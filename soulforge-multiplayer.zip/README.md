# Soulforge Multiplayer Mod

Placeholder build packaged for Aluminum Dog downloads.
Replace this zip by publishing from the Souper / mod repo.
Stable path: mods/soulforge-multiplayer.zip
