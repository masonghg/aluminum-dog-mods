﻿PLANTS VS. ZOMBIES MULTIPLAYER (version 1.0.1) - online co-op for up to 4 players
=====================================================================================

Defend the lawn together in a new endless mode, LAWN TYCOON:

  - Every player walks around the lawn as their own Crazy Dave (each one
    a different colour, with their name above his head).
  - Everyone shares the same sun and plants from the same seed bank.
  - You start in the front yard with ONE lane and only the Peashooter.
  - Killing zombies earns money, and the money is shared too. Spend it in
    the shop on new seed types (39 plants, from Sunflower to Winter
    Melon), on more lanes (up to all 5), and on new lawn mowers.
  - The zombies never stop. Every stage is 10 waves, and like the game's
    own Endless mode they get tougher and new kinds of zombies show up as
    you go: cones, buckets, footballers, balloons, diggers, gargantuars...
  - Join through Steam (an invite, or "Join Game" in your friends list),
    or over your home network by IP. Friends can join a game that's
    already running.
  - Every plant, zombie, pea, sun drop and coin is the same for everyone.

The rest of Plants vs. Zombies (Adventure, Mini-games, Puzzle, Survival,
Zen Garden) still works as normal in the modded game.

You need your own copy of Plants vs. Zombies (Game of the Year edition on
Steam). No game files are included - the mod reads them from your game
folder. Your normal Plants vs. Zombies install is not changed.


1. INSTALL (everyone who plays)
-------------------------------
The zip contains:
  PvZ-Multiplayer-Setup.exe     the installer (option A, easiest)
  Manual install - mod files    the raw mod files, if you'd rather install
                                it yourself (option B)
  Licenses and source           licenses and the mod's source changes
  README.txt                    this file

Use ONE of the two options below - they install exactly the same files.
Everyone who plays together must have the same version of the mod.

OPTION A: THE INSTALLER (recommended)
1. Unzip the zip anywhere (e.g. your Desktop). Don't run the installer from
   inside the zip - it copies the mod from the "Manual install - mod files"
   folder next to it.
2. Close Plants vs. Zombies, then double-click PvZ-Multiplayer-Setup.exe.
   If Windows says "Windows protected your PC", click "More info" and then
   "Run anyway" (the installer isn't signed by a company).
3. The installer finds your Plants vs. Zombies folder by itself. If it
   can't, click "Browse..." and pick the folder that has main.pak in it.
   (On Steam: right-click Plants vs. Zombies in your library > Manage >
   Browse local files.)
4. Leave "Make Steam start the mod..." ticked and click "Install" (it says
   "Reinstall" if the mod is already there).
   - To change the Steam setting, Steam has to be closed for a moment. The
     installer asks first and closes it for you; start Steam again after.
   - If Windows asks for administrator permission, click Yes.
5. Start Plants vs. Zombies from Steam as usual. On the main menu, click
   "Lawn Tycoon (Co-op)" in the top right corner.

The installer puts the mod in a new "PvZ-Multiplayer" folder inside your
Plants vs. Zombies folder and sets Plants vs. Zombies' Steam launch
options so Steam starts the mod instead of the original game. To update to
a newer version of the mod, just run the new installer and click
"Reinstall".

OPTION B: MANUAL INSTALL (the raw mod files)
Everything the installer does, done by hand:
1. Open your Plants vs. Zombies folder (the one with main.pak in it). On
   Steam: right-click Plants vs. Zombies in your library > Manage > Browse
   local files.
2. Copy the "PvZ-Multiplayer" folder from "Manual install - mod files"
   into it. You should end up with
     <Plants vs. Zombies folder>\PvZ-Multiplayer\PvZ-Multiplayer.exe
3. In Steam, right-click Plants vs. Zombies > Properties > General >
   Launch Options, and paste (with the quotes, using your real path):
     "<Plants vs. Zombies folder>\PvZ-Multiplayer\PvZ-Multiplayer.exe" %command%
   For example:
     "C:\Program Files (x86)\Steam\steamapps\common\Plants Vs Zombies\PvZ-Multiplayer\PvZ-Multiplayer.exe" %command%
4. Start Plants vs. Zombies from Steam.

You can also start PvZ-Multiplayer.exe directly (or from the desktop
shortcut the installer makes). Everything works that way except the
"Invite Steam Friends" button, which needs the Steam overlay - and that
only shows up when Steam starts the game.


2. PLAYING TOGETHER
-------------------
Click "Lawn Tycoon (Co-op)" in the top right corner of the main menu. The
Lawn Tycoon screen has these buttons:

  Play Solo              play on your own
  Host Steam Lobby       host a game your Steam friends can join
  Invite Steam Friends   opens the Steam overlay's invite window
  Host LAN Game          host a game on your home network
  Join LAN               join a LAN game at the IP address in the box
  Start Game             (host) start once everyone is in
  Leave Lobby / Main Menu

HOSTING THROUGH STEAM
1. Click "Host Steam Lobby".
2. Click "Invite Steam Friends" and invite your friends, or tell them to
   right-click you in their Steam friends list and choose "Join Game".
3. When everyone shows up in the player list, click "Start Game".

JOINING THROUGH STEAM
- Accept the host's invite, or right-click the host in your Steam friends
  list and choose "Join Game". If the game isn't running, Steam starts it
  and you go straight into the host's lobby.
- You can join a game that has already started. You'll show up next to
  the others after a few seconds of "Syncing with host...".

LAN / BY IP
- The host clicks "Host LAN Game". Everyone else types the host's IP
  address in the box next to "Join LAN" and clicks it.
- It uses TCP port 27777. When Windows Firewall asks about
  PvZ-Multiplayer.exe, click "Allow". Playing over the internet this way
  needs that port forwarded on the host's router - Steam is much easier.

The host's game runs the lawn and everyone else follows it, so the host
should be the player with the best connection. If the host leaves, the
game ends for everyone.


3. HOW TO PLAY LAWN TYCOON
--------------------------
CONTROLS
  WASD or arrow keys   walk
  Space, E or Enter    plant the selected seed on the tile you're standing on
  Q or X               dig up the plant on your tile (shovel)
  1-9, 0               pick a seed from the seed bank
  B or Tab             open / close the shop
  L                    buy the next lane (while the shop is open)
  Esc                  close the shop / pause menu

- The tile you'll plant on is outlined, with a see-through preview of the
  plant.
- Walk over sun and coins to collect them.
- You can also click a seed packet to pick it, and use the mouse in the
  shop.

MONEY AND THE SHOP
- You start with $150. Every zombie you kill pays out (tougher zombies pay
  more), and coins they drop are worth extra.
- Money and sun are shared by the whole team. Anyone can spend them, and
  everyone sees who bought what.
- Click a seed in the shop to buy it. Your seed bank holds 10 seeds; click
  a seed you own to put it in or take it out of the seed bank.
- "Buy lane" opens the next lane of the lawn ($500, $1,500, $3,500,
  $7,000). Zombies only come down lanes you own, but more lanes also
  means bigger waves.
- "Restock mowers" puts back the lawn mowers that have been used ($250
  each).

WAVES
- Each stage is 10 waves with a short break in between. The top right
  shows the stage and wave.
- If a zombie gets into the house, it's game over for everyone. The host
  can click "Try Again" to start a new lawn, and everyone else goes along
  automatically.


4. TROUBLESHOOTING
------------------
"Join Game" / the invite starts the normal Plants vs. Zombies
    Steam isn't set to start the mod. Run the installer again with "Make
    Steam start the mod..." ticked, or set the launch options by hand
    (option B, step 3).
"The host is running a different version..."
    Everyone needs the same version. Download the newest zip and install
    it again (everyone, host included).
The "Invite Steam Friends" button does nothing
    The Steam overlay only works when Steam starts the game. Start Plants
    vs. Zombies from your Steam library (with the launch options set), or
    have friends use "Join Game" on you instead.
"Steam is not running" in the lobby
    Start Steam and log in, then start the game again. LAN still works
    without Steam.
Can't connect over LAN
    Check the IP (on the host: open a Command Prompt and type ipconfig),
    make sure both PCs are on the same network, and that the host clicked
    "Allow" when Windows Firewall asked.
The game says "resyncs" next to the ping
    The game noticed a difference between players and fixed it by copying
    the host's lawn. A few now and then are fine.
"Windows protected your PC"
    Click "More info", then "Run anyway".

Your modded saves and settings are kept separately from the original
game, in %APPDATA%\io.github.wszqkzqk\PvZPortable.


5. UNINSTALL
------------
Run PvZ-Multiplayer-Setup.exe and click "Uninstall". It removes the
PvZ-Multiplayer folder, the desktop shortcut and the Steam launch option.

By hand: delete the PvZ-Multiplayer folder from your Plants vs. Zombies
folder, and clear the Launch Options box in Steam (right-click Plants vs.
Zombies > Properties > General).


6. CREDITS AND LICENSES
-----------------------
Plants vs. Zombies is made by PopCap Games / Electronic Arts. This mod is
not affiliated with them.

The modded game is built on PvZ-Portable
(https://github.com/wszqkzqk/PvZ-Portable), an open-source
reimplementation licensed under the GNU LGPL v3.0. The licenses and this
mod's full source changes are in the "Licenses and source" folder. It also
uses SDL2 and other open-source libraries, and Valve's Steamworks API
(steam_api64.dll).
