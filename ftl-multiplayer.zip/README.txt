FTL CO-OP MOD (version 11) - up to 8 players
===========================================

Everyone shares one ship. Each player controls one crew member and can only
use the controls of the room that crew member is standing in:

  - PILOTING room:      system power, jumping, the star map, upgrades
                        and the doors.
  - WEAPONS room:       power, aim and fire the weapons (and autofire).
  - DRONE CONTROL room: power and launch the drones.
  - DOORS room:         open and close all the doors on the ship.
  - TELEPORTER, CLOAKING, HACKING, MIND CONTROL and BACKUP BATTERY rooms:
                        use that system's buttons (send/return crew,
                        cloak, launch the hacking drone, mind control,
                        start the battery). Their power can be changed
                        from that room or from Piloting.

Event answers and stores are open to everyone (see section 4).

Crew members that no player controls are run by the game's AI: they man
empty stations, repair, fight fires and boarders. Each station goes to the
AI crew member with the best skill for it (piloting, engines, shields,
weapons), and a station a player walks into is left to that player - the AI
crew member there moves out of the way. They go to the medbay on
their own when they are badly hurt (below 25%) during a fight, and whenever
the ship is calm (no enemy, boarders, fire, breach or missing air) they go
there if hurt at all. They stay until fully healed. If the medbay is off,
broken or unsafe, a badly hurt one (below 30%) waits in the nearest safe
room instead of fighting on, until the boarders, fires and breaches are
dealt with or the medbay works again.
Fighting fires, they keep at it until their health gets close to what the
fire would take from them, then step out to heal - like repair drones do.
When a room runs out of air, each one works out how long the walk to the
medbay takes and leaves early enough to get there alive.

The host's game is the "real" one. The other players join over the internet
and all games are kept in lockstep, so everything happens the same way on
every screen.


1. INSTALL (everyone who joins)
-------------------------------
The zip contains:
  FTL-Coop-Install.exe        the installer (option A, easiest)
  Manual install - mod files  the raw mod files, if you'd rather install
                              it yourself (option B)
  README.txt                  this file

Use ONE of the two options below - they install exactly the same mod.

OPTION A: THE INSTALLER (recommended)
1. Unzip the zip anywhere (e.g. your Desktop).
2. Close FTL, then double-click FTL-Coop-Install.exe.
   If Windows says "Windows protected your PC", click "More info" and then
   "Run anyway" (the installer isn't signed by a company).
3. The installer finds your FTL folder and does the rest:
   - It rolls FTL back to version 1.6.9 if needed (the mod only works with
     1.6.9). Your current FTLGame.exe is kept as FTLGame_orig.exe.
   - It installs or updates the mod files.
4. Start FTL as usual (from Steam is fine).

If Steam updates FTL later, or there is a new version of the mod, just run
the new FTL-Coop-Install.exe again. Your settings are kept. Everyone who
plays together must have the same version of the mod installed.

Your player name is your Steam name (the account logged into Steam). If the
Steam name can't be read, the "name" line in ftlcoop.ini is used instead;
add steam_name=0 to ftlcoop.ini to always use that name.

The installer knows the Steam, GOG, Epic, Humble, EA/Origin and Microsoft
versions of FTL. For non-Steam versions it downloads the official rollback
patch from github.com/FTL-Hyperspace/FTL-Version-Rollback. Everyone should
use the same store's version (Steam was tested).

Other DLL mods such as FTL Hyperspace can't run at the same time; the
installer renames Hyperspace.dll and xinput1_4.dll to *.disabled.

OPTION B: MANUAL INSTALL (the raw mod files)
Everything the installer does, done by hand:
1. Close FTL and find your FTL folder (the one with FTLGame.exe in it).
   On Steam: right-click FTL in your library > Manage > Browse local files.
2. Roll FTL back to version 1.6.9 (the mod only works with 1.6.9; skip
   this if you already did it for this FTL install):
   - Download https://github.com/FTL-Hyperspace/FTL-Version-Rollback/archive/refs/heads/main.zip
     and unzip it.
   - Copy everything inside its FTL-Version-Rollback-main folder (rollback.bat
     and the patch folder) into your FTL folder.
   - Double-click rollback.bat. It keeps your current FTLGame.exe as
     FTLGame_orig.exe. If it says FTLGame_orig.exe already exists, either
     you're already on 1.6.9, or delete that old FTLGame_orig.exe and run
     rollback.bat again.
3. From the "Manual install - mod files" folder, copy FTLCoop.dll and
   dbghelp.dll into your FTL folder (replace the old ones when updating).
4. First install only: also copy ftlcoop.ini into your FTL folder. When
   updating, keep your existing ftlcoop.ini (it holds your settings). The
   mod does nothing without this file.
5. If your FTL folder has Hyperspace.dll or xinput1_4.dll, rename them to
   Hyperspace.dll.disabled and xinput1_4.dll.disabled.
6. Start FTL as usual. "Co-op: ..." in the top right corner of the main
   menu means the mod is running.


2. CONNECTING
-------------
THROUGH STEAM (easiest - no IP address or port forwarding needed)
- Everyone needs the mod installed and FTL running through a Steam account
  (the Steam version of FTL). Steam friends only.
- Whoever INVITES is the host. In FTL's main menu, click "Invite Steam
  friends to play" (top left corner) and click a friend's name. During a
  run, hover over the co-op button in the top right corner and click
  "Invite Steam friends". Friends already playing FTL are listed in green.
- Whoever JOINS is a client: accept the invite in Steam, or right-click the
  host in your Steam friends list and choose "Join Game". If FTL isn't
  running, Steam starts it. If you're in the middle of a run, go back to the
  main menu and it connects you.
- Inviting from the main menu makes you the host if you weren't already.
  A client who is already playing with someone can invite more friends too;
  they join that same host.

WITH AN IP ADDRESS (the old way, also works without Steam)
- Run the installer too, then open ftlcoop.ini in the FTL folder and set
  mode=host (the installer never changes a host back to join).
- On your router, forward TCP port 34512 to your PC's local IP address
  (find it with "ipconfig" in a command prompt, "IPv4 Address").
- The first time FTL starts with mode=host, Windows Firewall may ask about
  FTLGame.exe - click "Allow access".
- The host tells the others their public IP address (e.g. from a site like
  whatismyip.com) - only share it with people you trust.
- Joiners click "Join by IP address" (or "Host IP: ...") in the top left
  corner of FTL's main menu, type or paste (Ctrl+V) the address and press
  Enter (or click Connect). It is saved and used from then on.


3. STARTING A GAME
------------------
1. Everyone starts FTL (the order doesn't matter). A small button in the
   top right corner shows the connection: "Co-op: Connected (3)",
   "Co-op: Connecting..." or "Co-op: Disconnected" (green/yellow/red dot).
   Hover the mouse over it for the details: who is connected, each
   player's crew member, room, health and ping, who is at which station,
   what the AI crew is doing (and who is healing), input delay, how often
   the game had to wait for someone, and when the games were last synced.
2. The HOST starts a new run or clicks Continue. Everyone else just waits in
   the main menu.
3. While the host is in the ship selection screen, everyone else sees the
   same screen: the ship, layout, crew names, difficulty and Advanced
   Edition setting. It's view-only - talk it over, the host clicks.
4. When the host starts the run (or continues one), everyone's game loads
   it a moment later.

Players can join or leave in the middle of a run. A player who joins gets
the current run a couple of seconds later (the game pauses briefly for
everyone while it is sent). When a player leaves, the others keep playing.

Co-op runs use their own save file, so your normal single-player save is
not touched.


4. CONTROLS AND RULES
---------------------
- The host is P1, the others are P2-P8 in the order they joined. Your crew
  member has your label above its head and is always selected for you.
- Every player gets their own crew member. If there are more players than
  crew, the extra players get one as soon as a crew member is free (for
  example when you hire one at a store).
- Right-click a room to walk your crew member there.
- Hovering over the co-op button at the top right also says which room you
  are in and what you can control there. If you try something you can't do
  from your room, a red message tells you where to go.
- WEAPONS room: click a weapon to power it, click it again to arm it, then
  click an enemy room to fire. Right-click a weapon to unpower it. Aiming
  only affects the gunner; the others can keep using the mouse normally.
- DRONE CONTROL room: click a drone to power/launch it, right-click to
  power it down. Only the player in this room can use drones.
- DOORS room: click any door, or use the open/close all doors buttons next
  to the Doors system.
- TELEPORTER / CLOAKING / HACKING / MIND CONTROL / BACKUP BATTERY rooms:
  the player in the room uses that system's buttons and hotkeys (e.g. C to
  cloak). The pilot can still power these systems up and down, but can't
  activate them.
- PILOTING room: everything else (see the top of this file), including the
  doors.
- Events: ANY player, wherever their crew member is, can answer an event
  by clicking a choice or pressing its number key (1-9, also on the
  number pad). The first answer counts, so talk it over first.
- Stores: ANY player, wherever their crew member is, can open the store
  and buy, sell or close it. Talk it over before spending the scrap.
- Right-click only ever walks your crew member, even over a door.
- Renaming crew: the player in the Piloting room opens the ship menu, goes
  to the crew tab, clicks a crew name, types the new name and presses Enter.
- Tooltips are your own: hover over something to see its tooltip (in
  the upgrade screen, the system description box follows your mouse too).
- During co-op the game draws at most 60 frames per second (the speed the
  game itself runs at), even with a faster monitor or vsync turned off.
- SPACE pauses and unpauses for everyone.
- Keyboard shortcuts only work for the room you are in (e.g. weapon hotkeys
  only in the Weapons room, drone hotkeys only in Drone Control). Esc (the
  pause menu) is disabled.
- Turned off because they don't fit several players: dragging a box to
  select several crew, dragging weapons/drones to rearrange them, and the
  options, Save Stations and Return Stations buttons.
- Other players' mouse cursors are shown as small crosses labeled P1, P2...
- If your crew member dies, you automatically take over another one.

SAVING AND STOPPING
- Click "Vote: Save & Go to Main Menu" in the top right corner (next to
  the co-op button). Once EVERY
  player has voted, the run is saved and everyone goes back to the main
  menu. Click it again ("Cancel my vote") to take your vote back.
- To keep playing later, the host clicks Continue in the main menu.
- If the host's game closes unexpectedly, the host can Continue from the
  last time everyone was synced.


5. TROUBLESHOOTING
------------------
"Fatal Error ... needs FTL version 1.6.9" / "Failed to find address ..."
    FTLGame.exe isn't version 1.6.9 (Steam probably updated it). Close FTL
    and run FTL-Coop-Install.exe again (or redo step 2 of the manual
    install).
"Could not reach <ip>:34512, retrying"
    The host isn't running FTL with mode=host yet, or the port forward /
    firewall on the host's side is missing, or the host IP is wrong (fix
    it with the "Host IP" button in the main menu).
"Game files differ from the host's"
    Different FTL versions/stores or different data mods. Everyone needs
    1.6.9 from the same store with identical files.
"Different co-op mod versions (this game has version ...)"
    Everyone must install the same version of the mod - all players should
    download the newest zip and run its FTL-Coop-Install.exe (or copy its
    FTLCoop.dll and dbghelp.dll over the old ones).
"Cannot listen on port 34512" (host)
    Another program (or a second copy of FTL) is using the port. Steam
    friends can still join.
No "Invite Steam friends" button
    Steam isn't running, or FTL wasn't started from a Steam account
    (steam_api.dll must be in the FTL folder). Use the IP address instead.
A Steam friend can't connect ("Connecting..." stays yellow)
    Both of you need this same build of the mod installed. Ask the host to
    invite you again, or use "Join Game" on them in your Steam friends list.
"Waiting for other players..." pops up often
    Someone's connection is slow. The host's game measures everyone's ping
    and raises the input delay automatically when the run is synced; the
    host can also raise input_delay in ftlcoop.ini (e.g. 10).
"Games drifted apart - resyncing from host"
    The games went out of sync; the host's game is sent again automatically
    and it only takes a moment. This should now be rare. If it keeps happening, please send the
    host ftlcoop.log and any ftlcoop.log.desync*.txt files from your FTL
    folder.

Log file: ftlcoop.log in the FTL folder (send it along with any bug report).


6. UNINSTALL
------------
Delete FTLCoop.dll, dbghelp.dll, ftlcoop.ini and FTL-Coop-readme.txt from
the FTL folder (or set mode=off in ftlcoop.ini to play normal FTL for a
while). To go back to the latest FTL version, use Steam's "Verify integrity
of game files" (right-click FTL > Properties > Installed Files).
