==============================================================
  NOITA CO-OP (FULL SYNC) - 2 PLAYER MOD - TEST BUILD v1.3.0
==============================================================

Two players play in the SAME Noita world at the same time: shared terrain,
liquids, enemies, items, physics objects, spells, perks, orbs and hearts.
If you die while your partner is alive you go DOWN instead of getting a
game over, and your partner can revive you.

You can connect through STEAM (easiest - no IP, no port forwarding) or
directly by IP address.

This is a test build. Things may break - see "REPORTING PROBLEMS" at the end.

NEW IN 1.3.0 (BOTH players must install it - 1.2.0 can't connect to 1.3.0):
 - Fixed "ghost" enemies that only one player could see, or that
   couldn't be killed.
 - Fixed enemies spawning twice inside each other.
 - Burning terrain (oil, wood, grass...) and burning crates/barrels now
   burn on both screens.
 - Water and other liquids are re-checked much more often, so pools and
   spills look the same on both screens.


--------------------------------------------------------------
  WHAT YOU NEED
--------------------------------------------------------------
 - Noita on Windows (Steam version, normal branch - not a beta).
   Both players need the same Noita version and the same mods.
 - To play through Steam: you and your partner are Steam friends.
 - Internet access during install (only if the Microsoft Visual C++
   runtime is missing - the installer downloads it from Microsoft).


--------------------------------------------------------------
  WHAT'S IN THIS ZIP
--------------------------------------------------------------
 NoitaCoop_Installer.exe          - installs and sets everything up
                                    for you (OPTION A, recommended)
 Manual install - mod folders\    - the raw mod, if you'd rather
                                    install it yourself (OPTION B)
 README.txt                       - this file

Use ONE of the two options. Both players need the same version.


--------------------------------------------------------------
  OPTION A: INSTALL WITH THE INSTALLER  (recommended)
--------------------------------------------------------------
 1. CLOSE NOITA if it is running.

 2. Extract this zip (right-click > Extract All...). Don't run the exe
    from inside the zip.

 3. Double-click  NoitaCoop_Installer.exe

    Windows may show a blue "Windows protected your PC" box because the
    installer isn't signed by a company. Click "More info", then
    "Run anyway". (Antivirus may also ask - allow it.)

 4. Answer the questions in the window:
      - "Install here?"          -> press Enter (Y) if the Noita path is right.
                                    If it can't find Noita, pick the folder
                                    that contains noita.exe
                                    (Steam: right-click Noita > Manage >
                                    Browse local files).
      - "Your player name"       -> type a name, Enter.
      - "Host IP for direct connections" -> press Enter (only matters if
                                    you don't use Steam).
      - Visual C++ runtime       -> if it asks, press Enter (Y) and click
                                    Yes when Windows asks for permission.
      - Firewall rule            -> press Enter (No) - not needed with Steam.

 5. When it says DONE, press Enter to close it.

What the installer does for you:
 - Copies the mod into  <Noita folder>\mods\noita_coop  plus two small
   "game mode" mods (noita_coop_host, noita_coop_join) that add the
   "Co-op: Host" and "Co-op: Join" choices to Noita's New Game menu
 - Turns them ON in Noita's mod list
 - Turns ON "Allow unsafe mods" (the mod needs it for networking)
 - Turns OFF "Noita Online" if you have it (they can't run together)
 - Installs the 32-bit Microsoft Visual C++ runtime if it's missing
 - Sets your name and the direct-connection IP in the mod settings
Backups of Noita's settings files are saved next to them as
"*.coop_backup" (in %USERPROFILE%\AppData\LocalLow\Nolla_Games_Noita).


--------------------------------------------------------------
  OPTION B: INSTALL THE MOD YOURSELF  (manual)
--------------------------------------------------------------
Do by hand what the installer would do:

 1. CLOSE NOITA if it is running, and extract this zip.

 2. Open your Noita folder (Steam: right-click Noita > Manage >
    Browse local files) and open the  mods  folder inside it.

 3. Copy the three folders from "Manual install - mod folders" into
    that mods folder:
        noita_coop        (the mod itself)
        noita_coop_host   (adds "Co-op: Host" to the New Game menu)
        noita_coop_join   (adds "Co-op: Join" to the New Game menu)
    You should end up with  <Noita folder>\mods\noita_coop\init.lua
    (not mods\Manual install - mod folders\...). If you're updating,
    delete the old three folders first.

 4. Start Noita > main menu > Mods:
      - Turn ON "Allow unsafe mods" (the mod needs it for networking).
      - Enable "Noita Co-op (Full Sync)", "Co-op: Host" and
        "Co-op: Join".
      - If you have "Noita Online" (evaisa.mp), disable it - the two
        can't run together.
    Restart Noita after changing mods.

 5. Mod settings > "Noita Co-op (Full Sync)": type your name. If you
    play over a direct IP instead of Steam, set "Host address" too.

 6. If the game freezes or crashes at start, install the 32-bit
    Microsoft Visual C++ runtime:
        https://aka.ms/vs/17/release/vc_redist.x86.exe
    (the installer does this for you in Option A).

 7. Only if you HOST over a direct IP (not Steam): allow Noita through
    Windows Firewall and forward TCP port 25600 on your router.


--------------------------------------------------------------
  HOW TO PLAY
--------------------------------------------------------------
Start Noita through Steam (so the Steam features work).

THE HOST (the player whose world you play in):
 1. Main menu > NEW GAME. In the list of game modes pick
        Co-op: Host
    and start the game.
 2. In game, press F9 and click "Invite a Steam friend" to send your
    friend a Steam invite (or just tell them to join - see below).
    The bottom-left corner shows "Co-op: hosting (Steam + port 25600),
    waiting for your friend".

THE PLAYER WHO JOINS:
 Wait until the host is IN GAME (past the main menu), then either:
  a) accept the host's Steam invite (Steam chat / overlay), or use
     "Join Game" on their Steam profile, or press F9 in any game and
     click "Join <friend>". If Noita isn't running yet, Steam starts
     it - click Continue or New Game.
     You don't have to be in the host's world: when you connect, the
     screen says "Co-op: loading <host>'s world" and after about 3
     seconds Noita closes and starts again by itself, straight into a
     new game in the host's world, and connects. (Your own run at that
     moment is replaced, like starting a New Game. Your unlocks and
     progress are kept.)
  b) or Main menu > NEW GAME > pick
        Co-op: Join
     and start the game. It finds your Steam friend's co-op game by
     itself (and also tries the direct IP from the settings) and loads
     their world right away, without a restart.

When you're connected, the bottom-left corner shows
        Co-op: <partner name> - <ping> ms (Steam)

THE F9 CO-OP MENU (in game):
 - Host this world        - make the world you're in the shared world
 - Invite a Steam friend  - opens Steam's invite window (host)
 - Join <friend>          - one button per Steam friend playing Noita
                            ("(hosting)" = they have a co-op game open)
 - Connect to <IP>:25600  - direct connection to the IP in the settings
 - Retry now
 Joining someone needs the SAME world: if the worlds are different your
 game restarts into the host's world by itself (see above).

"Continue" works too: a saved co-op run remembers whether you were the
host or the joining player and reconnects (the host should continue
their run first).

In game:
 - Your partner has a name tag. When they're off screen, an arrow at
   the edge of the screen points to them, with the distance.
 - You see your partner burning, electrified, wet or invisible (faint),
   and liquid they spray from a flask appears instantly.
 - Kicked crates, barrels, furniture, flasks and wands fly the same way
   on both screens (whoever kicks something "owns" it until it stops).
 - The terrain is compared continuously in the background and any spot
   that drifted apart is repaired, so both worlds stay the same. Fire on
   terrain and props is shared too. Flowing liquids can look slightly
   different for a moment, then snap back into place.
 - If you die while your partner is alive you're DOWN. Your partner
   revives you by standing right next to you for about 3 seconds.
   Reaching a Holy Mountain also revives a downed partner.
   If BOTH players go down, it's game over.
 - Perks, orbs and hearts picked up by one player are given to both.
 - Opening the inventory or pause menu does NOT freeze the world while
   connected (otherwise the other player would desync) - be careful.
 - F10 shows network stats (useful for bug reports).
 - If the connection drops, the mod reconnects automatically.


--------------------------------------------------------------
  PLAYING WITHOUT STEAM (direct IP)
--------------------------------------------------------------
 - The host forwards TCP port 25600 on their router to their PC and
   allows it in Windows Firewall (the installer can add the rule).
 - The joining player puts the host's public IP in the mod settings
   ("Host address", default 70.180.181.97). "Co-op: Join" and the F9
   "Connect to" button use it.


--------------------------------------------------------------
  TROUBLESHOOTING
--------------------------------------------------------------
I don't see "Co-op: Host" / "Co-op: Join" in the New Game menu
    Main menu > Mods: make sure "Noita Co-op (Full Sync)", "Co-op: Host"
    and "Co-op: Join" are enabled and "Allow unsafe mods" is on, then
    restart Noita. Or run the installer again.
    You can always start a normal game and press F9 instead.

"Could not reach a host before world generation"
    The host wasn't in game yet, or couldn't be found. Make sure the
    host is in the world (and that you're Steam friends), then quit to
    the main menu and start a NEW GAME > Co-op: Join again.

Bottom-left keeps saying "connecting to ..." / "did not answer"
    - Check that the host is in game and hosting (their bottom-left
      corner says "hosting").
    - Steam: both players must have "Use Steam" on in the mod settings
      and Noita must be started through Steam.
    - Direct IP: check the host address and the host's port forwarding.

"Steam: off - ..." in the F9 menu
    Steam isn't available to the mod (Noita not started through Steam,
    or "Use Steam" is off in the mod settings). Direct IP still works.

"DIFFERENT WORLD" / "still a different world"
    You're connected but not in the host's world, and restarting into it
    didn't work (or "Auto-load host's world" is off). Quit to the main
    menu and start a NEW GAME with "Co-op: Join" while the host is in
    game. Also check that both players have the same mods enabled and
    the same Noita version.

Noita closed after "loading <host>'s world" but didn't come back
    It restarts after about 2 seconds. If it doesn't, start Noita again
    through Steam within 3 minutes and click New Game - it still loads
    the host's world.

"Host rejected connection: Version mismatch"
    You and the host have different versions of the mod. Get the newest
    installer from the host and run it again (1.3.0 and 1.2.0 can't
    play together).

An enemy only one of you can see, or two enemies inside each other
    Should be fixed in 1.3.0. If it still happens, press F10 on both
    screens, take screenshots and send both coop_log.txt files.

"Host rejected connection: Server full (max 2 players)"
    Someone else is already connected to the host (or an old
    connection is stuck - wait a few seconds and try again).

"Noita Co-op is not running" message when the game starts
    The message says why. Usually: "Allow unsafe mods" is off (Mods
    menu > enable "Allow unsafe mods", restart Noita), or Noita Online
    is enabled (disable it in the Mods menu).

"Terrain sync disabled after an error" or crashes when digging/
exploding a lot
    Open the mod settings and turn OFF "Terrain sync" (both players),
    then start a NEW GAME. Everything else keeps working.

The game freezes/crashes right at start
    Run the installer again and let it install the Visual C++ runtime,
    or install it yourself from Microsoft:
        https://aka.ms/vs/17/release/vc_redist.x86.exe


--------------------------------------------------------------
  CHANGING SETTINGS
--------------------------------------------------------------
In Noita, open "Mod settings" (main menu or pause menu) and find
"Noita Co-op (Full Sync)":
 - Role in normal games: Off (default - use the New Game modes or F9),
                         Host, or Client
 - Use Steam:    on (default)
 - Auto-load host's world: on (default) - restart into the host's world
                 when you join someone who is in a different world
 - Host address: the host's IP for direct connections (70.180.181.97)
 - Port:         25600
 - Your name
 - Terrain sync, Downed & revive, Shared perks/orbs/hearts,
   Keep world running while paused
Connection settings take effect when you start a NEW GAME.

Running the installer again re-applies the name and IP you choose in
it (and updates the mod files).

Updating: download the newest zip from
    https://www.aluminumdoggames.com
and run the installer again (or repeat Option B).


--------------------------------------------------------------
  UNINSTALL
--------------------------------------------------------------
Delete these folders in <Noita folder>\mods:
    noita_coop   noita_coop_host   noita_coop_join
(or just disable them in Noita's Mods menu).
To turn unsafe mods back off: Mods menu > uncheck "Allow unsafe mods".


--------------------------------------------------------------
  REPORTING PROBLEMS
--------------------------------------------------------------
When something goes wrong, send the host:
 1. What you were doing when it happened.
 2. This log file (from both players if possible):
        <Noita folder>\mods\noita_coop\coop_log.txt
 3. A screenshot with F10 stats on, if it's a sync/lag problem.
