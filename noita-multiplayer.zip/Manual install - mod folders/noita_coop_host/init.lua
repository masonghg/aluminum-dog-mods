-- Tells the Noita Co-op mod (which reads and clears this in OnModPreInit) that this run is hosted.
ModSettingSet("noita_coop._gm_host", "1")
