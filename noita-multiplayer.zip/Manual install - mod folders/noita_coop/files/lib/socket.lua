-- Minimal non-blocking TCP sockets on top of Winsock (ws2_32.dll) through LuaJIT FFI.
-- Symbols are renamed with __asm__ so they can't clash with declarations made by other code.
local ffi = require("ffi")

local M = {}

pcall(ffi.cdef, [[
typedef uintptr_t coop_socket_t;
typedef struct { int16_t sin_family; uint16_t sin_port; uint32_t sin_addr; uint8_t sin_zero[8]; } coop_sockaddr_in;
typedef struct { uint32_t fd_count; coop_socket_t fd_array[64]; } coop_fd_set;
typedef struct { int32_t tv_sec; int32_t tv_usec; } coop_timeval;
typedef struct { char* h_name; char** h_aliases; int16_t h_addrtype; int16_t h_length; char** h_addr_list; } coop_hostent;

int __stdcall coop_WSAStartup(uint16_t version, void* data) __asm__("WSAStartup");
int __stdcall coop_WSAGetLastError(void) __asm__("WSAGetLastError");
coop_socket_t __stdcall coop_socket(int af, int type, int protocol) __asm__("socket");
int __stdcall coop_closesocket(coop_socket_t s) __asm__("closesocket");
int __stdcall coop_bind(coop_socket_t s, const coop_sockaddr_in* name, int namelen) __asm__("bind");
int __stdcall coop_listen(coop_socket_t s, int backlog) __asm__("listen");
coop_socket_t __stdcall coop_accept(coop_socket_t s, coop_sockaddr_in* addr, int* addrlen) __asm__("accept");
int __stdcall coop_connect(coop_socket_t s, const coop_sockaddr_in* name, int namelen) __asm__("connect");
int __stdcall coop_send(coop_socket_t s, const char* buf, int len, int flags) __asm__("send");
int __stdcall coop_recv(coop_socket_t s, char* buf, int len, int flags) __asm__("recv");
int __stdcall coop_ioctlsocket(coop_socket_t s, uint32_t cmd, uint32_t* argp) __asm__("ioctlsocket");
int __stdcall coop_setsockopt(coop_socket_t s, int level, int optname, const char* optval, int optlen) __asm__("setsockopt");
int __stdcall coop_getsockopt(coop_socket_t s, int level, int optname, char* optval, int* optlen) __asm__("getsockopt");
uint16_t __stdcall coop_htons(uint16_t v) __asm__("htons");
uint32_t __stdcall coop_inet_addr(const char* cp) __asm__("inet_addr");
coop_hostent* __stdcall coop_gethostbyname(const char* name) __asm__("gethostbyname");
int __stdcall coop_select(int nfds, coop_fd_set* r, coop_fd_set* w, coop_fd_set* e, const coop_timeval* timeout) __asm__("select");
]])

local AF_INET = 2
local SOCK_STREAM = 1
local IPPROTO_TCP = 6
local TCP_NODELAY = 1
local SOL_SOCKET = 0xffff
local SO_ERROR = 0x1007
local SO_SNDBUF = 0x1001
local SO_RCVBUF = 0x1002
local FIONBIO = 0x8004667E
local WSAEWOULDBLOCK = 10035
local WSAEINPROGRESS = 10036
local INADDR_NONE = 0xFFFFFFFF

local ws = nil
local INVALID = nil
local recv_buf = ffi.new("char[65536]")

local function lib()
	if ws then return ws end
	ws = ffi.load("ws2_32")
	local data = ffi.new("uint8_t[1024]")
	ws.coop_WSAStartup(0x0202, data)
	INVALID = tonumber(ffi.cast("coop_socket_t", -1))
	return ws
end

local function last_error()
	return ws.coop_WSAGetLastError()
end

local function make_box(h)
	local box = ffi.new("coop_socket_t[1]", h)
	return ffi.gc(box, function(b) ws.coop_closesocket(b[0]) end)
end

local function ip_to_string(addr)
	local a = tonumber(addr)
	return string.format("%d.%d.%d.%d", a % 256, math.floor(a / 256) % 256, math.floor(a / 65536) % 256, math.floor(a / 16777216) % 256)
end

local Sock = {}
Sock.__index = Sock

local function wrap(h, peer)
	local s = setmetatable({ box = make_box(h), h = h, closed = false, peer = peer }, Sock)
	return s
end

function Sock:set_options()
	local arg = ffi.new("uint32_t[1]", 1)
	ws.coop_ioctlsocket(self.h, FIONBIO, arg)
	local one = ffi.new("int[1]", 1)
	ws.coop_setsockopt(self.h, IPPROTO_TCP, TCP_NODELAY, ffi.cast("const char*", one), 4)
	local big = ffi.new("int[1]", 1024 * 1024)
	ws.coop_setsockopt(self.h, SOL_SOCKET, SO_SNDBUF, ffi.cast("const char*", big), 4)
	ws.coop_setsockopt(self.h, SOL_SOCKET, SO_RCVBUF, ffi.cast("const char*", big), 4)
end

function Sock:close()
	if self.closed then return end
	self.closed = true
	ws.coop_closesocket(self.h)
	ffi.gc(self.box, nil)
end

-- Returns number of bytes sent (possibly 0 when the socket buffer is full) or nil, err.
function Sock:send(str, offset)
	offset = offset or 0
	local len = #str - offset
	if len <= 0 then return 0 end
	local n = ws.coop_send(self.h, ffi.cast("const char*", str) + offset, len, 0)
	if n < 0 then
		local err = last_error()
		if err == WSAEWOULDBLOCK then return 0 end
		return nil, "send error " .. tostring(err)
	end
	return n
end

-- Returns a string with whatever data is available ("" if none) or nil, err when the connection is gone.
function Sock:recv_available(max_bytes)
	max_bytes = max_bytes or (4 * 1024 * 1024)
	local parts = nil
	local total = 0
	while total < max_bytes do
		local n = ws.coop_recv(self.h, recv_buf, 65536, 0)
		if n > 0 then
			parts = parts or {}
			parts[#parts + 1] = ffi.string(recv_buf, n)
			total = total + n
		elseif n == 0 then
			if parts then return table.concat(parts) end
			return nil, "connection closed"
		else
			local err = last_error()
			if err == WSAEWOULDBLOCK then break end
			if parts then return table.concat(parts) end
			return nil, "recv error " .. tostring(err)
		end
	end
	if parts then return table.concat(parts) end
	return ""
end

local function wait(h, want_read, want_write, timeout_ms)
	local rset, wset, eset = nil, nil, ffi.new("coop_fd_set")
	eset.fd_count = 1; eset.fd_array[0] = h
	if want_read then rset = ffi.new("coop_fd_set"); rset.fd_count = 1; rset.fd_array[0] = h end
	if want_write then wset = ffi.new("coop_fd_set"); wset.fd_count = 1; wset.fd_array[0] = h end
	local tv = ffi.new("coop_timeval")
	tv.tv_sec = math.floor(timeout_ms / 1000)
	tv.tv_usec = (timeout_ms % 1000) * 1000
	local r = ws.coop_select(0, rset, wset, eset, tv)
	if r < 0 then return "error" end
	if eset.fd_count > 0 then return "error" end
	if (rset and rset.fd_count > 0) or (wset and wset.fd_count > 0) then return "ready" end
	return "timeout"
end

-- For a connecting socket: "connected", "pending" or "failed".
function Sock:poll_connect(timeout_ms)
	local r = wait(self.h, false, true, timeout_ms or 0)
	if r == "ready" then
		local err = ffi.new("int[1]", 0)
		local len = ffi.new("int[1]", 4)
		ws.coop_getsockopt(self.h, SOL_SOCKET, SO_ERROR, ffi.cast("char*", err), len)
		if err[0] ~= 0 then return "failed", "error " .. tostring(err[0]) end
		return "connected"
	elseif r == "timeout" then
		return "pending"
	end
	local err = ffi.new("int[1]", 0)
	local len = ffi.new("int[1]", 4)
	ws.coop_getsockopt(self.h, SOL_SOCKET, SO_ERROR, ffi.cast("char*", err), len)
	return "failed", "error " .. tostring(err[0])
end

function Sock:wait_readable(timeout_ms)
	return wait(self.h, true, false, timeout_ms) == "ready"
end

function Sock:accept()
	local addr = ffi.new("coop_sockaddr_in")
	local len = ffi.new("int[1]", ffi.sizeof("coop_sockaddr_in"))
	local h = ws.coop_accept(self.h, addr, len)
	if tonumber(h) == INVALID then return nil end
	local s = wrap(h, ip_to_string(addr.sin_addr))
	s:set_options()
	return s
end

local function resolve(host)
	local ip = ws.coop_inet_addr(host)
	if tonumber(ip) ~= INADDR_NONE then return ip end
	local he = ws.coop_gethostbyname(host)
	if he == nil or he.h_addr_list == nil or he.h_addr_list[0] == nil then return nil end
	return ffi.cast("uint32_t*", he.h_addr_list[0])[0]
end

function M.listen(port)
	local ok, err = pcall(lib)
	if not ok then return nil, "winsock unavailable: " .. tostring(err) end
	local h = ws.coop_socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)
	if tonumber(h) == INVALID then return nil, "socket() failed: " .. last_error() end
	local s = wrap(h, nil)
	local addr = ffi.new("coop_sockaddr_in")
	addr.sin_family = AF_INET
	addr.sin_port = ws.coop_htons(port)
	addr.sin_addr = 0
	if ws.coop_bind(h, addr, ffi.sizeof(addr)) ~= 0 then
		local e = last_error()
		s:close()
		if e == 10048 then return nil, "port " .. port .. " is already in use (restart Noita)" end
		return nil, "bind failed (" .. e .. ")"
	end
	if ws.coop_listen(h, 4) ~= 0 then
		local e = last_error()
		s:close()
		return nil, "listen failed (" .. e .. ")"
	end
	local arg = ffi.new("uint32_t[1]", 1)
	ws.coop_ioctlsocket(h, FIONBIO, arg)
	return s
end

-- Starts a non-blocking connect. Use poll_connect() to see when it completes.
function M.connect(host, port)
	local ok, err = pcall(lib)
	if not ok then return nil, "winsock unavailable: " .. tostring(err) end
	local ip = resolve(host)
	if ip == nil then return nil, "could not resolve " .. tostring(host) end
	local h = ws.coop_socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)
	if tonumber(h) == INVALID then return nil, "socket() failed: " .. last_error() end
	local s = wrap(h, host)
	s:set_options()
	local addr = ffi.new("coop_sockaddr_in")
	addr.sin_family = AF_INET
	addr.sin_port = ws.coop_htons(port)
	addr.sin_addr = ip
	local r = ws.coop_connect(h, addr, ffi.sizeof(addr))
	if r ~= 0 then
		local e = last_error()
		if e ~= WSAEWOULDBLOCK and e ~= WSAEINPROGRESS then
			s:close()
			return nil, "connect failed (" .. e .. ")"
		end
	end
	return s
end

return M
