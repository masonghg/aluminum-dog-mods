-- zstd compression through the bundled libzstd.dll. Everything degrades to "no compression" if it fails to load.
local ffi = require("ffi")

local Z = { ok = false }

pcall(ffi.cdef, [[
size_t coop_ZSTD_compress(void* dst, size_t dstCapacity, const char* src, size_t srcSize, int level) __asm__("ZSTD_compress");
size_t coop_ZSTD_decompress(void* dst, size_t dstCapacity, const char* src, size_t srcSize) __asm__("ZSTD_decompress");
size_t coop_ZSTD_compressBound(size_t srcSize) __asm__("ZSTD_compressBound");
unsigned coop_ZSTD_isError(size_t code) __asm__("ZSTD_isError");
]])

local lib = nil
local buf, buf_size = nil, 0

local function ensure(size)
	if size > buf_size then
		buf_size = math.max(size, buf_size * 2, 65536)
		buf = ffi.new("uint8_t[?]", buf_size)
	end
	return buf
end

function Z.init(path)
	local ok, res = pcall(ffi.load, path)
	if not ok then
		Z.err = tostring(res)
		return false
	end
	lib = res
	local ok2, err = pcall(function()
		local probe = string.rep("noita", 64)
		local c = Z.compress(probe)
		assert(c and Z.decompress(c, #probe) == probe)
	end)
	if not ok2 then
		lib = nil
		Z.err = tostring(err)
		return false
	end
	Z.ok = true
	return true
end

function Z.compress(s, level)
	local bound = tonumber(lib.coop_ZSTD_compressBound(#s))
	local dst = ensure(bound)
	local n = lib.coop_ZSTD_compress(dst, bound, s, #s, level or 3)
	if lib.coop_ZSTD_isError(n) ~= 0 then return nil end
	return ffi.string(dst, n)
end

function Z.decompress(s, raw_len)
	local dst = ensure(raw_len)
	local n = lib.coop_ZSTD_decompress(dst, raw_len, s, #s)
	if lib.coop_ZSTD_isError(n) ~= 0 then return nil end
	return ffi.string(dst, n)
end

return Z
