-- Compact binary serializer for plain Lua values: nil, booleans, numbers, strings and tables.
-- Integers that fit in 32 bits are stored as 1/2/4 bytes, everything else as a double.
local ffi = require("ffi")

local codec = {}

local T_NIL, T_FALSE, T_TRUE = 0, 1, 2
local T_I8, T_I16, T_I32, T_F64 = 3, 4, 5, 6
local T_STR8, T_STR32 = 7, 8
local T_ARR, T_MAP = 9, 10

local conv = ffi.new("union { double d; int32_t i; int16_t s; uint32_t u; uint8_t b[8]; }")
local char, sub, floor = string.char, string.sub, math.floor
local concat = table.concat
local ffi_string, ffi_cast = ffi.string, ffi.cast
local pairs, type, error = pairs, type, error

local function raw(n)
	return ffi_string(conv.b, n)
end

local enc

local function enc_number(out, n, v)
	if v == floor(v) and v >= -2147483648 and v <= 2147483647 then
		if v >= -128 and v <= 127 then
			n = n + 1; out[n] = char(T_I8, v % 256)
		elseif v >= -32768 and v <= 32767 then
			conv.s = v
			n = n + 1; out[n] = char(T_I16) .. raw(2)
		else
			conv.i = v
			n = n + 1; out[n] = char(T_I32) .. raw(4)
		end
	else
		conv.d = v
		n = n + 1; out[n] = char(T_F64) .. raw(8)
	end
	return n
end

enc = function(out, n, v)
	local t = type(v)
	if t == "number" then
		return enc_number(out, n, v)
	elseif t == "string" then
		local len = #v
		if len < 256 then
			n = n + 1; out[n] = char(T_STR8, len)
		else
			conv.u = len
			n = n + 1; out[n] = char(T_STR32) .. raw(4)
		end
		n = n + 1; out[n] = v
		return n
	elseif t == "boolean" then
		n = n + 1; out[n] = char(v and T_TRUE or T_FALSE)
		return n
	elseif t == "table" then
		local len = #v
		local count = 0
		for _ in pairs(v) do count = count + 1 end
		if count == len then
			conv.u = len
			n = n + 1; out[n] = char(T_ARR) .. raw(4)
			for i = 1, len do n = enc(out, n, v[i]) end
		else
			conv.u = count
			n = n + 1; out[n] = char(T_MAP) .. raw(4)
			for k, val in pairs(v) do
				n = enc(out, n, k)
				n = enc(out, n, val)
			end
		end
		return n
	end
	n = n + 1; out[n] = char(T_NIL)
	return n
end

function codec.encode(v)
	local out = {}
	local n = enc(out, 0, v)
	return concat(out, "", 1, n)
end

local dec

dec = function(s, p, pos, len)
	if pos >= len then error("codec: truncated") end
	local tag = p[pos]
	pos = pos + 1
	if tag == T_I8 then
		if pos + 1 > len then error("codec: truncated") end
		local b = p[pos]
		if b >= 128 then b = b - 256 end
		return b, pos + 1
	elseif tag == T_I16 then
		if pos + 2 > len then error("codec: truncated") end
		return ffi_cast("const int16_t*", p + pos)[0], pos + 2
	elseif tag == T_I32 then
		if pos + 4 > len then error("codec: truncated") end
		return ffi_cast("const int32_t*", p + pos)[0], pos + 4
	elseif tag == T_F64 then
		if pos + 8 > len then error("codec: truncated") end
		return ffi_cast("const double*", p + pos)[0], pos + 8
	elseif tag == T_STR8 then
		if pos + 1 > len then error("codec: truncated") end
		local l = p[pos]
		pos = pos + 1
		if pos + l > len then error("codec: truncated") end
		return sub(s, pos + 1, pos + l), pos + l
	elseif tag == T_STR32 then
		if pos + 4 > len then error("codec: truncated") end
		local l = ffi_cast("const uint32_t*", p + pos)[0]
		pos = pos + 4
		if pos + l > len then error("codec: truncated") end
		return sub(s, pos + 1, pos + l), pos + l
	elseif tag == T_TRUE then
		return true, pos
	elseif tag == T_FALSE then
		return false, pos
	elseif tag == T_NIL then
		return nil, pos
	elseif tag == T_ARR then
		if pos + 4 > len then error("codec: truncated") end
		local count = ffi_cast("const uint32_t*", p + pos)[0]
		pos = pos + 4
		local t = {}
		local v
		for i = 1, count do
			v, pos = dec(s, p, pos, len)
			t[i] = v
		end
		return t, pos
	elseif tag == T_MAP then
		if pos + 4 > len then error("codec: truncated") end
		local count = ffi_cast("const uint32_t*", p + pos)[0]
		pos = pos + 4
		local t = {}
		local k, v
		for _ = 1, count do
			k, pos = dec(s, p, pos, len)
			v, pos = dec(s, p, pos, len)
			if k ~= nil then t[k] = v end
		end
		return t, pos
	end
	error("codec: bad tag " .. tostring(tag))
end

function codec.decode(s)
	local p = ffi_cast("const uint8_t*", s)
	local v = dec(s, p, 0, #s)
	return v
end

return codec
