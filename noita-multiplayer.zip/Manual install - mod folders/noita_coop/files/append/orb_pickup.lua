-- noita_coop: report orbs picked by the local player
local coop_orig_item_pickup = item_pickup
function item_pickup( entity_item, entity_who_picked, item_name )
	local orb_id = nil
	if not EntityHasTag( entity_item, "coop_ignore" ) and EntityHasTag( entity_who_picked, "player_unit" ) then
		local oc = EntityGetFirstComponentIncludingDisabled( entity_item, "OrbComponent" )
		if oc ~= nil then orb_id = ComponentGetValue2( oc, "orb_id" ) end
	end
	coop_orig_item_pickup( entity_item, entity_who_picked, item_name )
	if orb_id ~= nil and orb_id >= 0 then
		GlobalsSetValue( "coop_evq", GlobalsGetValue( "coop_evq", "" ) .. "orb\t" .. tostring( orb_id ) .. "\n" )
	end
end
