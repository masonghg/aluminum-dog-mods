-- noita_coop: tell the partner when a Holy Mountain gets broken here
local coop_orig_checker_failed = material_area_checker_failed
function material_area_checker_failed( pos_x, pos_y )
	coop_orig_checker_failed( pos_x, pos_y )
	if GlobalsGetValue( "TEMPLE_PEACE_WITH_GODS" ) ~= "1" then
		GlobalsSetValue( "coop_evq", GlobalsGetValue( "coop_evq", "" ) .. "temple\t" .. temple_pos_to_id( pos_x, pos_y ) .. "\n" )
	end
end
