-- noita_coop: report heart pickups (max hp / healing changes) by the local player
local coop_orig_item_pickup = item_pickup
function item_pickup( entity_item, entity_who_picked, name )
	local dm = nil
	local max0, hp0, cap0 = 0, 0, 0
	if not EntityHasTag( entity_item, "coop_ignore" ) and EntityHasTag( entity_who_picked, "player_unit" ) then
		dm = EntityGetFirstComponentIncludingDisabled( entity_who_picked, "DamageModelComponent" )
		if dm ~= nil then
			max0 = ComponentGetValue2( dm, "max_hp" )
			hp0 = ComponentGetValue2( dm, "hp" )
			cap0 = ComponentGetValue2( dm, "max_hp_cap" )
		end
	end
	coop_orig_item_pickup( entity_item, entity_who_picked, name )
	if dm ~= nil and EntityGetIsAlive( entity_who_picked ) then
		local max1 = ComponentGetValue2( dm, "max_hp" )
		local hp1 = ComponentGetValue2( dm, "hp" )
		local cap1 = ComponentGetValue2( dm, "max_hp_cap" )
		local dmax, dhp, dcap = max1 - max0, hp1 - hp0, cap1 - cap0
		local full = ( hp1 >= max1 - 0.0001 ) and ( dhp > dmax + 0.0001 )
		if dmax ~= 0 or dhp ~= 0 or dcap ~= 0 then
			GlobalsSetValue( "coop_evq", GlobalsGetValue( "coop_evq", "" ) .. "heart\t" .. tostring( dmax ) .. "\t" .. tostring( dhp ) .. "\t" .. ( full and "1" or "0" ) .. "\t" .. tostring( dcap ) .. "\n" )
		end
	end
end
