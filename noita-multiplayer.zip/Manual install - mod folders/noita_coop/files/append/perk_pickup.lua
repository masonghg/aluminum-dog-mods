-- noita_coop: report perks picked by the local player
local coop_orig_item_pickup = item_pickup
function item_pickup( entity_item, entity_who_picked, item_name )
	local perk_id = nil
	if not EntityHasTag( entity_item, "coop_ignore" ) and EntityHasTag( entity_who_picked, "player_unit" ) then
		local comps = EntityGetComponentIncludingDisabled( entity_item, "VariableStorageComponent" ) or {}
		for _, c in ipairs( comps ) do
			if ComponentGetValue2( c, "name" ) == "perk_id" then
				perk_id = ComponentGetValue2( c, "value_string" )
			end
		end
	end
	coop_orig_item_pickup( entity_item, entity_who_picked, item_name )
	if perk_id ~= nil and perk_id ~= "" then
		GlobalsSetValue( "coop_evq", GlobalsGetValue( "coop_evq", "" ) .. "perk\t" .. perk_id .. "\n" )
	end
end
