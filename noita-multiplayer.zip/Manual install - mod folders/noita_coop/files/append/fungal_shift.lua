-- noita_coop: record the material conversions of a fungal shift caused by the local player
local coop_orig_fungal_shift = fungal_shift
function fungal_shift( entity, x, y, debug_no_limits )
	local who = entity
	local parent = EntityGetParent( entity )
	if parent ~= 0 then who = parent end
	if not EntityHasTag( who, "player_unit" ) then
		return coop_orig_fungal_shift( entity, x, y, debug_no_limits )
	end

	local conversions = {}
	local orig_convert = ConvertMaterialEverywhere
	ConvertMaterialEverywhere = function( from_material, to_material )
		conversions[#conversions + 1] = CellFactory_GetName( from_material ) .. "\t" .. CellFactory_GetName( to_material )
		return orig_convert( from_material, to_material )
	end
	local ok, err = pcall( coop_orig_fungal_shift, entity, x, y, debug_no_limits )
	ConvertMaterialEverywhere = orig_convert

	if #conversions > 0 then
		local iter = GlobalsGetValue( "fungal_shift_iteration", "0" )
		GlobalsSetValue( "coop_evq", GlobalsGetValue( "coop_evq", "" ) .. "fungal\t" .. iter .. "\t" .. table.concat( conversions, "\t" ) .. "\n" )
	end
	if not ok then error( err ) end
end
