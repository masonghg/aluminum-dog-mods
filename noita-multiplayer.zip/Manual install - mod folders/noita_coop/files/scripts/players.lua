-- Local player -> network, network -> remote player puppet, plus the downed / revive system.
-- Also mirrors visible status effects (burning, invisible, electrified, wet) and flask spraying.
local net = require("scripts.net")
local U = require("scripts.util")
local bit = require("bit")

local P = {
	puppet = nil,
	parts = nil,
	remote = nil,           -- latest remote state
	remote_look = nil,      -- latest remote appearance
	cx = nil, cy = nil,     -- interpolated puppet position
	downed = false,
	downed_frame = 0,
	revive_progress = 0,
	wait_flag_applied = nil,
	wait_flag_player = nil,
	last_look = nil,
	gameover = false,
}

local PUPPET_XML = "mods/noita_coop/files/entities/puppet_player.xml"
local REVIVE_FRAMES = 150
local REVIVE_RANGE = 28
local DOWNED_HP = 0.04

local FLAG_DOWNED = 1
local FLAG_POLY = 2
local FLAG_FIRE = 4
local FLAG_INVIS = 8
local FLAG_ELEC = 16
local FLAG_WET = 32

local SPRAY_FLUSH_FRAMES = 3
local SPRAY_MAX_PARTICLES = 250

local COSMETIC_TAGS = { "lukki_enable", "player_amulet", "player_amulet_gem", "player_hat", "player_hat2", "player_hat2_shadow" }

local arm_cache = {}

local function find_child(entity, name)
	local children = EntityGetAllChildren(entity)
	if not children then return nil end
	for _, c in ipairs(children) do
		if EntityGetName(c) == name then return c end
	end
	return nil
end

local function player_arm(player)
	local a = arm_cache[player]
	if a and EntityGetIsAlive(a) then return a end
	a = find_child(player, "arm_r")
	arm_cache[player] = a
	return a
end

local function main_sprite(entity)
	return EntityGetFirstComponent(entity, "SpriteComponent", "lukki_disable")
		or EntityGetFirstComponent(entity, "SpriteComponent", "character")
		or EntityGetFirstComponent(entity, "SpriteComponent")
end

function P.revive_enabled()
	return U.setting("revive", true)
end

------------------------------------------------------------------------------------------------
-- local -> network

local function held_item_look(player)
	local inv = EntityGetFirstComponent(player, "Inventory2Component")
	if not inv then return "", 0, 0 end
	local item = ComponentGetValue2(inv, "mActiveItem")
	if not item or item == 0 or not EntityGetIsAlive(item) then return "", 0, 0 end
	local sprite = EntityGetFirstComponentIncludingDisabled(item, "SpriteComponent", "item")
		or EntityGetFirstComponentIncludingDisabled(item, "SpriteComponent")
	if not sprite then return "", 0, 0 end
	return ComponentGetValue2(sprite, "image_file") or "",
		ComponentGetValue2(sprite, "offset_x") or 0,
		ComponentGetValue2(sprite, "offset_y") or 0
end

local function cosmetics_mask(player)
	local mask = 0
	for i, tag in ipairs(COSMETIC_TAGS) do
		local c = EntityGetFirstComponentIncludingDisabled(player, "SpriteComponent", tag)
		if c and ComponentGetIsEnabled(c) then mask = mask + 2 ^ (i - 1) end
	end
	return mask
end

local function send_state(player, frame)
	local x, y, rot, sx = EntityGetTransform(player)
	local vx, vy = U.vel_of(player)
	local anim = ""
	local sprite = main_sprite(player)
	if sprite then anim = ComponentGetValue2(sprite, "rect_animation") or "" end
	local arot, asy = 0, 1
	local arm = player_arm(player)
	if arm then
		local _, _, r, _, s = EntityGetTransform(arm)
		arot, asy = r or 0, s or 1
	end
	local hp, mhp = 0, 0
	local dm = EntityGetFirstComponentIncludingDisabled(player, "DamageModelComponent")
	if dm then
		hp = ComponentGetValue2(dm, "hp")
		mhp = ComponentGetValue2(dm, "max_hp")
	end
	local flags = 0
	if P.downed then flags = flags + FLAG_DOWNED end
	if EntityHasTag(player, "polymorphed_player") then flags = flags + FLAG_POLY end
	if U.is_burning(player) then flags = flags + FLAG_FIRE end
	if U.effect_count(player, "INVISIBILITY") > 0 then flags = flags + FLAG_INVIS end
	if U.effect_count(player, "ELECTROCUTION") > 0 then flags = flags + FLAG_ELEC end
	if U.effect_count(player, "WET") > 0 then flags = flags + FLAG_WET end
	net.send_unreliable({ "ps", U.round(x * 10), U.round(y * 10), U.round(vx), U.round(vy), (sx or 1) < 0 and -1 or 1, anim,
		U.round(arot * 1000), (asy or 1) < 0 and -1 or 1, hp, mhp, flags })

	if frame % 10 == 0 then
		local img, ox, oy = held_item_look(player)
		local cos = (frame % 30 == 0 or not P.last_look) and cosmetics_mask(player) or (P.last_look and P.last_look[5] or 0)
		local look = { "pa", img, ox, oy, cos }
		local last = P.last_look
		if not last or last[2] ~= img or last[3] ~= ox or last[4] ~= oy or last[5] ~= cos then
			P.last_look = look
			net.send(look)
		end
	end
end

-- Flask spraying: the liquid that leaves the held flask is re-emitted on the other machine right away,
-- instead of waiting for the terrain sync to carry it over pixel by pixel.
local spray = { item = nil, counts = nil, acc = {}, last_flush = 0, x = 0, y = 0, vx = 0, vy = 0 }

local function material_counts(item)
	local mi = EntityGetFirstComponentIncludingDisabled(item, "MaterialInventoryComponent")
	if not mi then return nil end
	local counts = ComponentGetValue2(mi, "count_per_material_type")
	if type(counts) ~= "table" then return nil end
	return counts, mi
end

local function flush_spray(frame)
	spray.last_flush = frame
	local list, total = {}, 0
	for id, amount in pairs(spray.acc) do
		local n = math.floor(amount)
		if n >= 1 then
			n = math.min(n, SPRAY_MAX_PARTICLES - total)
			if n <= 0 then break end
			local name = CellFactory_GetName(id)
			if name and name ~= "" then
				list[#list + 1] = name
				list[#list + 1] = n
				total = total + n
			end
			spray.acc[id] = amount - math.floor(amount)
		end
	end
	if #list > 0 and net.synced then
		net.send({ "spr", U.round(spray.x * 10), U.round(spray.y * 10), U.round(spray.vx), U.round(spray.vy), list })
	end
end

local function update_spray(player, frame)
	local controls = EntityGetFirstComponent(player, "ControlsComponent")
	local inv = EntityGetFirstComponent(player, "Inventory2Component")
	local item = inv and ComponentGetValue2(inv, "mActiveItem") or 0
	local firing = controls and ComponentGetValue2(controls, "mButtonDownFire")
	local potion = item ~= 0 and EntityGetIsAlive(item) and EntityGetFirstComponentIncludingDisabled(item, "PotionComponent")
	if not firing or not potion then
		if next(spray.acc) then flush_spray(frame) end
		spray.item, spray.counts, spray.acc = nil, nil, {}
		return
	end
	local counts, mi = material_counts(item)
	if not counts then return end
	if spray.item ~= item or not spray.counts then
		spray.item, spray.counts = item, counts
		return
	end
	local prev = spray.counts
	spray.counts = counts
	-- drinking also empties the flask: don't mirror that
	local drank = ComponentGetValue2(mi, "last_frame_drank") or -100
	if frame - drank <= 3 then return end
	local any = false
	for i = 1, math.max(#prev, #counts) do
		local d = (prev[i] or 0) - (counts[i] or 0)
		if d > 0 then
			spray.acc[i - 1] = (spray.acc[i - 1] or 0) + d
			any = true
		end
	end
	if any then
		local x, y = EntityGetTransform(item)
		local ax, ay = ComponentGetValue2(controls, "mAimingVectorNormalized")
		local rx, ry = ComponentGetValue2(controls, "mAimingVector")
		ax, ay = ax or 0, ay or 0
		local len = math.sqrt((rx or 0) ^ 2 + (ry or 0) ^ 2)
		local coeff = ComponentGetValue2(potion, "spray_velocity_coeff") or 75
		local minf = ComponentGetValue2(potion, "spray_velocity_normalized_min") or 0.5
		local speed = coeff * 2 * math.max(minf, math.min(1, len / 100))
		spray.x, spray.y = x + ax * 4, y + ay * 4
		spray.vx, spray.vy = ax * speed, ay * speed
	end
	if frame - spray.last_flush >= SPRAY_FLUSH_FRAMES then flush_spray(frame) end
end

local function on_spray(m)
	local x, y, vx, vy, list = m[2] / 10, m[3] / 10, m[4] or 0, m[5] or 0, m[6]
	if type(list) ~= "table" or not DoesWorldExistAt(x - 4, y - 4, x + 4, y + 4) then return end
	for i = 1, #list - 1, 2 do
		local name, n = list[i], tonumber(list[i + 1]) or 0
		if type(name) == "string" and n > 0 then
			GameCreateParticle(name, x, y, math.min(n, SPRAY_MAX_PARTICLES), vx, vy, false, false, true)
		end
	end
end

------------------------------------------------------------------------------------------------
-- network -> puppet

local function kill_puppet()
	if P.puppet and EntityGetIsAlive(P.puppet) then EntityKill(P.puppet) end
	P.puppet = nil
	P.parts = nil
	P.cx, P.cy = nil, nil
end

local function apply_look(puppet, parts, look)
	if not look then return end
	if parts.held_sprite then
		local img = look[2]
		if img and img ~= "" then
			ComponentSetValue2(parts.held_sprite, "image_file", img)
			ComponentSetValue2(parts.held_sprite, "offset_x", look[3] or 0)
			ComponentSetValue2(parts.held_sprite, "offset_y", look[4] or 0)
			ComponentSetValue2(parts.held_sprite, "visible", true)
		else
			ComponentSetValue2(parts.held_sprite, "visible", false)
		end
		EntityRefreshSprite(parts.held, parts.held_sprite)
	end
	local mask = look[5] or 0
	for i, tag in ipairs(COSMETIC_TAGS) do
		local on = math.floor(mask / 2 ^ (i - 1)) % 2 == 1
		local c = EntityGetFirstComponentIncludingDisabled(puppet, "SpriteComponent", tag)
		if c then EntitySetComponentIsEnabled(puppet, c, on) end
		if tag == "lukki_enable" then
			local normal = EntityGetFirstComponentIncludingDisabled(puppet, "SpriteComponent", "lukki_disable")
			if normal then EntitySetComponentIsEnabled(puppet, normal, not on) end
		end
	end
end

local function ensure_puppet(x, y)
	if P.puppet and EntityGetIsAlive(P.puppet) then return P.puppet end
	P.puppet = nil
	if not DoesWorldExistAt(x - 16, y - 16, x + 16, y + 16) then return nil end
	local e = EntityLoad(PUPPET_XML, x, y)
	if not e or e == 0 then return nil end
	P.puppet = e
	local arm = find_child(e, "arm_r")
	local held = find_child(e, "held_item")
	P.parts = {
		arm = arm,
		held = held,
		held_sprite = held and EntityGetFirstComponentIncludingDisabled(held, "SpriteComponent", "coop_held") or nil,
		sprites = EntityGetComponentIncludingDisabled(e, "SpriteComponent", "character") or {},
		dm = EntityGetFirstComponentIncludingDisabled(e, "DamageModelComponent"),
		anim = nil,
	}
	P.cx, P.cy = x, y
	apply_look(e, P.parts, P.remote_look)
	return e
end

local function set_puppet_alpha(puppet, parts, alpha)
	local list = EntityGetComponentIncludingDisabled(puppet, "SpriteComponent") or {}
	for _, s in ipairs(list) do
		ComponentSetValue2(s, "alpha", alpha)
		EntityRefreshSprite(puppet, s)
	end
	if parts.held_sprite then
		ComponentSetValue2(parts.held_sprite, "alpha", alpha)
		EntityRefreshSprite(parts.held, parts.held_sprite)
	end
end

local function update_puppet_effects(puppet, parts, flags, frame)
	local burning = bit.band(flags, FLAG_FIRE) ~= 0
	if burning or parts.burning then
		U.show_burning(puppet, burning, frame)
		parts.burning = burning
	end
	local invis = bit.band(flags, FLAG_INVIS) ~= 0
	if invis ~= (parts.invis or false) then
		parts.invis = invis
		set_puppet_alpha(puppet, parts, invis and 0.2 or 1)
	end
	if invis then return end
	local x, y = P.cx, P.cy
	if bit.band(flags, FLAG_ELEC) ~= 0 and frame % 3 == 0 then
		GameCreateParticle("spark_electric", x + math.random(-5, 5), y - math.random(0, 12), 1,
			math.random(-40, 40), math.random(-40, 40), true, false, true)
	end
	if bit.band(flags, FLAG_WET) ~= 0 and frame % 12 == 0 then
		GameCreateParticle("water", x + math.random(-3, 3), y - math.random(2, 10), 1, 0, 20, true, false, false)
	end
end

local function update_puppet(frame)
	local r = P.remote
	if not r or not net.synced then
		if P.puppet then kill_puppet() end
		return
	end
	local age = math.min(frame - r.frame, 6)
	local tx = r.x + r.vx / 60 * age
	local ty = r.y + r.vy / 60 * age
	local puppet = ensure_puppet(tx, ty)
	if not puppet then return end
	if not P.cx or U.dist2(P.cx, P.cy, tx, ty) > 250 * 250 then
		P.cx, P.cy = tx, ty
	else
		P.cx = P.cx + (tx - P.cx) * 0.4
		P.cy = P.cy + (ty - P.cy) * 0.4
	end
	local downed = r.flags % 2 == 1
	local rot = downed and (math.pi / 2) * r.sx or 0
	EntitySetTransform(puppet, P.cx, P.cy, rot, r.sx, 1)
	local parts = P.parts
	if parts.arm then EntitySetTransform(parts.arm, P.cx, P.cy, r.arot, 1, r.asy) end
	if parts.held then EntitySetTransform(parts.held, P.cx, P.cy, r.arot, 1, r.asy) end
	if r.anim ~= "" and r.anim ~= parts.anim then
		parts.anim = r.anim
		for _, s in ipairs(parts.sprites) do
			ComponentSetValue2(s, "rect_animation", r.anim)
			ComponentSetValue2(s, "next_rect_animation", r.anim)
		end
	end
	if parts.dm and r.mhp > 0 then
		ComponentSetValue2(parts.dm, "max_hp", r.mhp)
		ComponentSetValue2(parts.dm, "hp", math.max(r.hp, DOWNED_HP))
	end
	update_puppet_effects(puppet, parts, r.flags or 0, frame)
end

------------------------------------------------------------------------------------------------
-- downed / revive

local function set_controls(player, enabled)
	local c = EntityGetFirstComponentIncludingDisabled(player, "ControlsComponent")
	if c then ComponentSetValue2(c, "enabled", enabled) end
end

local function remove_downed_fx(player)
	local children = EntityGetAllChildren(player)
	if not children then return end
	for _, c in ipairs(children) do
		if EntityHasTag(c, "coop_downed_fx") then EntityKill(c) end
	end
end

local function give_effect(player, file, frames, tag)
	local fx = LoadGameEffectEntityTo(player, file)
	if fx and fx ~= 0 then
		if tag then EntityAddTag(fx, tag) end
		local ge = EntityGetFirstComponentIncludingDisabled(fx, "GameEffectComponent")
		if ge and frames then ComponentSetValue2(ge, "frames", frames) end
	end
	return fx
end

local function apply_wait_flag(player)
	local want = net.synced and P.revive_enabled()
	if P.wait_flag_applied == want and P.wait_flag_player == player then return end
	local dm = EntityGetFirstComponentIncludingDisabled(player, "DamageModelComponent")
	if not dm then return end
	ComponentSetValue2(dm, "wait_for_kill_flag_on_death", want)
	P.wait_flag_applied = want
	P.wait_flag_player = player
end

function P.revive(player, hp_fraction, teleport_x, teleport_y)
	if not P.downed then return end
	P.downed = false
	P.revive_progress = 0
	remove_downed_fx(player)
	set_controls(player, not GameIsInventoryOpen())
	local dm = EntityGetFirstComponentIncludingDisabled(player, "DamageModelComponent")
	if dm then
		local mhp = ComponentGetValue2(dm, "max_hp")
		ComponentSetValue2(dm, "hp", math.max(mhp * (hp_fraction or 0.25), DOWNED_HP))
	end
	if teleport_x then
		EntitySetTransform(player, teleport_x, teleport_y)
	end
	give_effect(player, "data/entities/misc/effect_protection_all.xml", 180)
	GamePrint("[Co-op] You have been revived!")
	U.log("revived")
end

local function really_die(player)
	P.gameover = true
	P.downed = false
	remove_downed_fx(player)
	local dm = EntityGetFirstComponentIncludingDisabled(player, "DamageModelComponent")
	if dm then
		ComponentSetValue2(dm, "wait_for_kill_flag_on_death", false)
		ComponentSetValue2(dm, "hp", 0)
		ComponentSetValue2(dm, "kill_now", true)
	end
	P.wait_flag_applied = false
	EntityInflictDamage(player, 10000, "DAMAGE_CURSE", "Your whole party has fallen", "NONE", 0, 0, 0)
end

local function remote_is_downed()
	return P.remote ~= nil and P.remote.flags % 2 == 1
end

local function go_down(player, dm)
	P.downed = true
	P.downed_frame = GameGetFrameNum()
	P.revive_progress = 0
	ComponentSetValue2(dm, "hp", DOWNED_HP)
	give_effect(player, "data/entities/misc/effect_protection_all.xml", -1, "coop_downed_fx")
	set_controls(player, false)
	U.log("downed")
	if remote_is_downed() or not P.remote then
		net.send({ "gameover" })
		really_die(player)
		return
	end
	GamePrintImportant("You are down!", "Your partner can revive you by standing next to you, or by reaching a Holy Mountain.")
end

local POLY_EFFECTS = { "POLYMORPH", "POLYMORPH_RANDOM", "POLYMORPH_UNSTABLE", "POLYMORPH_CESSATION" }

-- the real player is stored inside the polymorph effect; letting the effect run out restores them
local function end_polymorph(body)
	local found = {}
	for _, name in ipairs(POLY_EFFECTS) do
		local ge = GameGetGameEffect(body, name)
		if ge and ge ~= 0 then found[ge] = true end
	end
	for _, child in ipairs(EntityGetAllChildren(body) or {}) do
		for _, ge in ipairs(EntityGetComponentIncludingDisabled(child, "GameEffectComponent") or {}) do
			local eff = tostring(ComponentGetValue2(ge, "effect") or "")
			if string.find(eff, "POLYMORPH", 1, true) then found[ge] = true end
		end
	end
	local ended = false
	for ge in pairs(found) do
		ComponentSetValue2(ge, "frames", 1)
		ended = true
	end
	return ended
end

local function update_polymorphed(body, frame)
	local dm = EntityGetFirstComponentIncludingDisabled(body, "DamageModelComponent")
	if not dm then return end
	apply_wait_flag(body)
	if P.poly_down then
		ComponentSetValue2(dm, "hp", math.max(ComponentGetValue2(dm, "hp"), DOWNED_HP))
		set_controls(body, false)
		if frame - P.poly_down > 30 and (frame - P.poly_down) % 30 == 0 then end_polymorph(body) end
		return
	end
	if P.downed then
		-- a downed player that gets polymorphed is turned straight back
		P.poly_down = frame
		end_polymorph(body)
		return
	end
	if not P.wait_flag_applied or ComponentGetValue2(dm, "hp") > 0 then return end
	if end_polymorph(body) then
		P.poly_down = frame
		ComponentSetValue2(dm, "hp", DOWNED_HP)
		set_controls(body, false)
		U.log("polymorphed body fell; restoring the player to go down")
	else
		ComponentSetValue2(dm, "wait_for_kill_flag_on_death", false)
		P.wait_flag_applied = false
		ComponentSetValue2(dm, "kill_now", true)
		U.log("polymorphed body fell but no polymorph effect was found")
	end
end

local function update_downed(player, frame)
	local dm = EntityGetFirstComponentIncludingDisabled(player, "DamageModelComponent")
	if not dm then return end

	if not P.downed then
		if P.wait_flag_applied and ComponentGetValue2(dm, "hp") <= 0 and not EntityHasTag(player, "polymorphed_player") then
			go_down(player, dm)
		end
		return
	end

	-- downed
	if not net.synced then
		P.revive(player, 0.25)
		return
	end
	ComponentSetValue2(dm, "hp", DOWNED_HP)
	set_controls(player, false)
	if remote_is_downed() then
		net.send({ "gameover" })
		really_die(player)
		return
	end
	local r = P.remote
	if r and P.cx then
		local x, y = EntityGetTransform(player)
		if U.dist2(x, y, P.cx, P.cy) < REVIVE_RANGE * REVIVE_RANGE then
			P.revive_progress = P.revive_progress + 1
			if P.revive_progress >= REVIVE_FRAMES then
				net.send({ "revived" })
				P.revive(player, 0.25)
				return
			end
		else
			P.revive_progress = math.max(0, P.revive_progress - 2)
		end
		if frame % 30 == 0 then
			local biome = BiomeMapGetName(r.x, r.y) or ""
			if string.find(biome, "holymountain", 1, true) then
				net.send({ "revived" })
				P.revive(player, 1.0, r.x, r.y - 4)
				return
			end
		end
	end
end

------------------------------------------------------------------------------------------------

function P.init()
	net.on("ps", function(m)
		P.remote = P.remote or {}
		local r = P.remote
		r.x, r.y = m[2] / 10, m[3] / 10
		r.vx, r.vy = m[4], m[5]
		r.sx = m[6]
		r.anim = m[7] or ""
		r.arot = m[8] / 1000
		r.asy = m[9]
		r.hp, r.mhp = m[10], m[11]
		r.flags = m[12] or 0
		r.frame = GameGetFrameNum()
	end)
	net.on("pa", function(m)
		P.remote_look = m
		if P.puppet and P.parts and EntityGetIsAlive(P.puppet) then apply_look(P.puppet, P.parts, m) end
	end)
	net.on("pdmg", function(m)
		local player = U.local_player()
		if not player or P.downed then return end
		local dmg = tonumber(m[2]) or 0
		if dmg > 0 then
			EntityInflictDamage(player, dmg, "DAMAGE_MELEE", tostring(m[3] or ""), "NONE", 0, 0, 0)
		end
	end)
	net.on("gameover", function()
		local player = U.local_player()
		if player and P.downed then really_die(player) end
	end)
	net.on("revived", function() end)
	net.on("spr", on_spray)
	net.on_connect(function()
		P.last_look = nil
	end)
	net.on_disconnect(function()
		kill_puppet()
		P.remote = nil
	end)
end

function P.update(frame)
	local player = U.local_player()

	-- forwarded melee damage done to the puppet on this machine
	local dmg_lines = U.drain_global("coop_puppet_dmg")
	if dmg_lines and net.synced then
		for _, line in ipairs(dmg_lines) do
			local f = U.split_tabs(line)
			net.send({ "pdmg", tonumber(f[1]) or 0, f[2] or "" })
		end
	end

	if player and not P.gameover then
		local real = U.real_player()
		if real then
			apply_wait_flag(real)
			if P.poly_down then
				P.poly_down = nil
				local dm = EntityGetFirstComponentIncludingDisabled(real, "DamageModelComponent")
				if dm and net.synced and not P.downed then go_down(real, dm) end
			end
			update_downed(real, frame)
		elseif EntityHasTag(player, "polymorphed_player") then
			update_polymorphed(player, frame)
		end
		if net.synced and frame % 2 == 0 then send_state(player, frame) end
		if net.synced then update_spray(player, frame) end
	end
	update_puppet(frame)
end

function P.on_paused_changed(paused)
	local player = U.local_player()
	if not player then return end
	if P.downed then
		set_controls(player, false)
	end
end

function P.is_puppet(entity)
	return entity ~= nil and entity == P.puppet
end

return P
