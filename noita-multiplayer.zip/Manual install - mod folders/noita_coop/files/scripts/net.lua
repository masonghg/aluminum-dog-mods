-- Connection management, framing and message dispatch.
--
-- Two transports carry the same byte stream: direct TCP (host port-forwards) and Steam P2P messages
-- (no port forwarding, Steam friends only). The host accepts both at once.
--
-- Wire format: [u32 len][u8 flags][payload], len counts flags + payload.
-- flags & 1: payload is [u32 raw_len][zstd data]. The (decompressed) payload is a codec-encoded
-- array of messages, each message being an array whose first element is the message type.
local socket = require("lib.socket")
local codec = require("lib.codec")
local zstd = require("lib.zstd")
local U = require("scripts.util")
local steam = require("scripts.steam")

local bit = require("bit")
local band, rshift = bit.band, bit.rshift
local char, byte, sub = string.char, string.byte, string.sub

local net = {
	MAX_PLAYERS = 2,
	role = "off",            -- "off" | "host" | "client"
	status = "offline",
	connected = false,       -- handshake done
	synced = false,          -- both players in game with the same seed
	peer_name = nil,
	peer_ready = false,
	peer_seed = nil,
	local_ready = false,
	local_seed = nil,
	host_seed = nil,         -- client: seed told by the host
	run_id = nil,
	rtt = 0,
	transport = nil,         -- "tcp" | "steam" of the open connection
	target = nil,            -- client: { kind = "tcp", addr, port } or { kind = "steam", id, name }
	listening_tcp = false,
	handlers = {},
	connect_cbs = {},
	disconnect_cbs = {},
	sync_cbs = {},
	welcome_cbs = {},
	bytes_in = 0,
	bytes_out = 0,
}

local COMPRESS_MIN = 600
local MAX_FRAME = 64 * 1024 * 1024
local UNRELIABLE_BACKLOG = 192 * 1024
local BULK_BACKLOG = 96 * 1024
local PING_INTERVAL = 1.0
local TIMEOUT = 20.0
local RECONNECT_INTERVAL = 5.0
local HELLO_TIMEOUT = 10.0
local STEAM_HELLO_TIMEOUT = 15.0

local listener = nil
local conn = nil
local pending = {}            -- host: incoming connections waiting for hello
local batch_rel, batch_unrel = {}, {}
local last_ping = 0
local next_connect = 0
local my_name = "Player"
local listen_port = nil

local function u32(n)
	return char(band(n, 255), band(rshift(n, 8), 255), band(rshift(n, 16), 255), band(rshift(n, 24), 255))
end

local function read_u32(s, pos)
	local a, b, c, d = byte(s, pos, pos + 3)
	return a + b * 256 + c * 65536 + d * 16777216
end

local function make_frame(messages)
	local payload = codec.encode(messages)
	local flags = 0
	if zstd.ok and #payload > COMPRESS_MIN then
		local c = zstd.compress(payload, 3)
		if c and #c + 4 < #payload then
			payload = u32(#payload) .. c
			flags = 1
		end
	end
	return u32(#payload + 1) .. char(flags) .. payload
end

-- link: a TCP socket or a Steam link (send / recv_available / close, TCP also poll_connect)
local function new_conn(link, state, kind)
	return {
		link = link,
		kind = kind,
		state = state,          -- "connecting" | "hello" | "open"
		inbuf = "",
		out = {},
		out_head = 1,
		out_off = 0,
		backlog = 0,
		last_recv = U.now(),
		created = U.now(),
		close_after_flush = false,
	}
end

local function conn_queue(c, data)
	c.out[#c.out + 1] = data
	c.backlog = c.backlog + #data
	net.bytes_out = net.bytes_out + #data
end

local function conn_flush(c)
	while c.out_head <= #c.out do
		local data = c.out[c.out_head]
		local n, err = c.link:send(data, c.out_off)
		if n == nil then return false, err end
		if n == 0 then break end
		c.out_off = c.out_off + n
		c.backlog = c.backlog - n
		if c.out_off >= #data then
			c.out[c.out_head] = nil
			c.out_head = c.out_head + 1
			c.out_off = 0
		end
	end
	if c.out_head > #c.out then
		c.out = {}
		c.out_head = 1
	end
	return true
end

-- Returns list of decoded message batches, or nil, err.
local function conn_read(c)
	local data, err = c.link:recv_available()
	if data == nil then return nil, err end
	if #data > 0 then
		c.last_recv = U.now()
		net.bytes_in = net.bytes_in + #data
		c.inbuf = c.inbuf .. data
	end
	local batches = nil
	local buf = c.inbuf
	local pos = 1
	local total = #buf
	while total - pos + 1 >= 4 do
		local len = read_u32(buf, pos)
		if len < 1 or len > MAX_FRAME then return nil, "bad frame length " .. len end
		if total - pos + 1 < 4 + len then break end
		local flags = byte(buf, pos + 4)
		local payload = sub(buf, pos + 5, pos + 3 + len)
		pos = pos + 4 + len
		if band(flags, 1) ~= 0 then
			if not zstd.ok then return nil, "peer sent compressed data but zstd is unavailable" end
			local raw_len = read_u32(payload, 1)
			payload = zstd.decompress(sub(payload, 5), raw_len)
			if not payload then return nil, "decompression failed" end
		end
		local ok, msgs = pcall(codec.decode, payload)
		if not ok then return nil, "decode failed: " .. tostring(msgs) end
		batches = batches or {}
		batches[#batches + 1] = msgs
	end
	if pos > 1 then c.inbuf = sub(buf, pos) end
	return batches or {}
end

local function send_direct(c, msg)
	conn_queue(c, make_frame({ msg }))
end

local function describe_target(t)
	if not t then return "?" end
	if t.kind == "steam" then return (t.name or "Steam friend") .. " (Steam)" end
	return tostring(t.addr) .. ":" .. tostring(t.port)
end
net.describe_target = describe_target

------------------------------------------------------------------------------------------------
-- public API

function net.on(msg_type, fn)
	net.handlers[msg_type] = fn
end

function net.on_connect(fn) net.connect_cbs[#net.connect_cbs + 1] = fn end
function net.on_disconnect(fn) net.disconnect_cbs[#net.disconnect_cbs + 1] = fn end
function net.on_sync(fn) net.sync_cbs[#net.sync_cbs + 1] = fn end
-- client: fn(seed, run_id, target, host_name) whenever a host accepts us
function net.on_welcome(fn) net.welcome_cbs[#net.welcome_cbs + 1] = fn end

-- Reliable, ordered.
function net.send(msg)
	if not net.connected then return end
	batch_rel[#batch_rel + 1] = msg
end

-- Dropped if the connection is congested (for frequent state updates).
function net.send_unreliable(msg)
	if not net.connected then return end
	batch_unrel[#batch_unrel + 1] = msg
end

-- True if there is room for large, non-urgent data (terrain, entity snapshots).
function net.can_send_bulk()
	return net.connected and conn ~= nil and conn.backlog < BULK_BACKLOG
end

function net.backlog()
	return conn and conn.backlog or 0
end

local function fire(list, ...)
	for _, fn in ipairs(list) do
		local ok, err = pcall(fn, ...)
		if not ok then U.log("callback error: " .. tostring(err)) end
	end
end

local function update_synced()
	local was = net.synced
	net.synced = net.connected and net.local_ready and net.peer_ready
		and net.local_seed ~= nil and net.local_seed == net.peer_seed
	if net.synced ~= was then
		U.log("synced = " .. tostring(net.synced))
		fire(net.sync_cbs, net.synced)
	end
end

local function host_waiting_status()
	local via = {}
	if steam.ok then via[#via + 1] = "Steam" end
	if net.listening_tcp then via[#via + 1] = "port " .. tostring(listen_port) end
	return "hosting (" .. table.concat(via, " + ") .. "), waiting for your friend"
end

local function drop_connection(reason)
	if conn then
		conn.link:close()
		conn = nil
	end
	local was_connected = net.connected
	net.connected = false
	net.transport = nil
	net.peer_ready = false
	net.peer_seed = nil
	batch_rel, batch_unrel = {}, {}
	net.status = reason or "disconnected"
	U.log("connection dropped: " .. tostring(reason))
	update_synced()
	if was_connected then
		GamePrint("[Co-op] Disconnected: " .. tostring(reason))
		fire(net.disconnect_cbs, reason)
	end
	next_connect = U.now() + RECONNECT_INTERVAL
end

local function established(c, peer_name)
	conn = c
	c.state = "open"
	net.connected = true
	net.transport = c.kind
	net.peer_name = peer_name
	net.status = "connected"
	last_ping = 0
	U.log("connected to " .. tostring(peer_name) .. " via " .. tostring(c.kind))
	GamePrint("[Co-op] Connected to " .. tostring(peer_name) .. (c.kind == "steam" and " (Steam)" or ""))
	fire(net.connect_cbs)
	if net.local_ready then
		net.send({ "ready", net.local_seed })
	end
end

function net.set_local_ready(seed)
	net.local_ready = true
	net.local_seed = seed
	if net.connected then net.send({ "ready", seed }) end
	update_synced()
end

------------------------------------------------------------------------------------------------
-- built-in messages

local host_handle_hello

local function handle_builtin(t, m)
	if t == "hello" and net.role == "host" and conn.kind == "steam" then
		-- the partner's game restarted and reuses the old Steam session: start over with a fresh link
		local peer = conn.link.id
		drop_connection("partner restarted their game")
		local c = new_conn(steam.new_link(peer), "hello", "steam")
		if host_handle_hello(c, { m }) ~= "accepted" then pending[#pending + 1] = c end
		return true
	elseif t == "ping" then
		net.send({ "pong", m[2] })
		return true
	elseif t == "pong" then
		net.rtt = U.now() - (m[2] or U.now())
		return true
	elseif t == "ready" then
		net.peer_ready = true
		net.peer_seed = m[2]
		if net.local_seed and m[2] ~= net.local_seed then
			if net.role == "client" then
				if not net.reloading then
					GamePrintImportant("Co-op: different world", "Start a NEW GAME and pick 'Co-op: Join' to load " .. tostring(net.peer_name) .. "'s world.")
				end
			else
				GamePrintImportant("Co-op: different world", tostring(net.peer_name) .. " is in a different world - their game will restart into yours.")
			end
			U.log("seed mismatch local=" .. tostring(net.local_seed) .. " peer=" .. tostring(m[2]))
		end
		update_synced()
		return true
	elseif t == "bye" then
		drop_connection("partner left: " .. tostring(m[2]))
		return true
	end
	return false
end

local function dispatch(batches)
	local c0 = conn
	for _, msgs in ipairs(batches) do
		for _, m in ipairs(msgs) do
			if not conn or conn ~= c0 then return end
			local t = m[1]
			if not handle_builtin(t, m) then
				local h = net.handlers[t]
				if h then
					local ok, err = pcall(h, m)
					if not ok then U.log("handler '" .. tostring(t) .. "' error: " .. tostring(err)) end
				end
			end
		end
	end
end

------------------------------------------------------------------------------------------------
-- host side

function host_handle_hello(c, msgs)
	for _, m in ipairs(msgs) do
		if m[1] == "hello" then
			local proto, name, query = m[2], m[3], m[4]
			if proto ~= U.PROTOCOL then
				send_direct(c, { "reject", "Version mismatch: host uses co-op protocol " .. U.PROTOCOL .. ", you use " .. tostring(proto) .. ". Both players need the same version of the mod." })
				c.close_after_flush = true
				return "rejected"
			end
			if not net.host_seed then
				send_direct(c, { "reject", "Host is not in a game yet." })
				c.close_after_flush = true
				return "rejected"
			end
			if query then
				send_direct(c, { "welcome", U.PROTOCOL, net.host_seed, my_name, net.run_id })
				c.close_after_flush = true
				return "query"
			end
			if conn and U.now() - conn.last_recv > 4 then
				drop_connection("replaced by a new connection")
			end
			if conn then
				send_direct(c, { "reject", "Server full (max " .. net.MAX_PLAYERS .. " players)." })
				c.close_after_flush = true
				return "rejected"
			end
			send_direct(c, { "welcome", U.PROTOCOL, net.host_seed, my_name, net.run_id })
			established(c, name)
			return "accepted"
		end
	end
	return nil
end

local function host_accept_steam(peer)
	local link = steam.new_link(peer)
	U.log("incoming Steam connection from " .. tostring(link.peer))
	pending[#pending + 1] = new_conn(link, "hello", "steam")
	return link
end

local function host_update()
	if listener then
		while true do
			local s = listener:accept()
			if not s then break end
			U.log("incoming connection from " .. tostring(s.peer))
			pending[#pending + 1] = new_conn(s, "hello", "tcp")
		end
	end
	local keep = {}
	for _, c in ipairs(pending) do
		local alive = true
		local batches = conn_read(c)
		if not batches then
			alive = false
		elseif not c.close_after_flush then
			for _, msgs in ipairs(batches) do
				local r = host_handle_hello(c, msgs)
				if r == "accepted" then alive = false break end -- moved to conn
				if c.close_after_flush then break end
			end
		end
		if c.close_after_flush then
			conn_flush(c)
			if c.backlog <= 0 or U.now() - c.created > 3 then
				c.link:close()
				alive = false
			end
		elseif alive and U.now() - c.created > HELLO_TIMEOUT then
			c.link:close()
			alive = false
		end
		if alive then keep[#keep + 1] = c end
	end
	pending = keep
	if not conn and not net.connected then net.status = host_waiting_status() end
end

------------------------------------------------------------------------------------------------
-- client side

local function open_client_conn(t)
	if t.kind == "steam" then
		if not steam.ok then return nil, "Steam unavailable" end
		local c = new_conn(steam.new_link(t.id), "hello", "steam")
		send_direct(c, { "hello", U.PROTOCOL, my_name, false })
		return c
	end
	local s, err = socket.connect(t.addr, t.port)
	if not s then return nil, err end
	return new_conn(s, "connecting", "tcp")
end

local function client_update()
	if conn then return end
	local t = net.target
	if not t then
		net.status = "not connected - press F9 to pick who to join"
		return
	end
	local c = net._connecting
	if not c then
		if U.now() < next_connect then return end
		next_connect = U.now() + RECONNECT_INTERVAL
		local err
		c, err = open_client_conn(t)
		if not c then
			net.status = "connect failed: " .. tostring(err)
			return
		end
		net._connecting = c
		net.status = "connecting to " .. describe_target(t)
	end
	if c.state == "connecting" then
		local st, err = c.link:poll_connect(0)
		if st == "connected" then
			c.state = "hello"
			c.created = U.now()
			send_direct(c, { "hello", U.PROTOCOL, my_name, false })
		elseif st == "failed" or U.now() - c.created > 8 then
			c.link:close()
			net._connecting = nil
			net.status = "cannot reach " .. describe_target(t) .. " (retrying)"
			return
		else
			return
		end
	end
	local ok, ferr = conn_flush(c)
	if not ok then
		c.link:close(); net._connecting = nil
		net.status = "connection error: " .. tostring(ferr)
		return
	end
	local batches, err = conn_read(c)
	if not batches then
		c.link:close(); net._connecting = nil
		net.status = "connection lost: " .. tostring(err)
		return
	end
	for bi, msgs in ipairs(batches) do
		for _, m in ipairs(msgs) do
			if m[1] == "welcome" then
				net._connecting = nil
				net.run_id = m[5]
				net.host_seed = m[3]
				established(c, m[4])
				fire(net.welcome_cbs, m[3], m[5], t, m[4])
				-- anything that arrived in the same read after the welcome
				local rest = {}
				local found = false
				for _, mm in ipairs(msgs) do
					if found then rest[#rest + 1] = mm end
					if mm == m then found = true end
				end
				local later = { rest }
				for j = bi + 1, #batches do later[#later + 1] = batches[j] end
				dispatch(later)
				return
			elseif m[1] == "reject" then
				c.link:close(); net._connecting = nil
				net.status = "rejected: " .. tostring(m[2])
				GamePrint("[Co-op] Host rejected the connection: " .. tostring(m[2]))
				next_connect = U.now() + 15
				return
			end
		end
	end
	local limit = c.kind == "steam" and STEAM_HELLO_TIMEOUT or HELLO_TIMEOUT
	if U.now() - c.created > limit then
		c.link:close(); net._connecting = nil
		net.status = describe_target(t) .. " did not answer (retrying)"
	end
end

------------------------------------------------------------------------------------------------

local function init_zstd()
	if zstd.ok or net._zstd_tried then return end
	net._zstd_tried = true
	if not zstd.init(U.MOD_PATH .. "bin/libzstd.dll") then
		U.log("zstd unavailable: " .. tostring(zstd.err))
	end
end

-- Starts hosting (also usable in the middle of a run). Listens on TCP and, if available, Steam.
function net.start_host(port)
	init_zstd()
	net.role = "host"
	listen_port = port
	if not listener then
		local l, err = socket.listen(port)
		if l then
			listener = l
			net.listening_tcp = true
		else
			U.log("cannot listen on port " .. tostring(port) .. ": " .. tostring(err))
			if not steam.ok then
				net.status = "cannot host: " .. tostring(err)
				GamePrint("[Co-op] " .. net.status)
				return false
			end
			GamePrint("[Co-op] Port " .. tostring(port) .. " unavailable (" .. tostring(err) .. "), hosting over Steam only")
		end
	end
	if steam.ok then
		steam.accept_any = true
		steam.on_unknown = host_accept_steam
	end
	net.status = host_waiting_status()
	U.log(net.status)
	return true
end

-- role "host": port is the TCP port to listen on. role "client": target is where to connect.
function net.init(role, addr, port, name, target)
	my_name = name or "Player"
	init_zstd()
	if role == "host" then
		return net.start_host(port)
	end
	net.role = role
	if role == "client" then
		net.target = target or (addr and { kind = "tcp", addr = addr, port = port }) or nil
		net.status = net.target and ("connecting to " .. describe_target(net.target)) or "not connected"
		next_connect = 0
	end
	return true
end

-- Client: switch to another host (e.g. a Steam invite arrived). Drops the current connection.
function net.set_target(target)
	net.role = "client"
	if net._connecting then net._connecting.link:close() net._connecting = nil end
	if conn then drop_connection("switching host") end
	net.target = target
	next_connect = 0
	net.status = "connecting to " .. describe_target(target)
end

function net.retry_now()
	next_connect = 0
end

-- Called every frame (also while paused).
function net.pump()
	steam.pump()
	if net.role == "host" then
		host_update()
	elseif net.role == "client" then
		client_update()
	end
	if not conn then return end

	local ok, err = conn_flush(conn)
	if not ok then drop_connection(err) return end

	local batches
	batches, err = conn_read(conn)
	if not batches then drop_connection(err) return end
	if #batches > 0 then dispatch(batches) end
	if not conn then return end

	local t = U.now()
	if t - conn.last_recv > TIMEOUT then
		drop_connection("timed out")
		return
	end
	if t - last_ping > PING_INTERVAL then
		last_ping = t
		net.send({ "ping", t })
	end
end

-- Called once per frame after all modules queued their messages.
function net.flush()
	if not conn then
		batch_rel, batch_unrel = {}, {}
		return
	end
	local msgs = batch_rel
	if #batch_unrel > 0 and conn.backlog < UNRELIABLE_BACKLOG then
		for _, m in ipairs(batch_unrel) do msgs[#msgs + 1] = m end
	end
	batch_rel, batch_unrel = {}, {}
	if #msgs > 0 then
		local ok, frame = pcall(make_frame, msgs)
		if ok then
			conn_queue(conn, frame)
		else
			U.log("encode error: " .. tostring(frame))
		end
	end
	local ok, err = conn_flush(conn)
	if not ok then drop_connection(err) end
end

function net.shutdown(reason)
	if conn then
		pcall(function()
			send_direct(conn, { "bye", reason or "quit" })
			conn_flush(conn)
		end)
		conn.link:close()
		conn = nil
	end
	if listener then listener:close() listener = nil end
	net.listening_tcp = false
	net.connected = false
	net.synced = false
end

-- During world setup (blocking): asks every target at once for the host's seed.
-- targets: list of { kind = "tcp", addr, port } / { kind = "steam", id, name }.
-- Returns seed, run_id, target, host_name or nil, err.
function net.query_any(targets, name, timeout)
	init_zstd()
	timeout = timeout or 4
	local start = U.now()
	local qs = {}
	for _, t in ipairs(targets) do
		local q = { t = t }
		if t.kind == "steam" then
			if steam.ok then
				q.c = new_conn(steam.new_link(t.id), "hello", "steam")
				send_direct(q.c, { "hello", U.PROTOCOL, name, true })
			else
				q.err = "Steam unavailable"
			end
		else
			local s, err = socket.connect(t.addr, t.port)
			if s then q.c = new_conn(s, "connecting", "tcp") else q.err = "cannot reach host (" .. tostring(err) .. ")" end
		end
		qs[#qs + 1] = q
	end
	local result = nil
	local last_err = #targets == 0 and "no host to ask" or nil
	while not result and U.now() - start < timeout do
		steam.pump()
		local active = 0
		for _, q in ipairs(qs) do
			local c = q.c
			if c and not q.done then
				active = active + 1
				if c.state == "connecting" then
					local st, err = c.link:poll_connect(0)
					if st == "connected" then
						c.state = "hello"
						send_direct(c, { "hello", U.PROTOCOL, name, true })
					elseif st == "failed" then
						q.done, q.err = true, "cannot reach host (" .. tostring(err) .. ")"
					end
				end
				if c.state == "hello" and not q.done then
					local ok, ferr = conn_flush(c)
					local batches, rerr = nil, ferr
					if ok then batches, rerr = conn_read(c) end
					if not batches then
						q.done, q.err = true, tostring(rerr)
					else
						for _, msgs in ipairs(batches) do
							for _, m in ipairs(msgs) do
								if m[1] == "welcome" and not result then
									result = { m[3], m[5], q.t, m[4] }
								elseif m[1] == "reject" then
									q.done, q.err = true, tostring(m[2])
								end
							end
						end
					end
				end
			end
			if q.err then last_err = q.err end
		end
		if active == 0 then break end
		if not result then U.sleep_ms(15) end
	end
	for _, q in ipairs(qs) do
		if q.c then q.c.link:close() end
	end
	if result then return result[1], result[2], result[3], result[4] end
	return nil, last_err or "host did not answer"
end

-- Single TCP host version of query_any.
function net.query_seed(addr, port, name, timeout)
	local seed, run_id = net.query_any({ { kind = "tcp", addr = addr, port = port } }, name, timeout)
	return seed, run_id
end

return net
