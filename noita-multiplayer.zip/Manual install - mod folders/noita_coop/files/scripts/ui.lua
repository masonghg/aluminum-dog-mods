-- On-screen info: connection status, partner name tag / off-screen pointer, downed state,
-- and the F9 co-op menu (host this world / invite / join a Steam friend / connect by IP).
local net = require("scripts.net")
local U = require("scripts.util")
local steam = require("scripts.steam")

local UI = { gui = nil, players = nil, entities = nil, worldsync = nil, show_stats = false,
	menu_open = false, actions = nil, friends = {}, friends_at = -1000 }

local OPT_NON_INTERACTIVE = 2
local KEY_F9 = 66
local KEY_F10 = 67

local function world_to_gui(gui, wx, wy)
	local cx, cy, cw, ch = GameGetCameraBounds()
	local sw, sh = GuiGetScreenDimensions(gui)
	return (wx - cx) / cw * sw, (wy - cy) / ch * sh, sw, sh
end

local function text(gui, x, y, s, r, g, b, a)
	GuiOptionsAddForNextWidget(gui, OPT_NON_INTERACTIVE)
	GuiZSetForNextWidget(gui, -100)
	if r then GuiColorSetForNextWidget(gui, r, g, b, a or 1) end
	GuiText(gui, x, y, s)
end

local function centered(gui, x, y, s, r, g, b, a)
	local w = GuiGetTextDimensions(gui, s)
	text(gui, x - w / 2, y, s, r, g, b, a)
end

function UI.init(players, entities, worldsync, actions)
	UI.gui = GuiCreate()
	UI.players = players
	UI.entities = entities
	UI.worldsync = worldsync
	UI.actions = actions or {}
end

-- While the menu is open the player can't move or shoot, so clicking buttons doesn't fire the wand.
local function set_player_controls(enabled)
	local player = U.local_player()
	if not player then return end
	if enabled and UI.players and UI.players.downed then return end
	local c = EntityGetFirstComponentIncludingDisabled(player, "ControlsComponent")
	if c then ComponentSetValue2(c, "enabled", enabled) end
end

function UI.set_menu(open)
	if UI.menu_open == open then return end
	UI.menu_open = open
	UI.friends_at = -1000
	set_player_controls(not open)
end

local function draw_menu(gui, frame, sw, sh)
	local A = UI.actions
	local w, x = 220, math.floor(sw / 2 - 110)
	local y0 = 40
	local lines = {}
	local function line(s, r, g, b) lines[#lines + 1] = { "text", s, r, g, b } end
	local function button(s, fn) lines[#lines + 1] = { "button", s, fn } end

	line("NOITA CO-OP  (F9 to close)", 1, 0.85, 0.4)
	local mode = A.game_mode == "host" and "Co-op: Host game" or (A.game_mode == "join" and "Co-op: Join game" or "normal game")
	line("This run: " .. mode .. ",  role: " .. tostring(net.role), 0.8, 0.8, 0.8)
	line("Status: " .. tostring(net.synced and ("playing with " .. tostring(net.peer_name)) or net.status), 0.8, 0.8, 0.8)
	line("Steam: " .. (steam.ok and "ready" or ("off - " .. tostring(steam.err))), 0.8, 0.8, 0.8)
	line(" ")

	if net.role ~= "host" and not net.connected then
		button("[ Host this world ]", A.host)
	end
	local hosting = net.role == "host"
	if hosting and steam.ok then
		button(steam.lobby and "[ Invite a Steam friend ]" or "[ Invite a Steam friend ] (lobby starting...)", A.invite)
	end
	if not (hosting and net.connected) then
		if not hosting then
			button("[ Connect to " .. tostring(A.host_ip) .. ":" .. tostring(A.port) .. " ]", A.join_ip)
		end
		if steam.ok then
			if frame - UI.friends_at > 120 then
				UI.friends_at = frame
				local ok, list = pcall(A.friends)
				UI.friends = ok and list or {}
			end
			if #UI.friends == 0 then
				line("No Steam friends are playing Noita right now.", 0.6, 0.6, 0.6)
			end
			for i, f in ipairs(UI.friends) do
				if i > 8 then break end
				if hosting and not f.lobby_key then
					local label = "[ Invite " .. tostring(f.name) .. " ]" .. (A.is_invited(f) and "  (invited)" or "")
					button(label, function() A.invite_friend(f) end)
				else
					local label = "[ Join " .. tostring(f.name) .. " ]" .. (f.lobby_key and "  (hosting)" or "")
					button(label, function() A.join(A.steam_target(f)) end)
				end
			end
			if hosting and #UI.friends > 0 then
				line("Invited friends join even from the main menu: they just", 0.6, 0.6, 0.6)
				line("start a game (New Game or Continue) within 10 minutes.", 0.6, 0.6, 0.6)
			end
		end
	end
	if net.role == "client" and not net.connected then
		button("[ Retry now ]", A.retry)
	end
	line(" ")
	line("Joining someone in a different world restarts your game", 0.6, 0.6, 0.6)
	line("straight into their world (your current run is replaced).", 0.6, 0.6, 0.6)

	local h = #lines * 11 + 8
	GuiZSetForNextWidget(gui, -90)
	GuiImageNinePiece(gui, 9000, x - 6, y0 - 6, w + 12, h)
	local y = y0
	for i, l in ipairs(lines) do
		if l[1] == "text" then
			text(gui, x, y, l[2], l[3], l[4], l[5], 1)
		else
			GuiZSetForNextWidget(gui, -110)
			if GuiButton(gui, 9100 + i, x, y, l[2]) and l[3] then
				local ok, err = pcall(l[3])
				if not ok then U.log("menu action error: " .. tostring(err)) end
				UI.friends_at = -1000
			end
		end
		y = y + 11
	end
end

function UI.draw(frame)
	local gui = UI.gui
	if not gui then return end
	GuiStartFrame(gui)
	local sw, sh = GuiGetScreenDimensions(gui)

	-- F9 co-op menu, F10 debug stats
	if InputIsKeyJustDown and InputIsKeyJustDown(KEY_F9) then UI.set_menu(not UI.menu_open) end
	if InputIsKeyJustDown and InputIsKeyJustDown(KEY_F10) then UI.show_stats = not UI.show_stats end
	if UI.menu_open then draw_menu(gui, frame, sw, sh) end

	local status
	if net.synced then
		status = "Co-op: " .. tostring(net.peer_name) .. " - " .. math.floor(net.rtt * 1000) .. " ms"
	elseif net.connected then
		if not net.peer_ready then
			status = "Co-op: connected to " .. tostring(net.peer_name) .. ", waiting for them to spawn"
		elseif net.peer_seed ~= net.local_seed then
			status = "Co-op: DIFFERENT WORLD - the client must start a New Game while the host is in game"
		else
			status = "Co-op: connected"
		end
	else
		status = "Co-op: " .. tostring(net.status)
	end
	if net.transport == "steam" then status = status .. " (Steam)" end
	if not UI.menu_open then status = status .. "   [F9: co-op menu]" end
	text(gui, 4, sh - 12, status, 1, 1, 1, 0.65)

	if UI.show_stats then
		local E = UI.entities and UI.entities.stats or {}
		local W = UI.worldsync or {}
		local lines = {
			string.format("in %.1f KB  out %.1f KB  backlog %d B", net.bytes_in / 1024, net.bytes_out / 1024, net.backlog()),
			string.format("entities %d  physics %d  puppets %d  copies %d", E.tracked or 0, E.physics or 0, E.puppets or 0, E.copies or 0),
			string.format("dupes absorbed %d  merged %d  re-copied %d  healed %d", E.absorbed or 0, E.merged or 0, E.recopied or 0, E.healed or 0),
			string.format("terrain check: compared %d  repairs asked %d  sent %d  drift %d/%d  fire %d", W.checked or 0,
				W.repairs_requested or 0, W.repairs_sent or 0, W.drift_repairs or 0, W.drift_checked or 0, W.ignited or 0),
			string.format("terrain: %s  sent %d  applied %d  pending %d  enc %.2f ms  dec %.2f ms",
				W.enabled and "on" or ("off" .. (W.failed and (" (" .. W.failed .. ")") or "")),
				W.sent or 0, W.applied or 0, W.pending_count or 0, W.avg_encode_ms or 0, W.avg_decode_ms or 0),
		}
		for i, l in ipairs(lines) do text(gui, 4, sh - 12 - 10 * i, l, 0.8, 1, 0.8, 0.8) end
	end

	if not net.synced then return end
	local P = UI.players
	local r = P.remote

	-- partner marker
	if r and P.cx then
		local gx, gy = world_to_gui(gui, P.cx, P.cy)
		local name = tostring(net.peer_name or "Partner")
		local downed = r.flags % 2 == 1
		if gx >= 0 and gx <= sw and gy >= 0 and gy <= sh then
			centered(gui, gx, gy - 30, name, downed and 1 or 0.7, downed and 0.3 or 0.9, downed and 0.3 or 1, 0.9)
			if downed then centered(gui, gx, gy - 40, "DOWN", 1, 0.2, 0.2, 1) end
		else
			local player = U.local_player()
			local dist = ""
			if player then
				local x, y = EntityGetTransform(player)
				dist = " " .. math.floor(math.sqrt(U.dist2(x, y, r.x, r.y)) / 10) .. "m"
			end
			local label = name .. dist .. (downed and " (DOWN)" or "")
			local cx, cy = sw / 2, sh / 2
			local dx, dy = gx - cx, gy - cy
			local scale = math.min((sw / 2 - 40) / math.max(math.abs(dx), 1), (sh / 2 - 20) / math.max(math.abs(dy), 1))
			local ex, ey = cx + dx * scale, cy + dy * scale
			local arrow = (math.abs(dx) > math.abs(dy)) and (dx > 0 and ">" or "<") or (dy > 0 and "v" or "^")
			centered(gui, ex, ey, arrow .. " " .. label, downed and 1 or 0.7, downed and 0.3 or 0.9, downed and 0.3 or 1, 0.9)
		end
	end

	-- downed state
	if P.downed then
		centered(gui, sw / 2, sh * 0.3, "YOU ARE DOWN", 1, 0.25, 0.25, 1)
		centered(gui, sw / 2, sh * 0.3 + 12, "Your partner can revive you by standing next to you, or by reaching a Holy Mountain", 1, 1, 1, 0.8)
		if P.revive_progress > 0 then
			centered(gui, sw / 2, sh * 0.3 + 24, "Reviving... " .. math.floor(P.revive_progress / 150 * 100) .. "%", 0.5, 1, 0.5, 1)
		end
	elseif r and r.flags % 2 == 1 then
		centered(gui, sw / 2, sh * 0.3, tostring(net.peer_name) .. " is DOWN - stand next to them to revive", 1, 0.5, 0.3, 1)
	end
end

return UI
