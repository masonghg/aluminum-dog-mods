-- Shared run events: perks, orbs, hearts, fungal shifts, time of day, gold, Holy Mountain anger.
-- Hooks appended to the game's pickup / fungal / temple scripts push lines into the "coop_evq" global.
local net = require("scripts.net")
local U = require("scripts.util")

local EV = {
	gold_last = nil,      -- wallet value last seen / set here
	gold_player = nil,    -- the player entity that wallet belongs to
	gold_pending = 0,     -- partner gold that arrived while we had no wallet (polymorphed)
	glob_sent = {},
}

local FORCED_ORB = "mods/noita_coop/files/entities/forced_orb.xml"
local perk_lib_loaded = false
local GLOB_EVERY = 60
-- run globals kept equal on both machines (numbers: the higher value wins)
local SHARED_GLOBALS = { "TEMPLE_SPAWN_GUARDIAN", "STEVARI_DEATHS", "TEMPLE_PEACE_WITH_GODS" }

local function partner()
	return net.peer_name or "Your partner"
end

local function grant_perk(perk_id)
	local player = U.real_player()
	if not player then return end
	if not perk_lib_loaded then
		dofile_once("data/scripts/perks/perk.lua")
		perk_lib_loaded = true
	end
	local x, y = EntityGetTransform(player)
	local e = perk_spawn(x, y - 8, perk_id, true)
	if e and e ~= 0 then
		EntityAddTag(e, "coop_ignore")
		perk_pickup(e, player, nil, true, false)
	end
end

local function grant_orb(orb_id)
	local player = U.real_player()
	if not player then return end
	if GameGetOrbCollectedThisRun(orb_id) then return end
	local x, y = EntityGetTransform(player)
	local orb = EntityLoad(FORCED_ORB, x, y)
	local oc = EntityGetFirstComponentIncludingDisabled(orb, "OrbComponent")
	if oc then ComponentSetValue2(oc, "orb_id", orb_id) end
	local ic = EntityGetFirstComponentIncludingDisabled(orb, "ItemComponent")
	if ic then ComponentSetValue2(ic, "auto_pickup", true) end
	GamePickUpInventoryItem(player, orb, true)
end

local function grant_heart(dmax, dhp, full, dcap)
	local player = U.real_player()
	if not player then return end
	local dm = EntityGetFirstComponentIncludingDisabled(player, "DamageModelComponent")
	if not dm then return end
	local max_hp = ComponentGetValue2(dm, "max_hp")
	local hp = ComponentGetValue2(dm, "hp")
	local cap = ComponentGetValue2(dm, "max_hp_cap")
	if dcap and dcap ~= 0 and cap > 0 then
		cap = cap + dcap
		ComponentSetValue2(dm, "max_hp_cap", cap)
	end
	local new_max = max_hp + dmax
	if cap > 0 then new_max = math.min(new_max, cap) end
	ComponentSetValue2(dm, "max_hp", new_max)
	if full then
		hp = new_max
	else
		hp = math.min(hp + math.max(dhp, 0), new_max)
	end
	ComponentSetValue2(dm, "hp", hp)
end

local function apply_fungal(iter, pairs_list)
	for i = 1, #pairs_list - 1, 2 do
		local from = CellFactory_GetType(pairs_list[i])
		local to = CellFactory_GetType(pairs_list[i + 1])
		if from >= 0 and to >= 0 and from ~= to then
			ConvertMaterialEverywhere(from, to)
		end
	end
	local cur = tonumber(GlobalsGetValue("fungal_shift_iteration", "0")) or 0
	if iter and iter > cur then GlobalsSetValue("fungal_shift_iteration", tostring(iter)) end
	GlobalsSetValue("fungal_shift_last_frame", tostring(GameGetFrameNum()))
	GamePrintImportant("Reality shifts...", partner() .. " caused a fungal shift", "data/ui_gfx/decorations/3piece_fungal_shift.png")
end

local function world_state()
	local ws = GameGetWorldStateEntity()
	if not ws or ws == 0 then return nil end
	return EntityGetFirstComponent(ws, "WorldStateComponent")
end

------------------------------------------------------------------------------------------------
-- shared wallet: every change to one player's gold (pickups, shop purchases) is applied to the other's

local function wallet()
	local player = U.real_player()
	if not player then return nil end
	local w = EntityGetFirstComponentIncludingDisabled(player, "WalletComponent")
	if not w then return nil end
	if EV.gold_player ~= player then
		-- new player entity (run start, polymorph ended): take its value as is, never as a change
		EV.gold_player = player
		EV.gold_last = ComponentGetValue2(w, "money")
	end
	return w
end

local function set_money(w, money)
	money = math.max(math.floor(money + 0.5), 0)
	ComponentSetValue2(w, "money", money)
	EV.gold_last = money
end

-- send our own change since last time first, so it isn't swallowed by the partner's arriving on top
local function flush_local(w)
	local money = ComponentGetValue2(w, "money")
	local delta = money - (EV.gold_last or money)
	EV.gold_last = money
	if delta ~= 0 and net.synced and U.setting("shared_gold", true) then net.send({ "gold", delta }) end
	return money
end

local function apply_gold(delta)
	local w = wallet()
	if not w then
		EV.gold_pending = EV.gold_pending + delta
		return
	end
	local money = flush_local(w)
	if ComponentGetValue2(w, "mHasReachedInf") then return end
	set_money(w, money + delta)
end

local function update_gold()
	local w = wallet()
	if not w then return end
	if EV.gold_pending ~= 0 then
		local d = EV.gold_pending
		EV.gold_pending = 0
		apply_gold(d)
	end
	flush_local(w)
end

local function send_gold_total()
	local w = wallet()
	if w and U.setting("shared_gold", true) then net.send({ "goldsync", flush_local(w) }) end
end

------------------------------------------------------------------------------------------------
-- Holy Mountain anger: whoever breaks a Holy Mountain angers the gods for both players, the guardian
-- (synced like any other creature) hunts both, and later mountains spawn it on both machines

local function merge_global(name, value)
	local mine = GlobalsGetValue(name, "")
	local a, b = tonumber(mine), tonumber(value)
	local best = value
	if a and b then best = (a >= b) and mine or value
	elseif mine ~= "" and value == "" then best = mine end
	if best ~= mine then GlobalsSetValue(name, best) end
	-- what the partner has now; if ours is higher the next send_globals tells them
	EV.glob_sent[name] = value
end

local function send_globals(all)
	for _, name in ipairs(SHARED_GLOBALS) do
		local v = GlobalsGetValue(name, "")
		if v ~= "" and (all or EV.glob_sent[name] ~= v) then
			EV.glob_sent[name] = v
			net.send({ "glob", name, v })
		end
	end
end

local function partner_angered_gods(temple_id)
	if GlobalsGetValue("TEMPLE_PEACE_WITH_GODS", "") == "1" then return end
	GlobalsSetValue("TEMPLE_SPAWN_GUARDIAN", "1")
	EV.glob_sent.TEMPLE_SPAWN_GUARDIAN = "1"
	local leak = "TEMPLE_LEAKED_" .. tostring(temple_id)
	if GlobalsGetValue(leak, "") ~= "1" then
		GlobalsSetValue(leak, "1")
		GamePrintImportant("$logdesc_temple_spawn_guardian", partner() .. " angered the gods")
	end
end

function EV.init()
	net.on("ev", function(m)
		local kind = m[2]
		if kind == "perk" then
			if not U.setting("shared_perks", true) then return end
			GamePrint("[Co-op] " .. partner() .. " picked a perk - you get it too")
			grant_perk(m[3])
		elseif kind == "orb" then
			if not U.setting("shared_orbs", true) then return end
			GamePrint("[Co-op] " .. partner() .. " found an orb")
			grant_orb(tonumber(m[3]) or 0)
		elseif kind == "heart" then
			if not U.setting("shared_hearts", true) then return end
			grant_heart(tonumber(m[3]) or 0, tonumber(m[4]) or 0, m[5] == true, tonumber(m[6]) or 0)
		elseif kind == "fungal" then
			apply_fungal(tonumber(m[3]), m[4] or {})
		elseif kind == "temple" then
			partner_angered_gods(m[3])
		end
	end)

	net.on("gold", function(m)
		if not U.setting("shared_gold", true) then return end
		local d = tonumber(m[2])
		if d and d ~= 0 then apply_gold(d) end
	end)
	-- on (re)connect both wallets become the larger of the two
	net.on("goldsync", function(m)
		if not U.setting("shared_gold", true) then return end
		local w = wallet()
		local total = tonumber(m[2])
		if w and total and total > flush_local(w) and not ComponentGetValue2(w, "mHasReachedInf") then
			set_money(w, total)
		end
	end)
	net.on("glob", function(m)
		if type(m[2]) == "string" and type(m[3]) == "string" then merge_global(m[2], m[3]) end
	end)
	net.on_sync(function(synced)
		if not synced then return end
		update_gold()
		send_gold_total()
		send_globals(true)
	end)

	net.on("tod", function(m)
		if net.role == "host" then return end
		local c = world_state()
		if not c then return end
		local t = ComponentGetValue2(c, "time")
		if math.abs(t - m[2]) > 0.002 then ComponentSetValue2(c, "time", m[2]) end
		if m[3] then ComponentSetValue2(c, "day_count", m[3]) end
	end)
end

function EV.update(frame)
	local lines = U.drain_global("coop_evq")
	if lines and net.synced then
		for _, line in ipairs(lines) do
			local f = U.split_tabs(line)
			local kind = f[1]
			if kind == "perk" then
				net.send({ "ev", "perk", f[2] })
			elseif kind == "orb" then
				net.send({ "ev", "orb", tonumber(f[2]) })
			elseif kind == "heart" then
				net.send({ "ev", "heart", tonumber(f[2]), tonumber(f[3]), f[4] == "1", tonumber(f[5]) })
			elseif kind == "fungal" then
				local list = {}
				for i = 3, #f do list[#list + 1] = f[i] end
				net.send({ "ev", "fungal", tonumber(f[2]), list })
			elseif kind == "temple" then
				net.send({ "ev", "temple", f[2] })
				send_globals(false)
			end
		end
	end

	update_gold()
	if net.synced and frame % GLOB_EVERY == 31 then send_globals(false) end

	if net.synced and net.role == "host" and frame % 180 == 0 then
		local c = world_state()
		if c then
			net.send_unreliable({ "tod", ComponentGetValue2(c, "time"), ComponentGetValue2(c, "day_count") })
		end
	end
end

return EV
