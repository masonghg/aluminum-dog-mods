-- Shared run events: perks, orbs, hearts, fungal shifts, time of day.
-- Hooks appended to the game's pickup / fungal scripts push lines into the "coop_evq" global.
local net = require("scripts.net")
local U = require("scripts.util")

local EV = {}

local FORCED_ORB = "mods/noita_coop/files/entities/forced_orb.xml"
local perk_lib_loaded = false

local function partner()
	return net.peer_name or "Your partner"
end

local function grant_perk(perk_id)
	local player = U.real_player()
	if not player then return end
	if not perk_lib_loaded then
		dofile_once("data/scripts/perks/perk.lua")
		perk_lib_loaded = true
	end
	local x, y = EntityGetTransform(player)
	local e = perk_spawn(x, y - 8, perk_id, true)
	if e and e ~= 0 then
		EntityAddTag(e, "coop_ignore")
		perk_pickup(e, player, nil, true, false)
	end
end

local function grant_orb(orb_id)
	local player = U.real_player()
	if not player then return end
	if GameGetOrbCollectedThisRun(orb_id) then return end
	local x, y = EntityGetTransform(player)
	local orb = EntityLoad(FORCED_ORB, x, y)
	local oc = EntityGetFirstComponentIncludingDisabled(orb, "OrbComponent")
	if oc then ComponentSetValue2(oc, "orb_id", orb_id) end
	local ic = EntityGetFirstComponentIncludingDisabled(orb, "ItemComponent")
	if ic then ComponentSetValue2(ic, "auto_pickup", true) end
	GamePickUpInventoryItem(player, orb, true)
end

local function grant_heart(dmax, dhp, full, dcap)
	local player = U.real_player()
	if not player then return end
	local dm = EntityGetFirstComponentIncludingDisabled(player, "DamageModelComponent")
	if not dm then return end
	local max_hp = ComponentGetValue2(dm, "max_hp")
	local hp = ComponentGetValue2(dm, "hp")
	local cap = ComponentGetValue2(dm, "max_hp_cap")
	if dcap and dcap ~= 0 and cap > 0 then
		cap = cap + dcap
		ComponentSetValue2(dm, "max_hp_cap", cap)
	end
	local new_max = max_hp + dmax
	if cap > 0 then new_max = math.min(new_max, cap) end
	ComponentSetValue2(dm, "max_hp", new_max)
	if full then
		hp = new_max
	else
		hp = math.min(hp + math.max(dhp, 0), new_max)
	end
	ComponentSetValue2(dm, "hp", hp)
end

local function apply_fungal(iter, pairs_list)
	for i = 1, #pairs_list - 1, 2 do
		local from = CellFactory_GetType(pairs_list[i])
		local to = CellFactory_GetType(pairs_list[i + 1])
		if from >= 0 and to >= 0 and from ~= to then
			ConvertMaterialEverywhere(from, to)
		end
	end
	local cur = tonumber(GlobalsGetValue("fungal_shift_iteration", "0")) or 0
	if iter and iter > cur then GlobalsSetValue("fungal_shift_iteration", tostring(iter)) end
	GlobalsSetValue("fungal_shift_last_frame", tostring(GameGetFrameNum()))
	GamePrintImportant("Reality shifts...", partner() .. " caused a fungal shift", "data/ui_gfx/decorations/3piece_fungal_shift.png")
end

local function world_state()
	local ws = GameGetWorldStateEntity()
	if not ws or ws == 0 then return nil end
	return EntityGetFirstComponent(ws, "WorldStateComponent")
end

function EV.init()
	net.on("ev", function(m)
		local kind = m[2]
		if kind == "perk" then
			if not U.setting("shared_perks", true) then return end
			GamePrint("[Co-op] " .. partner() .. " picked a perk - you get it too")
			grant_perk(m[3])
		elseif kind == "orb" then
			if not U.setting("shared_orbs", true) then return end
			GamePrint("[Co-op] " .. partner() .. " found an orb")
			grant_orb(tonumber(m[3]) or 0)
		elseif kind == "heart" then
			if not U.setting("shared_hearts", true) then return end
			grant_heart(tonumber(m[3]) or 0, tonumber(m[4]) or 0, m[5] == true, tonumber(m[6]) or 0)
		elseif kind == "fungal" then
			apply_fungal(tonumber(m[3]), m[4] or {})
		end
	end)

	net.on("tod", function(m)
		if net.role == "host" then return end
		local c = world_state()
		if not c then return end
		local t = ComponentGetValue2(c, "time")
		if math.abs(t - m[2]) > 0.002 then ComponentSetValue2(c, "time", m[2]) end
		if m[3] then ComponentSetValue2(c, "day_count", m[3]) end
	end)
end

function EV.update(frame)
	local lines = U.drain_global("coop_evq")
	if lines and net.synced then
		for _, line in ipairs(lines) do
			local f = U.split_tabs(line)
			local kind = f[1]
			if kind == "perk" then
				net.send({ "ev", "perk", f[2] })
			elseif kind == "orb" then
				net.send({ "ev", "orb", tonumber(f[2]) })
			elseif kind == "heart" then
				net.send({ "ev", "heart", tonumber(f[2]), tonumber(f[3]), f[4] == "1", tonumber(f[5]) })
			elseif kind == "fungal" then
				local list = {}
				for i = 3, #f do list[#list + 1] = f[i] end
				net.send({ "ev", "fungal", tonumber(f[2]), list })
			end
		end
	end

	if net.synced and net.role == "host" and frame % 180 == 0 then
		local c = world_state()
		if c then
			net.send_unreliable({ "tod", ComponentGetValue2(c, "time"), ComponentGetValue2(c, "day_count") })
		end
	end
end

return EV
