-- Creature and item synchronization.
--
-- Every creature / item near a player gets a network id (stored in a VariableStorageComponent "coop_nid").
-- Both machines run the same world generation, so most entities exist on both sides; they are paired
-- ("linked") by file name + origin (where the entity first appeared, which world generation makes the same
-- on both machines even if one copy has wandered off since), falling back to the current position.
-- The partner's id is stored on the entity ("coop_org"), so pairs survive reconnects and saved runs.
-- Entities that only exist on one side get copied with NoitaPatcher's entity serializer; a copy then
-- "absorbs" the local original if that one gets generated later, so nothing exists twice.
--
-- Simulation authority: the player closest to an entity simulates it (host wins near-ties). The other
-- machine turns its copy into a "puppet" (AI and scripts disabled) driven by state updates.
--
-- Kinds: "c" creature, "p" physics object (props, crates, barrels, flasks and wands lying around; their
-- box2d bodies are synced with velocities so kicked things fly the same way), "i" other items.
local net = require("scripts.net")
local U = require("scripts.util")
local bit = require("bit")

local E = {
	np = nil,
	players = nil,
	side = 1,
	by_nid = {},
	by_eid = {},
	remote_map = {},     -- remote nid -> local entry
	remote_rec = {},     -- remote nid -> record of a remote entity we have no local copy of
	remote_rec_count = 0,
	dormant = {},        -- nid -> entry of an entity that was streamed out on this machine
	by_hint = {},        -- remote nid remembered on an entity -> entry (re-pairing after a reconnect)
	superseded = {},     -- nid -> true: replaced by a fresh copy, kill it if it ever streams back in
	removed = {},        -- removal log: entities removed remotely that we might still spawn
	puppets = {},        -- entry -> true
	run_file = nil,
	scan_id = 0,
	stats = { tracked = 0, puppets = 0, copies = 0, physics = 0, absorbed = 0, recopied = 0, healed = 0, merged = 0 },
	nonphys = {},        -- entity ids already checked by the untagged physics scan
	nonphys_count = 0,
}

local SCAN_RADIUS = 1200       -- wide, so entities are found right where they spawn
local PHYS_SCAN_RADIUS = 700
local PHYS_SCAN_EVERY = 8      -- in scans (SCAN_INTERVAL frames each)
local MAX_BODIES = 8
local FLAG_FIRE = 1
local SCAN_INTERVAL = 4
local STATE_INTERVAL = 3
local STATE_RANGE = 1400
local MATCH_RANGE = 48
local ORIGIN_RANGE = 24
local TWIN_RANGE = 96          -- an unpaired local entity this close is used instead of making a copy
local DUP_RANGE = 24
local ABSORB_FRAMES = 2 * 60 * 60
local ABSORB_NEAR = 350        -- enemies appear once the camera gets about this close to where they spawn
local ABSORB_NEAR_FRAMES = 120
local ORPHAN_FRAMES = 300      -- a linked entity the partner stopped simulating gets taken over after this
local VANISH_NEAR = 500
local PUPPET_TIMEOUT = 120
local REVIVE_FRAMES = 60       -- a vanished puppet whose owner still has it near us gets re-copied after this
local DEAD_BAND = 32
local SWEEP_EVERY = 30
local MERGE_RANGE = 40
local BOSS_KEEP = 800          -- the host simulates a boss whenever it is this close, so boss phases never change hands mid-fight
local FREEZE_MARGIN = 150      -- the camera leads the player a bit; Noita freezes enemies this much closer than its freeze distance

local SCAN_TAGS = { "enemy", "mortal", "boss", "necromancer_shop", "item_pickup", "item_physics", "wand", "card_action", "potion",
	"powder_stash", "chest", "gold_nugget", "perk" }
local EXCLUDE_TAGS = { "player_unit", "polymorphed_player", "coop_puppet", "coop_ignore", "coop_replica", "projectile", "fake_orb", "player_projectile" }
local BOSS_TAGS = { "boss", "boss_dragon", "necromancer_shop", "necromancer_super" }
-- perk companions (lukki minion, ghosts, ...) belong to their player; both players get the perk anyway
local EXCLUDE_DIRS = { "data/entities/misc/perks/" }

-- Every spell has its own card file, and which spell a shop / chest rolls depends on each player's unlocks,
-- so the same slot can hold different cards on the two machines: cards pair by slot, not by file.
local CARD_BASE = "data/entities/base_custom_card.xml"
local CARD_DIR = "data/entities/misc/custom_cards/"
local CARD_KEY = "@card"

local function match_key(file)
	if file == CARD_BASE or (file and string.sub(file, 1, #CARD_DIR) == CARD_DIR) then return CARD_KEY end
	return file
end

local PUPPET_DISABLE = {
	AnimalAIComponent = true, AdvancedFishAIComponent = true, FishAIComponent = true, WormAIComponent = true,
	-- never ControlsComponent: the engine's held-item code reads it from every item holder (crashes when off)
	PhysicsAIComponent = true, CrawlerAnimalComponent = true, BossDragonComponent = true, ControlsComponent = false,
	CharacterPlatformingComponent = true, PathFindingComponent = true, AIAttackComponent = true,
	LuaComponent = true, CameraBoundComponent = true, LimbBossComponent = true, IKLimbWalkerComponent = false,
	ItemPickUpperComponent = true, DieIfSpeedBelowComponent = true, AttachToEntityComponent = false,
	ElectricChargeComponent = false, LifetimeComponent = true, WormAttractorComponent = true,
	PhysicsJointComponent = false, TeleportComponent = true, BossHealthBarComponent = false,
	ExplodeOnDamageComponent = true, PotionComponent = false,
}

-- puppet leftovers to switch back on (older versions also switched ControlsComponent off)
local HEAL_TYPES = { ControlsComponent = true }
for t, on in pairs(PUPPET_DISABLE) do
	if on then HEAL_TYPES[t] = true end
end
local PUPPET_BUTTONS = { "mButtonDownFire", "mButtonDownFire2", "mButtonDownThrow", "mButtonDownKick", "mButtonDownLeft",
	"mButtonDownRight", "mButtonDownUp", "mButtonDownDown", "mButtonDownJump", "mButtonDownFly" }

local ON_DEATH = "mods/noita_coop/files/scripts/entity/on_death.lua"

local function new_nid()
	return math.random(1, 268435455) * 4 + E.side
end

local function excluded(e)
	for _, t in ipairs(EXCLUDE_TAGS) do
		if EntityHasTag(e, t) then return true end
	end
	local file = EntityGetFilename(e)
	if file then
		for _, d in ipairs(EXCLUDE_DIRS) do
			if string.sub(file, 1, #d) == d then return true end
		end
	end
	return false
end

local function has_physics(e)
	return EntityGetFirstComponentIncludingDisabled(e, "PhysicsBodyComponent") ~= nil
		or EntityGetFirstComponentIncludingDisabled(e, "PhysicsBody2Component") ~= nil
end

local function is_boss(e)
	for _, t in ipairs(BOSS_TAGS) do
		if EntityHasTag(e, t) then return true end
	end
	return EntityGetFirstComponentIncludingDisabled(e, "BossHealthBarComponent") ~= nil
end

local function kind_of(e)
	if EntityHasTag(e, "enemy") or is_boss(e) then return "c" end
	if has_physics(e) then return "p" end
	if EntityHasTag(e, "mortal") and not EntityHasTag(e, "item_physics") and not EntityHasTag(e, "item_pickup")
		and EntityGetFirstComponentIncludingDisabled(e, "DamageModelComponent") then
		return "c"
	end
	return "i"
end

-- box2d bodies of an entity (one for most props, several for jointed things like carts)
local function physics_bodies(e)
	if not PhysicsBodyIDGetFromEntity then return nil end
	local ok, bodies = pcall(PhysicsBodyIDGetFromEntity, e)
	if ok and type(bodies) == "table" and #bodies > 0 then return bodies end
	return nil
end

-- Positions / angles / velocities in box2d units, x1000 so they travel as integers.
local function read_bodies(e)
	local bodies = physics_bodies(e)
	if not bodies then return nil end
	local out = {}
	for i = 1, math.min(#bodies, MAX_BODIES) do
		local x, y, a, vx, vy, av = PhysicsBodyIDGetTransform(bodies[i])
		if x == nil then return nil end
		out[i] = { U.round(x * 1000), U.round(y * 1000), U.round(a * 1000), U.round((vx or 0) * 1000),
			U.round((vy or 0) * 1000), U.round((av or 0) * 1000) }
	end
	return out
end

local function write_bodies(e, list)
	if type(list) ~= "table" or #list == 0 then return false end
	local bodies = physics_bodies(e)
	if not bodies then return false end
	for i = 1, math.min(#bodies, #list) do
		local b = list[i]
		PhysicsBodyIDSetTransform(bodies[i], b[1] / 1000, b[2] / 1000, b[3] / 1000, b[4] / 1000, b[5] / 1000, b[6] / 1000)
	end
	return true
end

local function player_pos()
	local p = U.local_player()
	if not p then return nil end
	local x, y = EntityGetTransform(p)
	return x, y
end

local function remote_pos()
	local r = E.players and E.players.remote
	if not r or not net.synced then return nil end
	return r.x, r.y
end

-- Does this machine simulate things at (x, y)?
function E.owns_pos(x, y, lx, ly, rx, ry)
	if not rx then return true end
	if not lx then return false end
	local dl = math.sqrt(U.dist2(x, y, lx, ly))
	local dr = math.sqrt(U.dist2(x, y, rx, ry))
	if net.role == "host" then
		return dl <= dr + DEAD_BAND
	end
	return dl < dr - DEAD_BAND
end

local function owns_entry(entry, x, y, lx, ly, rx, ry)
	if entry.boss and rx and lx then
		local host_x, host_y = lx, ly
		if net.role ~= "host" then host_x, host_y = rx, ry end
		if U.dist2(x, y, host_x, host_y) < BOSS_KEEP * BOSS_KEEP then return net.role == "host" end
	end
	return E.owns_pos(x, y, lx, ly, rx, ry)
end

------------------------------------------------------------------------------------------------
-- entity helpers

local function set_nid_comp(e, nid, file)
	local c = U.var_get(e, "coop_nid")
	if c then
		ComponentSetValue2(c, "value_int", nid)
		ComponentSetValue2(c, "value_string", file or "")
	else
		EntityAddComponent2(e, "VariableStorageComponent", { name = "coop_nid", value_int = nid, value_string = file or "", _tags = "coop" })
	end
end

local function ensure_death_hook(e)
	local comps = EntityGetComponentIncludingDisabled(e, "LuaComponent", "coop")
	if comps and #comps > 0 then
		for _, c in ipairs(comps) do EntitySetComponentIsEnabled(e, c, true) end
		return
	end
	EntityAddComponent2(e, "LuaComponent", { script_death = ON_DEATH, execute_every_n_frame = -1, _tags = "coop" })
end

local function strip_scripts(e)
	local comps = EntityGetAllComponents(e) or {}
	for _, c in ipairs(comps) do
		local t = ComponentGetTypeName(c)
		if t == "LuaComponent" or t == "ItemChestComponent" or t == "ExplodeOnDamageComponent" then
			EntityRemoveComponent(e, c)
		end
	end
end

-- Remove without side effects (no loot, no death scripts).
local function silent_kill(e)
	if not EntityGetIsAlive(e) then return end
	strip_scripts(e)
	EntityKill(e)
end

-- Visible death for a creature puppet, without loot.
local function visual_kill(e)
	if not EntityGetIsAlive(e) then return end
	strip_scripts(e)
	local dm = EntityGetFirstComponentIncludingDisabled(e, "DamageModelComponent")
	if dm then
		ComponentSetValue2(dm, "wait_for_kill_flag_on_death", false)
		ComponentSetValue2(dm, "hp", 0)
		ComponentSetValue2(dm, "kill_now", true)
	else
		EntityKill(e)
	end
end

-- Real death on the simulating machine (death scripts and loot run here and get synced from here).
local function owner_kill(e)
	if not EntityGetIsAlive(e) then return end
	local dm = EntityGetFirstComponentIncludingDisabled(e, "DamageModelComponent")
	if dm then
		ComponentSetValue2(dm, "wait_for_kill_flag_on_death", false)
		ComponentSetValue2(dm, "hp", 0)
		ComponentSetValue2(dm, "kill_now", true)
	else
		EntityKill(e)
	end
end

local function puppetize(entry)
	if entry.puppet then return end
	local e = entry.eid
	entry.puppet = true
	E.puppets[entry] = true
	if entry.kind ~= "c" then return end
	local comps = EntityGetAllComponents(e) or {}
	for _, c in ipairs(comps) do
		local t = ComponentGetTypeName(c)
		if PUPPET_DISABLE[t] and not ComponentHasTag(c, "coop") and ComponentGetIsEnabled(c) then
			EntitySetComponentIsEnabled(e, c, false)
			ComponentAddTag(c, "coop_off")
		end
	end
	-- with its AI off nothing presses buttons any more; release the ones held right now
	-- ("enabled" on a ControlsComponent means "read the local keyboard / gamepad": creatures keep it off)
	local ctrl = EntityGetFirstComponentIncludingDisabled(e, "ControlsComponent")
	if ctrl then
		ComponentSetValue2(ctrl, "enabled", false)
		for _, b in ipairs(PUPPET_BUTTONS) do ComponentSetValue2(ctrl, b, false) end
	end
	local dm = EntityGetFirstComponentIncludingDisabled(e, "DamageModelComponent")
	if dm and not ComponentGetValue2(dm, "wait_for_kill_flag_on_death") then
		ComponentSetValue2(dm, "wait_for_kill_flag_on_death", true)
		ComponentAddTag(dm, "coop_wkf")
	end
	local x, y = EntityGetTransform(e)
	entry.cx, entry.cy = x, y
end

local function restore_components(e)
	for type_name in pairs(HEAL_TYPES) do
		local comps = EntityGetComponentIncludingDisabled(e, type_name, "coop_off")
		if comps then
			for _, c in ipairs(comps) do
				ComponentRemoveTag(c, "coop_off")
				EntitySetComponentIsEnabled(e, c, true)
			end
		end
	end
	-- 1.4.1 switched creature controls over to player input here, which made them copy the player's movement
	local ctrl = EntityGetFirstComponentIncludingDisabled(e, "ControlsComponent")
	if ctrl then
		if ComponentHasTag(ctrl, "coop_ctl") then ComponentRemoveTag(ctrl, "coop_ctl") end
		if ComponentGetValue2(ctrl, "enabled") then ComponentSetValue2(ctrl, "enabled", false) end
	end
	local dm = EntityGetFirstComponentIncludingDisabled(e, "DamageModelComponent", "coop_wkf")
	if dm then
		ComponentRemoveTag(dm, "coop_wkf")
		ComponentSetValue2(dm, "wait_for_kill_flag_on_death", false)
		if ComponentGetValue2(dm, "hp") <= 0 then ComponentSetValue2(dm, "kill_now", true) end
	end
end

local function unpuppetize(entry)
	if not entry.puppet then return end
	entry.puppet = false
	E.puppets[entry] = nil
	local e = entry.eid
	if e and EntityGetIsAlive(e) then restore_components(e) end
end

------------------------------------------------------------------------------------------------
-- bookkeeping

-- Origin (first-seen position) + the partner's nid, kept on the entity so they survive streaming,
-- Noita's own freeze/respawn of far enemies, reconnects and saved runs.
local function set_org_comp(e, ox, oy, rnid)
	if not e or not EntityGetIsAlive(e) then return end
	local s = string.format("%d,%d", U.round(ox or 0), U.round(oy or 0))
	local c = U.var_get(e, "coop_org")
	if c then
		ComponentSetValue2(c, "value_string", s)
		ComponentSetValue2(c, "value_int", rnid or 0)
	else
		EntityAddComponent2(e, "VariableStorageComponent", { name = "coop_org", value_string = s, value_int = rnid or 0, _tags = "coop" })
	end
end

local function read_org_comp(e)
	local c = U.var_get(e, "coop_org")
	if not c then return nil end
	local ox, oy = string.match(ComponentGetValue2(c, "value_string") or "", "^(%-?%d+),(%-?%d+)$")
	if not ox then return nil end
	local hint = ComponentGetValue2(c, "value_int")
	return tonumber(ox), tonumber(oy), (hint and hint ~= 0) and hint or nil
end

local function set_hint(entry, rnid)
	if entry.hint and E.by_hint[entry.hint] == entry then E.by_hint[entry.hint] = nil end
	entry.hint = rnid
	if rnid then E.by_hint[rnid] = entry end
end

local function untrack(entry)
	if entry.eid then E.by_eid[entry.eid] = nil end
	if E.by_nid[entry.nid] == entry then E.by_nid[entry.nid] = nil end
	if entry.rnid and E.remote_map[entry.rnid] == entry then E.remote_map[entry.rnid] = nil end
	if entry.hint and E.by_hint[entry.hint] == entry then E.by_hint[entry.hint] = nil end
	E.puppets[entry] = nil
	E.dormant[entry.nid] = nil
end

local function link(entry, rnid)
	if entry.rnid and E.remote_map[entry.rnid] == entry then E.remote_map[entry.rnid] = nil end
	local other = E.remote_map[rnid]
	if other and other ~= entry then other.rnid = nil end
	entry.rnid = rnid
	entry.linked_at = GameGetFrameNum()
	E.remote_map[rnid] = entry
	entry.rcopy = E.remote_rec[rnid] and E.remote_rec[rnid].rcopy or nil
	if E.remote_rec[rnid] then
		E.remote_rec[rnid] = nil
		E.remote_rec_count = E.remote_rec_count - 1
	end
	if entry.hint ~= rnid then
		set_hint(entry, rnid)
		set_org_comp(entry.eid, entry.ox, entry.oy, rnid)
	end
end

local function near_origin(ax, ay, bx, by)
	return ax and bx and U.dist2(ax, ay, bx, by) < ORIGIN_RANGE * ORIGIN_RANGE
end

local function add_removed(file, x, y, persist, ox, oy)
	if not file or file == "" then return end
	E.removed[#E.removed + 1] = { file = file, x = x, y = y, ox = ox, oy = oy, seen = 0 }
	if persist and E.run_file then
		local f = io.open(E.run_file, "a")
		if f then
			f:write(file, "\t", string.format("%.1f", x), "\t", string.format("%.1f", y))
			if ox then f:write("\t", string.format("%.1f", ox), "\t", string.format("%.1f", oy)) end
			f:write("\n")
			f:close()
		end
	end
end

local function consume_removed(file, x, y, ox, oy)
	local r2 = MATCH_RANGE * MATCH_RANGE
	for i, r in ipairs(E.removed) do
		if r.file == file and (U.dist2(r.x, r.y, x, y) < r2 or near_origin(r.ox, r.oy, ox, oy)) then
			table.remove(E.removed, i)
			return true
		end
	end
	return false
end

-- Best match for (file, kind) among candidates: same origin first, then current position within range.
local function best_match(candidates, file, kind, x, y, ox, oy, range, pos_of)
	local best, best_d = nil, math.huge
	local best_p, best_pd = nil, (range or MATCH_RANGE) ^ 2
	local mk = match_key(file)
	for key, c in pairs(candidates) do
		local cx, cy, cox, coy, ok = pos_of(key, c)
		if ok and c.kind == kind and (c.file == file or match_key(c.file) == mk) then
			if ox and cox then
				local d = U.dist2(cox, coy, ox, oy)
				if d < ORIGIN_RANGE * ORIGIN_RANGE and d < best_d then best, best_d = key, d end
			end
			-- shop cards sit 26 px apart: never pair a card with its neighbour's slot
			if cx and mk ~= CARD_KEY then
				local d = U.dist2(cx, cy, x, y)
				if d < best_pd then best_p, best_pd = key, d end
			end
		end
	end
	return best or best_p
end

local function rec_pos(rnid, rec)
	return rec.x, rec.y, rec.ox, rec.oy, true
end

local function find_remote_record(file, kind, x, y, ox, oy)
	return best_match(E.remote_rec, file, kind, x, y, ox, oy, MATCH_RANGE, rec_pos)
end

local function local_pos(e, entry)
	if entry.rnid or not EntityGetIsAlive(e) then return nil, nil, nil, nil, false end
	local ex, ey = EntityGetTransform(e)
	return ex, ey, entry.ox, entry.oy, true
end

local function find_unlinked_local(file, kind, x, y, ox, oy, range)
	local e = best_match(E.by_eid, file, kind, x, y, ox, oy, range, local_pos)
	return e and E.by_eid[e] or nil
end

-- A copy made from the partner's entity stands in for our own original, which may only get generated
-- here later (world generation runs when an area first loads on this machine).
-- Things that stay where they were generated (items, perks, shop cards) and bosses always match by origin;
-- ordinary enemies only within the absorb window, since a different one may spawn there later.
local function find_absorbing_copy(file, x, y, ox, oy, frame, sticky)
	local r2 = DUP_RANGE * DUP_RANGE
	local mk = match_key(file)
	for e, entry in pairs(E.by_eid) do
		if entry.copy and (entry.file == file or match_key(entry.file) == mk) and EntityGetIsAlive(e) then
			if (sticky or (entry.absorb_until or 0) > frame) and near_origin(entry.ox, entry.oy, ox, oy) then
				entry.absorb_until = nil
				return entry
			end
			if frame - entry.created < 900 and mk ~= CARD_KEY then
				local ex, ey = EntityGetTransform(e)
				if U.dist2(ex, ey, x, y) < r2 then return entry end
			end
		end
	end
	return nil
end

local function announce(entry, x, y)
	net.send({ "esn", entry.nid, entry.kind, entry.file, x, y, entry.rnid or 0, U.round(entry.ox or x), U.round(entry.oy or y),
		entry.copy and 1 or 0 })
end

local function link_back(entry, rnid)
	link(entry, rnid)
	local x, y = entry.lx, entry.ly
	if entry.eid and EntityGetIsAlive(entry.eid) then x, y = EntityGetTransform(entry.eid) end
	announce(entry, x, y)
end

-- Different spells rolled for the same slot: the host's card wins, the client swaps its own for a copy.
local function card_conflict(local_file, remote_file)
	return net.role ~= "host" and local_file ~= remote_file
end

local function drop_local(entry)
	E.superseded[entry.nid] = true
	untrack(entry)
	if entry.eid then silent_kill(entry.eid) end
end

-- A copy is gone (died / removed): the partner's original is gone too, so if our own original only gets
-- generated now it must not come back.
local function remember_removed_copy(entry)
	if entry.copy then add_removed(entry.file, entry.lx, entry.ly, true, entry.ox, entry.oy) end
end

local function track(e, nid, kind, file, x, y, frame, ox, oy, hint)
	local entry = { nid = nid, eid = e, kind = kind, file = file, puppet = false, last_state = -100000,
		created = frame, sx = x, sy = y, lx = x, ly = y, ox = ox or x, oy = oy or y }
	E.by_nid[nid] = entry
	E.by_eid[e] = entry
	set_nid_comp(e, nid, file)
	set_org_comp(e, entry.ox, entry.oy, hint)
	if hint then set_hint(entry, hint) end
	ensure_death_hook(e)
	if kind == "c" and is_boss(e) then entry.boss = true end
	local cb = EntityGetFirstComponentIncludingDisabled(e, "CameraBoundComponent")
	if cb and ComponentGetIsEnabled(cb) then
		if ComponentGetValue2(cb, "freeze_on_max_count_kill") ~= false then
			entry.max_count = ComponentGetValue2(cb, "max_count")
		end
		-- documented in pixels, but enemy files give it squared (160000 = 400 px)
		local d = tonumber(ComponentGetValue2(cb, "distance"))
		if d and d > 0 and ComponentGetValue2(cb, "freeze_on_distance_kill") ~= false then
			entry.freeze_r = d > 2048 and math.sqrt(d) or d
		end
	end
	return entry
end

-- Entities that were saved / frozen while they were puppets keep the disabled AI and "can't die"
-- flag baked in; on their owner that makes an unkillable statue.
local function heal_puppet_leftovers(e)
	local ctrl = EntityGetFirstComponentIncludingDisabled(e, "ControlsComponent")
	local dirty = EntityGetFirstComponentIncludingDisabled(e, "DamageModelComponent", "coop_wkf") ~= nil
		or (ctrl ~= nil and (ComponentHasTag(ctrl, "coop_ctl") or ComponentGetValue2(ctrl, "enabled") == true))
	if not dirty then
		for type_name in pairs(HEAL_TYPES) do
			local comps = EntityGetComponentIncludingDisabled(e, type_name, "coop_off")
			if comps and #comps > 0 then dirty = true break end
		end
	end
	if dirty then
		restore_components(e)
		E.stats.healed = E.stats.healed + 1
	end
	return dirty
end

local function on_new_local(e, frame)
	local x, y = EntityGetTransform(e)
	local comp = U.var_get(e, "coop_nid")
	local file = EntityGetFilename(e)
	local ox, oy, hint
	local nid = nil
	if comp then
		nid = ComponentGetValue2(comp, "value_int")
		local stored_file = ComponentGetValue2(comp, "value_string")
		if stored_file and stored_file ~= "" then file = stored_file end
		heal_puppet_leftovers(e)
		if E.superseded[nid] then
			silent_kill(e)
			return
		end
		local d = E.dormant[nid]
		if d then
			E.dormant[nid] = nil
			if d.dead then
				silent_kill(e)
				return
			end
			d.eid = e
			d.puppet = false
			d.revive_since = nil
			E.by_eid[e] = d
			E.by_nid[nid] = d
			if d.rnid then E.remote_map[d.rnid] = d end
			ensure_death_hook(e)
			return
		end
		-- the id is stale (item dropped from an inventory, Noita respawning a frozen enemy, or a saved run):
		-- re-register, keeping its id, origin and partner when nothing else uses them
		ox, oy, hint = read_org_comp(e)
		if E.by_nid[nid] then nid = nil end
	end
	if not file or file == "" then file = "?" end
	local kind = kind_of(e)
	ox, oy = ox or x, oy or y

	if not comp then
		if consume_removed(file, x, y, ox, oy) then
			silent_kill(e)
			return
		end
		if find_absorbing_copy(file, x, y, ox, oy, frame, kind ~= "c" or is_boss(e)) then
			E.stats.absorbed = E.stats.absorbed + 1
			silent_kill(e)
			return
		end
	end

	local rnid = nil
	if hint and E.remote_rec[hint] then rnid = hint end
	rnid = rnid or find_remote_record(file, kind, x, y, ox, oy)
	if rnid and card_conflict(file, E.remote_rec[rnid].file) then
		-- the record stays: a copy of the host's card gets requested for this slot
		silent_kill(e)
		return
	end
	local entry = track(e, nid or new_nid(), kind, file, x, y, frame, ox, oy, hint)
	if rnid then link(entry, rnid) end
	if net.synced then announce(entry, x, y) end
end

-- An entity we tracked is gone from the world (not via a death we saw).
--  * items / props don't wander off or get frozen: gone near us means really gone (picked up, broken,
--    or every other perk removed by taking one), whoever simulated it
--  * creatures: only the machine simulating it may report that, and only well inside Noita's freeze
--    distance: a puppet vanishing here, or Noita freezing an enemy (too far from the camera, or too many
--    of its kind around) says nothing about the real one
local function on_vanished(entry, d2, file_counts)
	local near = d2 < VANISH_NEAR * VANISH_NEAR
	local authoritative
	if entry.kind == "c" then
		authoritative = not entry.puppet and (entry.mine or not entry.rnid)
		if entry.freeze_r then
			local r = math.max(entry.freeze_r - FREEZE_MARGIN, 0)
			near = near and d2 < r * r
		end
	else
		authoritative = true
	end
	local frozen = entry.max_count and (file_counts[entry.file] or 0) >= entry.max_count - 2
	if near and authoritative and not frozen then
		if net.synced then net.send({ "esg", entry.nid }) end
		remember_removed_copy(entry)
		untrack(entry)
	else
		-- streamed out / frozen: remember it in case it comes back
		if entry.eid then E.by_eid[entry.eid] = nil end
		entry.eid = nil
		entry.puppet = false
		entry.revive_since = nil
		E.puppets[entry] = nil
		E.dormant[entry.nid] = entry
	end
end

-- Our stand-in for a partner entity vanished, but the partner keeps simulating it right next to us:
-- drop ours and ask for a fresh copy instead of leaving an invisible enemy on their screen.
local function supersede(entry, x, y, frame)
	local rnid = entry.rnid
	E.superseded[entry.nid] = true
	E.stats.recopied = E.stats.recopied + 1
	untrack(entry)
	if not rnid then return end
	E.remote_rec[rnid] = { file = entry.file, kind = entry.kind, x = x, y = y, ox = entry.ox, oy = entry.oy, frame = frame }
	E.remote_rec_count = E.remote_rec_count + 1
end

------------------------------------------------------------------------------------------------
-- scanning

local function scan(frame)
	local px, py = player_pos()
	if not px then return end
	E.scan_id = E.scan_id + 1
	local seen = {}
	for _, tag in ipairs(SCAN_TAGS) do
		local list = EntityGetInRadiusWithTag(px, py, SCAN_RADIUS, tag)
		for _, e in ipairs(list) do
			if not seen[e] then
				seen[e] = true
				if not E.by_eid[e] and EntityGetRootEntity(e) == e and not excluded(e) then
					on_new_local(e, frame)
				end
			end
		end
	end
	-- Most furniture / crates / minecarts / pixel-scene props have no tag at all: find anything with a
	-- physics body. Slow and cached, because the radius query returns every entity around.
	if E.scan_id % PHYS_SCAN_EVERY == 0 then
		if E.nonphys_count > 30000 then E.nonphys, E.nonphys_count = {}, 0 end
		local list = EntityGetInRadius(px, py, PHYS_SCAN_RADIUS) or {}
		for _, e in ipairs(list) do
			if not seen[e] and not E.by_eid[e] and not E.nonphys[e] then
				seen[e] = true
				local file = EntityGetFilename(e)
				if EntityGetRootEntity(e) == e and file and file ~= "" and not string.find(file, "ragdoll", 1, true)
					and not excluded(e) and has_physics(e) then
					on_new_local(e, frame)
				else
					E.nonphys[e] = true
					E.nonphys_count = E.nonphys_count + 1
				end
			end
		end
	end

	local rx, ry = remote_pos()
	local player = U.local_player()
	local count, puppets, phys = 0, 0, 0
	local gone = nil
	local file_counts = {}
	for e, entry in pairs(E.by_eid) do
		if not EntityGetIsAlive(e) then
			gone = gone or {}
			gone[#gone + 1] = { entry, U.dist2(entry.lx, entry.ly, px, py) }
		elseif EntityGetRootEntity(e) ~= e then
			-- picked up into some inventory
			gone = gone or {}
			gone[#gone + 1] = { entry, true, true }
		else
			count = count + 1
			if entry.kind == "p" then phys = phys + 1 end
			local x, y = EntityGetTransform(e)
			entry.lx, entry.ly = x, y
			local mine
			if (entry.claim_until or 0) > frame then
				mine = true
			elseif (entry.rclaim_until or 0) > frame then
				mine = false
			else
				mine = owns_entry(entry, x, y, px, py, rx, ry)
				if not mine and entry.rnid and not entry.puppet
					and frame - math.max(entry.last_state, entry.linked_at or 0) > ORPHAN_FRAMES then
					-- the partner has it frozen / unloaded: keep sending it so they get it back
					mine = true
				end
			end
			entry.mine = mine
			if entry.absorb_until then
				if frame > entry.absorb_until then
					entry.absorb_until = nil
				elseif U.dist2(entry.ox, entry.oy, px, py) < ABSORB_NEAR * ABSORB_NEAR then
					entry.absorb_near = (entry.absorb_near or 0) + SCAN_INTERVAL
					if entry.absorb_near >= ABSORB_NEAR_FRAMES then entry.absorb_until = nil end
				end
			end
			if entry.puppet then
				puppets = puppets + 1
				if mine or frame - entry.last_state > PUPPET_TIMEOUT then unpuppetize(entry) end
			elseif entry.kind == "c" and (E.scan_id + entry.nid) % 16 == 0 then
				heal_puppet_leftovers(e)
			end
			if entry.max_count then file_counts[entry.file] = (file_counts[entry.file] or 0) + 1 end
		end
	end
	if gone then
		for _, g in ipairs(gone) do
			local entry, d2, taken = g[1], g[2], g[3]
			if taken then
				if net.synced then net.send({ "esg", entry.nid }) end
				untrack(entry)
			else
				on_vanished(entry, d2, file_counts)
			end
		end
	end
	E.stats.tracked = count
	E.stats.puppets = puppets
	E.stats.physics = phys
end

------------------------------------------------------------------------------------------------
-- state sync

local function send_states(frame)
	local rx, ry = remote_pos()
	if not rx then return end
	local list = {}
	local r2 = STATE_RANGE * STATE_RANGE
	for e, entry in pairs(E.by_eid) do
		if not entry.puppet and entry.mine and EntityGetIsAlive(e) then
			local x, y, rot, sx = EntityGetTransform(e)
			if U.dist2(x, y, rx, ry) < r2 then
				if entry.kind == "c" then
					local vx, vy = U.vel_of(e)
					local hp, mhp = 0, 0
					local dm = EntityGetFirstComponentIncludingDisabled(e, "DamageModelComponent")
					if dm then hp, mhp = ComponentGetValue2(dm, "hp"), ComponentGetValue2(dm, "max_hp") end
					local anim = ""
					local sprite = EntityGetFirstComponent(e, "SpriteComponent")
					if sprite then anim = ComponentGetValue2(sprite, "rect_animation") or "" end
					local flags = U.is_burning(e) and FLAG_FIRE or 0
					list[#list + 1] = { entry.nid, U.round(x * 10), U.round(y * 10), U.round(vx), U.round(vy),
						U.round((rot or 0) * 1000), (sx or 1) < 0 and -1 or 1, hp, mhp, anim, flags }
				elseif entry.kind == "p" then
					local bodies = read_bodies(e)
					local moving = false
					if bodies then
						for _, b in ipairs(bodies) do
							if math.abs(b[4]) + math.abs(b[5]) > 20 or math.abs(b[6]) > 20 then moving = true break end
						end
					end
					local burning = U.is_burning(e)
					local moved = moving or not entry.sent_x or U.dist2(x, y, entry.sent_x, entry.sent_y) > 0.25
						or math.abs((rot or 0) - (entry.sent_rot or 0)) > 0.02
						or burning ~= (entry.sent_burning or false)
					local refresh = frame - (entry.sent_frame or 0) > (burning and 30 or 120)
					if moved or entry.was_moving or refresh then
						entry.sent_x, entry.sent_y, entry.sent_rot, entry.sent_frame = x, y, rot or 0, frame
						entry.sent_burning = burning
						list[#list + 1] = { entry.nid, U.round(x * 10), U.round(y * 10), U.round((rot or 0) * 1000),
							bodies or false, (entry.claim_until or 0) > frame and 1 or 0, burning and FLAG_FIRE or 0 }
					end
					entry.was_moving = moving
					if moving and (entry.claim_until or 0) > frame then
						entry.claim_until = math.max(entry.claim_until, frame + 60)
					end
				else
					local moved = not entry.sent_x or U.dist2(x, y, entry.sent_x, entry.sent_y) > 0.5
					if moved or frame - (entry.sent_frame or 0) > 120 then
						entry.sent_x, entry.sent_y, entry.sent_frame = x, y, frame
						list[#list + 1] = { entry.nid, U.round(x * 10), U.round(y * 10), U.round((rot or 0) * 1000) }
					end
				end
			end
		end
	end
	if #list > 0 then net.send_unreliable({ "es", list }) end
end

local function apply_state(s, frame)
	local rnid = s[1]
	local entry = E.remote_map[rnid]
	if not entry then
		local rec = E.remote_rec[rnid]
		if rec then rec.x, rec.y = s[2] / 10, s[3] / 10 end
		return
	end
	local e = entry.eid
	local x, y = s[2] / 10, s[3] / 10
	local px, py = player_pos()
	-- picked up into an inventory here; the scan reports that shortly
	if e and EntityGetIsAlive(e) and EntityGetRootEntity(e) ~= e then return end
	if not e or not EntityGetIsAlive(e) then
		-- our stand-in is gone (frozen / streamed out) but the owner still sends it: if that's right next
		-- to us, the partner sees something we don't, so get a fresh copy
		if not e and not entry.dead and px and U.dist2(x, y, px, py) < VANISH_NEAR * VANISH_NEAR then
			entry.revive_since = entry.revive_since or frame
			if frame - entry.revive_since >= REVIVE_FRAMES then supersede(entry, x, y, frame) end
		else
			entry.revive_since = nil
		end
		return
	end
	local rx, ry = remote_pos()
	local claimed = entry.kind == "p" and s[6] == 1
	if claimed then
		-- the other player kicked / threw it: their simulation wins for a while (host wins a double claim)
		if (entry.claim_until or 0) > frame and net.role == "host" then return end
		entry.claim_until = nil
		entry.rclaim_until = frame + 120
		entry.mine = false
	elseif (entry.claim_until or 0) > frame then
		return
	elseif (entry.rclaim_until or 0) <= frame and owns_entry(entry, x, y, px, py, rx, ry) then
		return
	end
	entry.last_state = frame
	if entry.kind == "p" then
		entry.burning = bit.band(s[7] or 0, FLAG_FIRE) ~= 0
		puppetize(entry)
		if not write_bodies(e, s[5]) then EntityApplyTransform(e, x, y, s[4] / 1000) end
		return
	end
	if entry.kind == "c" then
		entry.burning = bit.band(s[11] or 0, FLAG_FIRE) ~= 0
		puppetize(entry)
		entry.tx, entry.ty = x, y
		entry.tvx, entry.tvy = s[4], s[5]
		entry.trot = s[6] / 1000
		entry.tsx = s[7]
		local dm = EntityGetFirstComponentIncludingDisabled(e, "DamageModelComponent")
		if dm and s[9] and s[9] > 0 then
			ComponentSetValue2(dm, "max_hp", s[9])
			ComponentSetValue2(dm, "hp", math.max(s[8], 0.0001))
		end
		local anim = s[10]
		if anim and anim ~= "" and anim ~= entry.anim then
			entry.anim = anim
			local sprite = EntityGetFirstComponent(e, "SpriteComponent")
			if sprite then
				ComponentSetValue2(sprite, "rect_animation", anim)
				ComponentSetValue2(sprite, "next_rect_animation", anim)
			end
		end
	else
		local rot = s[4] / 1000
		if EntityGetFirstComponentIncludingDisabled(e, "PhysicsBodyComponent") or EntityGetFirstComponentIncludingDisabled(e, "PhysicsBody2Component") then
			EntityApplyTransform(e, x, y, rot)
		else
			local _, _, _, sx, sy = EntityGetTransform(e)
			EntitySetTransform(e, x, y, rot, sx, sy)
		end
	end
end

-- Whoever kicks a physics object simulates it until it comes to rest, so the kick isn't overwritten by
-- the other machine (which may be "closer" to it but never saw the kick).
local KICK_RANGE = 64          -- generous: prop origins aren't at their centre, and claiming a still prop is harmless
local CLAIM_FRAMES = 180

local function claim(entry, frame)
	entry.claim_until = frame + CLAIM_FRAMES
	entry.rclaim_until = nil
	entry.mine = true
	entry.sent_frame = 0
	unpuppetize(entry)
end

local function check_kick(frame)
	local p = U.local_player()
	if not p then return end
	local ctrl = EntityGetFirstComponent(p, "ControlsComponent")
	if not ctrl then return end
	local kf = ComponentGetValue2(ctrl, "mButtonFrameKick") or 0
	if kf == E.last_kick or frame - kf > 3 then return end
	E.last_kick = kf
	local px, py = EntityGetTransform(p)
	local r2 = KICK_RANGE * KICK_RANGE
	for e, entry in pairs(E.by_eid) do
		if entry.kind == "p" and EntityGetIsAlive(e) then
			local x, y = EntityGetTransform(e)
			if U.dist2(x, y, px, py) < r2 then claim(entry, frame) end
		end
	end
end

local function update_puppets(frame)
	for entry in pairs(E.puppets) do
		local e = entry.eid
		if e and entry.kind == "p" and (entry.burning or entry.shown_burning) and EntityGetIsAlive(e) then
			U.show_burning(e, entry.burning, frame)
			entry.shown_burning = entry.burning
		end
		if e and entry.tx and EntityGetIsAlive(e) and EntityGetRootEntity(e) == e then
			local cx, cy = entry.cx or entry.tx, entry.cy or entry.ty
			local age = math.min(frame - entry.last_state, 6)
			local tx = entry.tx + (entry.tvx or 0) / 60 * age
			local ty = entry.ty + (entry.tvy or 0) / 60 * age
			if U.dist2(cx, cy, tx, ty) > 200 * 200 then
				cx, cy = tx, ty
			else
				cx = cx + (tx - cx) * 0.35
				cy = cy + (ty - cy) * 0.35
			end
			entry.cx, entry.cy = cx, cy
			EntitySetTransform(e, cx, cy, entry.trot or 0, entry.tsx or 1, 1)
			local cd = EntityGetFirstComponentIncludingDisabled(e, "CharacterDataComponent")
			if cd then ComponentSetValue2(cd, "mVelocity", entry.tvx or 0, entry.tvy or 0) end
			if entry.burning or entry.shown_burning then
				U.show_burning(e, entry.burning, frame)
				entry.shown_burning = entry.burning
			end
		end
	end
end

------------------------------------------------------------------------------------------------
-- copies of remote-only entities

-- Our own twin of a partner entity may be sitting there untracked (the scan hasn't reached it yet, or
-- it's an untagged prop the slow physics scan only finds every few scans): pair with it instead of copying.
local function adopt_untracked(rnid, file, x, y, ox, oy, frame)
	local pts = { x, y }
	if ox and oy and (ox ~= x or oy ~= y) then pts[3], pts[4] = ox, oy end
	local mk = match_key(file)
	local radius = TWIN_RANGE
	if mk == CARD_KEY then
		pts = { ox or x, oy or y }
		radius = ORIGIN_RANGE
	end
	for i = 1, #pts, 2 do
		for _, e in ipairs(EntityGetInRadius(pts[i], pts[i + 1], radius) or {}) do
			if not E.by_eid[e] and EntityGetIsAlive(e) and EntityGetRootEntity(e) == e and not excluded(e)
				and match_key(EntityGetFilename(e)) == mk then
				on_new_local(e, frame)
				local entry = E.by_eid[e]
				if entry then
					if entry.rnid == rnid then return true end
					if not entry.rnid then
						link_back(entry, rnid)
						return true
					end
				end
			end
		end
	end
	return false
end

local function resolve_remote_records(frame)
	local px, py = player_pos()
	if not px then return end
	for rnid, rec in pairs(E.remote_rec) do
		-- props: only inside the range our physics scan covers, so our own twin had a chance to be found
		local near = rec.kind == "p" and PHYS_SCAN_RADIUS - 100 or 800
		if U.dist2(rec.x, rec.y, px, py) < near * near and DoesWorldExistAt(rec.x - 8, rec.y - 8, rec.x + 8, rec.y + 8) then
			rec.loaded_at = rec.loaded_at or frame
			if frame - rec.loaded_at >= 30 and (not rec.requested or frame - rec.requested > 300) then
				if not adopt_untracked(rnid, rec.file, rec.x, rec.y, rec.ox, rec.oy, frame) then
					rec.requested = frame
					net.send({ "esr", rnid })
				end
			end
		else
			rec.loaded_at = nil
		end
	end
	-- forget removal-log entries once the place it was generated at has been loaded here for a while
	local keep = {}
	for _, r in ipairs(E.removed) do
		local gx, gy = r.ox or r.x, r.oy or r.y
		if U.dist2(gx, gy, px, py) < 600 * 600 and DoesWorldExistAt(gx - 8, gy - 8, gx + 8, gy + 8) then
			r.seen = r.seen + 1
		end
		if r.seen < 4 then keep[#keep + 1] = r end
	end
	E.removed = keep
end

-- Last line of defence against doubles: the same thing generated on both machines, but too far apart
-- (it fell / wandered before either side saw it) to be paired, so each side copied the other's.
-- Such twins end up right on top of each other, chasing the same player.
--  * host: our original (partner shows a copy of it) next to our copy of a partner original -> drop one pair
--  * both: an unpaired original of ours next to a copy of the same thing -> drop ours
local function dedup_sweep(frame)
	local by_file = {}
	for e, entry in pairs(E.by_eid) do
		-- shop items and perks sit closer together than MERGE_RANGE
		if entry.kind ~= "i" and EntityGetIsAlive(e) and EntityGetRootEntity(e) == e and not string.find(entry.file, "gold", 1, true) then
			local list = by_file[entry.file]
			if not list then
				list = {}
				by_file[entry.file] = list
			end
			list[#list + 1] = entry
		end
	end
	local seen, prev, done = {}, E.dedup_seen or {}, {}
	local is_host = net.role == "host"
	local r2 = MERGE_RANGE * MERGE_RANGE
	for _, list in pairs(by_file) do
		if #list >= 2 then
			for _, b in ipairs(list) do
				if b.copy and b.rnid and not done[b] then
					for _, a in ipairs(list) do
						if a ~= b and not a.copy and not done[a] and a.kind == b.kind then
							local pair_dup = is_host and a.rnid and a.rcopy
							local lone_dup = not a.rnid and frame - a.created >= 60
							if (pair_dup or lone_dup) and U.dist2(a.lx, a.ly, b.lx, b.ly) < r2 then
								local key = a.nid .. ":" .. b.nid
								seen[key] = true
								if prev[key] then
									done[a], done[b] = true, true
									local drop = a
									if pair_dup and a.mine then drop = b end
									if net.synced then net.send({ "esg", drop.nid }) end
									E.superseded[drop.nid] = true
									untrack(drop)
									silent_kill(drop.eid)
									E.stats.merged = E.stats.merged + 1
									U.log("merged doubled " .. tostring(a.file) .. " at " .. math.floor(a.lx) .. "," .. math.floor(a.ly))
									break
								end
							end
						end
					end
				end
			end
		end
	end
	E.dedup_seen = seen
end

local function create_copy(rnid, kind, file, x, y, data, frame, ox, oy)
	local e
	if data and E.np then
		e = EntityCreateNew()
		local ok, err = pcall(E.np.DeserializeEntity, e, data, x, y)
		if not ok then
			U.log("entity deserialize failed (" .. tostring(file) .. "): " .. tostring(err))
			EntityKill(e)
			e = nil
		else
			EntitySetTransform(e, x, y)
		end
	end
	if not e and file and file ~= "" and file ~= "?" then
		local ok, res = pcall(EntityLoad, file, x, y)
		if ok then e = res end
	end
	if not e or e == 0 then return nil end
	restore_components(e)
	local entry = track(e, new_nid(), kind, file, x, y, frame, ox, oy, rnid)
	entry.copy = true
	entry.absorb_until = frame + ABSORB_FRAMES
	link(entry, rnid)
	E.stats.copies = E.stats.copies + 1
	announce(entry, x, y)
	return entry
end

------------------------------------------------------------------------------------------------
-- messages

local function handle_esn(m, frame)
	local rnid, kind, file, x, y, rlink, ox, oy = m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9]
	local rcopy = m[10] == 1
	local known = E.remote_map[rnid]
	if known then
		known.rcopy = rcopy
		return
	end
	if rlink and rlink ~= 0 then
		local entry = E.by_nid[rlink] or E.dormant[rlink]
		if entry and card_conflict(entry.file, file) then
			drop_local(entry)
		elseif entry then
			link(entry, rnid)
			entry.rcopy = rcopy
			return
		end
	end
	-- remembered from an earlier session
	local h = E.by_hint[rnid]
	if h and not h.rnid and not h.dead and E.by_nid[h.nid] == h then
		link_back(h, rnid)
		h.rcopy = rcopy
		return
	end
	local entry = find_unlinked_local(file, kind, x, y, ox, oy)
	if entry and card_conflict(entry.file, file) then
		drop_local(entry)
	elseif entry then
		link_back(entry, rnid)
		entry.rcopy = rcopy
		return
	end
	if not E.remote_rec[rnid] then E.remote_rec_count = E.remote_rec_count + 1 end
	E.remote_rec[rnid] = { file = file, kind = kind, x = x, y = y, ox = ox, oy = oy, frame = frame, rcopy = rcopy }
	if E.remote_rec_count > 4000 then
		local oldest, of = nil, math.huge
		for k, r in pairs(E.remote_rec) do
			if r.frame < of then oldest, of = k, r.frame end
		end
		if oldest then E.remote_rec[oldest] = nil; E.remote_rec_count = E.remote_rec_count - 1 end
	end
end

local function handle_removed_remote(rnid, died)
	local entry = E.remote_map[rnid]
	if entry then
		remember_removed_copy(entry)
		local e = entry.eid
		if e and EntityGetIsAlive(e) and EntityGetRootEntity(e) ~= e then
			-- both players grabbed it at once: it's in an inventory here now, and killing an inventory
			-- item under the engine's feet crashes the inventory GUI
			untrack(entry)
		elseif e and EntityGetIsAlive(e) then
			if died then
				if entry.puppet or entry.kind ~= "c" then
					untrack(entry)
					-- props with health (barrels, boxes) break / explode visibly too
					if entry.kind == "c" or (entry.kind == "p" and EntityGetFirstComponentIncludingDisabled(e, "DamageModelComponent")) then
						visual_kill(e)
					else
						silent_kill(e)
					end
				else
					untrack(entry)
					owner_kill(e)
				end
			else
				untrack(entry)
				silent_kill(e)
			end
		else
			-- streamed out here: kill it when it streams back in
			entry.dead = true
			E.remote_map[rnid] = nil
			if E.by_nid[entry.nid] == entry then E.by_nid[entry.nid] = nil end
			E.dormant[entry.nid] = entry
		end
		return
	end
	local rec = E.remote_rec[rnid]
	if rec then
		E.remote_rec[rnid] = nil
		E.remote_rec_count = E.remote_rec_count - 1
		add_removed(rec.file, rec.x, rec.y, true, rec.ox, rec.oy)
	end
end

function E.init(np, players)
	E.np = np
	E.players = players
	E.side = net.role == "host" and 1 or 2
	math.randomseed(os and os.time and os.time() or 12345)
	for _ = 1, 10 do math.random() end

	net.on("esn", function(m) handle_esn(m, GameGetFrameNum()) end)
	net.on("es", function(m)
		local frame = GameGetFrameNum()
		for _, s in ipairs(m[2] or {}) do apply_state(s, frame) end
	end)
	net.on("esd", function(m) handle_removed_remote(m[2], true) end)
	net.on("esg", function(m) handle_removed_remote(m[2], false) end)
	net.on("esr", function(m)
		local entry = E.by_nid[m[2]]
		if not entry or not entry.eid or not EntityGetIsAlive(entry.eid) or EntityGetRootEntity(entry.eid) ~= entry.eid then return end
		local x, y = EntityGetTransform(entry.eid)
		local data = nil
		if E.np then
			local ok, res = pcall(E.np.SerializeEntity, entry.eid)
			if ok then data = res end
		end
		net.send({ "esf", entry.nid, entry.kind, entry.file, x, y, data or false, U.round(entry.ox or x), U.round(entry.oy or y),
			entry.copy and 1 or 0 })
	end)
	net.on("esf", function(m)
		local rnid, kind, file, x, y, data, ox, oy = m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9]
		local rec = E.remote_rec[rnid]
		if not rec then return end
		ox, oy = ox or rec.ox, oy or rec.oy
		rec.rcopy = m[10] == 1
		local frame = GameGetFrameNum()
		-- our own twin may have spawned / wandered in since the announcement
		local entry = find_unlinked_local(file, kind, x, y, ox, oy, TWIN_RANGE)
		if entry and card_conflict(entry.file, file) then
			drop_local(entry)
		elseif entry then
			link_back(entry, rnid)
			return
		end
		if adopt_untracked(rnid, file, x, y, ox, oy, frame) then return end
		if not E.remote_rec[rnid] then return end
		create_copy(rnid, kind, file, x, y, data or nil, frame, ox, oy)
	end)

	net.on_sync(function(synced)
		if synced then
			E.side = net.role == "host" and 1 or 2   -- the role can change mid-run (F9 menu)
			E.connect_frame = GameGetFrameNum()
			-- links from an older session are meaningless now
			E.remote_map = {}
			E.remote_rec = {}
			E.remote_rec_count = 0
			for _, entry in pairs(E.by_eid) do entry.rnid = nil end
			for _, entry in pairs(E.dormant) do entry.rnid = nil end
			for e, entry in pairs(E.by_eid) do
				if EntityGetIsAlive(e) then
					local x, y = EntityGetTransform(e)
					announce(entry, x, y)
				end
			end
		else
			for entry in pairs(E.puppets) do unpuppetize(entry) end
			E.puppets = {}
		end
	end)
end

function E.load_run_log(run_id)
	if not run_id or not io then return end
	E.run_file = U.MOD_PATH .. "run_" .. tostring(run_id) .. ".log"
	local f = io.open(E.run_file, "r")
	if not f then return end
	local n = 0
	for line in f:lines() do
		local p = U.split_tabs(line)
		local x, y = tonumber(p[2]), tonumber(p[3])
		if p[1] and x and y then
			E.removed[#E.removed + 1] = { file = p[1], x = x, y = y, ox = tonumber(p[4]), oy = tonumber(p[5]), seen = 0 }
			n = n + 1
		end
	end
	f:close()
	U.log("loaded " .. n .. " removal log entries")
end

function E.update(frame)
	-- deaths reported by entity scripts
	local deaths = U.drain_global("coop_deaths")
	if deaths then
		for _, line in ipairs(deaths) do
			local nid = tonumber(line)
			local entry = nid and E.by_nid[nid]
			if entry then
				if net.synced then net.send({ "esd", nid }) end
				remember_removed_copy(entry)
				untrack(entry)
			end
		end
	end

	if frame % SCAN_INTERVAL == 0 then scan(frame) end
	if not net.synced then return end
	check_kick(frame)
	if frame % STATE_INTERVAL == 0 then send_states(frame) end
	update_puppets(frame)
	if frame % 30 == 15 then resolve_remote_records(frame) end
	if frame % SWEEP_EVERY == 7 then dedup_sweep(frame) end
end

-- For projectile replication: network id of a creature this machine simulates.
function E.owned_nid(entity)
	local entry = E.by_eid[entity]
	if entry and not entry.puppet then return entry.nid end
	return nil
end

function E.local_for_remote(rnid)
	local entry = E.remote_map[rnid]
	if entry and entry.eid and EntityGetIsAlive(entry.eid) then return entry.eid end
	return nil
end

return E
