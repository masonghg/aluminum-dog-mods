-- On the remote player's puppet: forward melee / direct hits from locally simulated creatures to the real player.
-- Projectile damage is not forwarded because every projectile is replicated on the other machine anyway.
function damage_received( damage, message, entity_thats_responsible, is_fatal, projectile_thats_responsible )
	if damage <= 0 then return end
	if projectile_thats_responsible ~= nil and projectile_thats_responsible ~= 0 then return end
	if entity_thats_responsible == nil or entity_thats_responsible == 0 then return end
	if EntityHasTag( entity_thats_responsible, "player_unit" ) or EntityHasTag( entity_thats_responsible, "coop_puppet" ) then return end
	local q = GlobalsGetValue( "coop_puppet_dmg", "" )
	GlobalsSetValue( "coop_puppet_dmg", q .. tostring( damage ) .. "\t" .. tostring( message or "" ) .. "\n" )
end
