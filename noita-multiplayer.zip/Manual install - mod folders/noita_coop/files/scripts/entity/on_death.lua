-- Attached to every synchronized entity: reports deaths to the co-op main script.
function death( damage_type_bit_field, damage_message, entity_thats_responsible, drop_items )
	local entity_id = GetUpdatedEntityID()
	local comps = EntityGetComponentIncludingDisabled( entity_id, "VariableStorageComponent" )
	if comps == nil then return end
	for _, c in ipairs( comps ) do
		if ComponentGetValue2( c, "name" ) == "coop_nid" then
			local nid = ComponentGetValue2( c, "value_int" )
			local q = GlobalsGetValue( "coop_deaths", "" )
			GlobalsSetValue( "coop_deaths", q .. tostring( nid ) .. "\n" )
			return
		end
	end
end
