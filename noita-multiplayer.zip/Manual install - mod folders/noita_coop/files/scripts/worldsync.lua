-- Terrain / liquid / powder synchronization through NoitaPatcher's direct world access.
--
-- The world is split into 64x64 areas. The player closest to an area "owns" it: their machine
-- run-length encodes it and sends it whenever it changed. The other machine writes it into its world.
-- Solid cells (box2d physics objects) are never written, and gas / fire is treated as air.
--
-- Burning pixels (oil, wood, grass...) carry a fire flag, so fire on terrain shows up on both machines.
--
-- Areas that changed recently are re-checked first so flowing liquids and digging show up quickly,
-- and sent once more after they settle (the receiver's own simulation keeps moving liquids after each
-- update). On top of that the owner keeps sending fingerprints of settled areas, and the receiver
-- watches the areas it got for local drift; either way it asks for the area again when it differs,
-- so both worlds converge over time.
local ffi = require("ffi")
local bit = require("bit")
local net = require("scripts.net")
local U = require("scripts.util")

local tobit, bxor, rol = bit.tobit, bit.bxor, bit.rol

local W = {
	enabled = false,
	failed = nil,
	entities = nil,
	players = nil,
	sent = 0,
	applied = 0,
	pending_count = 0,
	avg_encode_ms = 1,
	avg_decode_ms = 1,
	checked = 0,
	repairs_requested = 0,
	repairs_sent = 0,
	drift_checked = 0,
	drift_repairs = 0,
	ignited = 0,
}

local AREA = 64
local CELLS = AREA * AREA
local SCAN_HALF_W = 6        -- areas left/right of the player
local SCAN_HALF_H = 4        -- areas above/below the player
local ENCODE_BUDGET_MS = 1.6
local DECODE_BUDGET_MS = 1.6
local MAX_PENDING = 6000
local HOT_FRAMES = 120       -- an area that changed is re-checked first for this long
local HOT_RECHECK = 3        -- ... every this many frames
local SETTLE_RESEND = 30     -- a hot area unchanged this long is sent once more
local SETTLED_FRAMES = 60    -- fingerprints are only sent for areas unchanged this long
local HASH_INTERVAL = 30     -- frames between fingerprint batches
local HASH_BATCH = 48
local HASH_RANGE = 1000      -- only areas this close to the other player
local REPAIR_COOLDOWN = 150  -- frames before the same area may be requested again
local VERIFY_BUDGET_MS = 1.0
local DRIFT_DELAY = 45       -- receiver: first local drift check this long after applying an area
local DRIFT_RECHECK = 90
local DRIFT_COOLDOWN = 90
local DRIFT_RANGE = 900
local DRIFT_BUDGET_MS = 0.6
local MAX_IGNITES = 3        -- real fire particles per decoded area for pixels that just caught fire

local FLAG_STATIC, FLAG_BURNING = 1, 2

local CT_NONE, CT_LIQUID, CT_GAS, CT_SOLID, CT_FIRE = 0, 1, 2, 3, 4
local MAT_GAS, MAT_SOLID = -1, -2
local CELLDATA_SIZE = 0x290

pcall(ffi.cdef, [[
struct __attribute__((__packed__)) coop_px_run { uint16_t len; int16_t mat; uint8_t flags; };
]])

local run_buf = ffi.new("struct coop_px_run[?]", CELLS + 1)
local RUN_SIZE = ffi.sizeof("struct coop_px_run")
local prun_const = ffi.typeof("const struct coop_px_run*")

local wf = nil             -- noitapatcher.nsew.world_ffi
local pliquid = nil
local mat_begin = nil
local gw, cm = nil, nil

local last_sent = {}       -- area key -> encoded string we last sent
local changed_at = {}      -- area key -> frame our encoding last changed
local hot = {}             -- area key -> { ax, ay, frame } recently changed areas we own
local pending = {}         -- area key -> { ax, ay, data, t }
local verify = {}          -- area key -> { ax, ay, h1, h2 } fingerprints from the owner to check
local verify_count = 0
local cooldown = {}        -- area key -> frame until which we don't ask for that area again
local applied_fp = {}      -- area key -> { ax, ay, h1, h2, next_check, last_bad } what we last applied
local drift_keys, drift_pos = {}, 1
local hash_keys, hash_pos = {}, 1
local scan_list, scan_pos = {}, 1
local encode_skip, decode_skip = 0, 0

local function key_of(ax, ay)
	return ax * 65536 + ay
end

local function refresh_pointers()
	gw = wf.get_grid_world()
	if gw == nil then return false end
	cm = gw.vtable.get_chunk_map(gw)
	mat_begin = ffi.cast("char*", wf.get_material_ptr(0))
	return cm ~= nil
end

local function mat_id(cell)
	local p = ffi.cast("char*", cell.vtable.get_material(cell))
	return tonumber(p - mat_begin) / CELLDATA_SIZE
end

local function area_ready(ax, ay)
	local x, y = ax * AREA, ay * AREA
	if not wf.chunk_loaded(cm, x, y) then return false end
	return DoesWorldExistAt(x, y, x + AREA - 1, y + AREA - 1)
end

-- Returns the run-length encoding of an area as a string.
local function encode(ax, ay)
	local x0, y0 = ax * AREA, ay * AREA
	local get_cell = wf.get_cell
	local n = 0
	local cur_mat, cur_flags, len = nil, 0, 0
	for y = y0, y0 + AREA - 1 do
		for x = x0, x0 + AREA - 1 do
			local mat, flags = 0, 0
			local cell = get_cell(cm, x, y)[0]
			if cell ~= nil then
				local t = cell.vtable.get_cell_type(cell)
				if t == CT_SOLID then
					mat = MAT_SOLID
				elseif t == CT_GAS or t == CT_FIRE then
					mat = MAT_GAS
				else
					mat = mat_id(cell)
					if t == CT_LIQUID then
						if ffi.cast(pliquid, cell).is_static then flags = FLAG_STATIC end
						if cell.is_burning then flags = flags + FLAG_BURNING end
					end
				end
			end
			if mat == cur_mat and flags == cur_flags then
				len = len + 1
			else
				if cur_mat ~= nil then
					local r = run_buf[n]
					r.len = len - 1; r.mat = cur_mat; r.flags = cur_flags
					n = n + 1
				end
				cur_mat, cur_flags, len = mat, flags, 1
			end
		end
	end
	local r = run_buf[n]
	r.len = len - 1; r.mat = cur_mat; r.flags = cur_flags
	n = n + 1
	return ffi.string(run_buf, n * RUN_SIZE)
end

local function decode(ax, ay, data)
	local nruns = math.floor(#data / RUN_SIZE)
	if nruns < 1 or nruns * RUN_SIZE ~= #data then return false end
	local runs = ffi.cast(prun_const, data)
	local total = 0
	for i = 0, nruns - 1 do total = total + runs[i].len + 1 end
	if total ~= CELLS then return false end

	local get_cell, remove_cell, construct_cell = wf.get_cell, wf.remove_cell, wf.construct_cell
	local x0, y0 = ax * AREA, ay * AREA
	local ri = 0
	local left = runs[0].len + 1
	local mat, flags = runs[0].mat, runs[0].flags
	local mat_ptr = mat > 0 and (mat_begin + CELLDATA_SIZE * mat) or nil
	local ignites = 0
	for y = y0, y0 + AREA - 1 do
		for x = x0, x0 + AREA - 1 do
			if mat ~= MAT_SOLID then
				local pp = get_cell(cm, x, y)
				local cell = pp[0]
				local cur, t = 0, CT_NONE
				local skip = false
				if cell ~= nil then
					t = cell.vtable.get_cell_type(cell)
					if t == CT_SOLID then
						skip = true
					elseif t == CT_GAS or t == CT_FIRE then
						cur = MAT_GAS
					else
						cur = mat_id(cell)
					end
				end
				if not skip then
					local burning = flags >= FLAG_BURNING
					if mat == MAT_GAS or mat == 0 then
						-- remote has air (or gas) here: clear local liquids / powders / static terrain
						if cur > 0 then
							remove_cell(gw, cell, x, y, false)
						end
					elseif cur ~= mat then
						if cell ~= nil then
							remove_cell(gw, cell, x, y, false)
						end
						local nc = construct_cell(gw, x, y, mat_ptr, nil)
						if nc ~= nil then
							if nc.vtable.get_cell_type(nc) == CT_LIQUID then
								ffi.cast(pliquid, nc).is_static = (flags % 2) == 1
								if burning then nc.is_burning = true end
							end
							pp[0] = nc
						end
					elseif t == CT_LIQUID and cell.is_burning ~= burning then
						cell.is_burning = burning
						if burning and ignites < MAX_IGNITES then
							-- a little real fire too, in case the engine only spreads fire it created itself
							ignites = ignites + 1
							W.ignited = W.ignited + 1
							GameCreateParticle("fire", x, y, 1, 0, 0, false, false, false)
						end
					end
				end
			end
			left = left - 1
			if left == 0 then
				ri = ri + 1
				if ri < nruns then
					local r = runs[ri]
					left = r.len + 1
					mat, flags = r.mat, r.flags
					mat_ptr = mat > 0 and (mat_begin + CELLDATA_SIZE * mat) or nil
				end
			end
		end
	end
	return true
end

-- Fingerprint of an encoded area that ignores what decode() can't change (physics objects, gas, fire,
-- the static flag), so two areas that are as equal as they can get have the same fingerprint.
local function fingerprint(data)
	local nruns = math.floor(#data / RUN_SIZE)
	local runs = ffi.cast(prun_const, data)
	local h1, h2 = 5381, 0
	local cur, len = nil, 0
	for i = 0, nruns - 1 do
		local r = runs[i]
		local m = r.mat
		if m == MAT_SOLID or m == MAT_GAS then m = 0 end
		if m == cur then
			len = len + r.len + 1
		else
			if cur ~= nil then
				local v = (cur + 32768) * 8192 + len
				h1 = tobit(h1 * 33 + v)
				h2 = bxor(rol(h2, 5), v)
			end
			cur, len = m, r.len + 1
		end
	end
	if cur ~= nil then
		local v = (cur + 32768) * 8192 + len
		h1 = tobit(h1 * 33 + v)
		h2 = bxor(rol(h2, 5), v)
	end
	return h1, h2
end
W.fingerprint = fingerprint

------------------------------------------------------------------------------------------------

local function owns_area(ax, ay, lx, ly, rx, ry)
	local cx, cy = ax * AREA + AREA / 2, ay * AREA + AREA / 2
	return W.entities.owns_pos(cx, cy, lx, ly, rx, ry)
end

local function build_scan_list(px, py)
	local list = {}
	local pax, pay = math.floor(px / AREA), math.floor(py / AREA)
	for dy = -SCAN_HALF_H, SCAN_HALF_H do
		for dx = -SCAN_HALF_W, SCAN_HALF_W do
			list[#list + 1] = { pax + dx, pay + dy, dx * dx + dy * dy * 2 }
		end
	end
	table.sort(list, function(a, b) return a[3] < b[3] end)
	return list
end

local function remote_pos()
	local r = W.players and W.players.remote
	if not r then return nil end
	return r.x, r.y
end

-- Encodes an area we own and sends it if it differs from what we sent last (or always, if forced).
local function encode_and_send(ax, ay, frame, force)
	local t0 = U.now()
	local data = encode(ax, ay)
	local ms = (U.now() - t0) * 1000
	W.avg_encode_ms = W.avg_encode_ms * 0.9 + ms * 0.1
	local key = key_of(ax, ay)
	local prev = last_sent[key]
	if force or prev ~= data then
		if prev ~= data then
			changed_at[key] = frame
			if prev ~= nil then hot[key] = { ax, ay, frame, frame + HOT_RECHECK } end
		end
		last_sent[key] = data
		net.send({ "wa", ax, ay, data })
		W.sent = W.sent + 1
		return true
	end
	return false
end

local function send_changed(frame, px, py)
	if encode_skip > 0 then encode_skip = encode_skip - 1 return end
	if not net.can_send_bulk() then return end
	local rx, ry = remote_pos()
	local start = U.now()
	local done = 0

	-- recently changed areas first: that's where liquids flow and things get dug or blown up
	for key, h in pairs(hot) do
		if frame - h[3] > HOT_FRAMES or not owns_area(h[1], h[2], px, py, rx, ry) then
			hot[key] = nil
		elseif frame >= h[4] and area_ready(h[1], h[2]) then
			h[4] = frame + HOT_RECHECK
			local settled = not h[5] and frame - h[3] >= SETTLE_RESEND
			if settled then h[5] = true end
			encode_and_send(h[1], h[2], frame, settled)
			done = done + 1
			if not net.can_send_bulk() then return end
			if (U.now() - start) * 1000 > ENCODE_BUDGET_MS * 0.6 then break end
		end
	end

	local scanned = 0
	while ((U.now() - start) * 1000 <= ENCODE_BUDGET_MS or scanned == 0) and done <= 24 do
		scanned = scanned + 1
		if scan_pos > #scan_list then
			scan_list = build_scan_list(px, py)
			scan_pos = 1
		end
		local a = scan_list[scan_pos]
		scan_pos = scan_pos + 1
		local ax, ay = a[1], a[2]
		if owns_area(ax, ay, px, py, rx, ry) and area_ready(ax, ay) then
			if encode_and_send(ax, ay, frame, false) and not net.can_send_bulk() then break end
			done = done + 1
		end
		if scan_pos > #scan_list then break end
	end
	-- if one area costs more than the budget, spread the work over several frames
	if W.avg_encode_ms > ENCODE_BUDGET_MS then
		encode_skip = math.min(30, math.floor(W.avg_encode_ms / ENCODE_BUDGET_MS))
	end
end

-- Owner: fingerprints of settled areas near the other player.
local function send_fingerprints(frame, px, py)
	if frame % HASH_INTERVAL ~= 0 then return end
	local rx, ry = remote_pos()
	if not rx then return end
	if hash_pos > #hash_keys then
		hash_keys = {}
		for key in pairs(last_sent) do hash_keys[#hash_keys + 1] = key end
		hash_pos = 1
	end
	local list = {}
	local r2 = HASH_RANGE * HASH_RANGE
	while hash_pos <= #hash_keys and #list < HASH_BATCH do
		local key = hash_keys[hash_pos]
		hash_pos = hash_pos + 1
		local data = last_sent[key]
		if data then
			local ax = math.floor((key + 32768) / 65536)
			local ay = key - ax * 65536
			local cx, cy = ax * AREA + AREA / 2, ay * AREA + AREA / 2
			if frame - (changed_at[key] or 0) >= SETTLED_FRAMES and U.dist2(cx, cy, rx, ry) < r2
				and owns_area(ax, ay, px, py, rx, ry) then
				local h1, h2 = fingerprint(data)
				list[#list + 1] = { ax, ay, h1, h2 }
			end
		end
	end
	if #list > 0 then net.send({ "wh", list }) end
end

-- Receiver: compare fingerprints with our own copy of the area, ask for the area when it differs.
local function verify_fingerprints(frame, px, py)
	if verify_count == 0 then return end
	local rx, ry = remote_pos()
	local start = U.now()
	for key, v in pairs(verify) do
		verify[key] = nil
		verify_count = verify_count - 1
		if not pending[key] and not owns_area(v[1], v[2], px, py, rx, ry) and area_ready(v[1], v[2]) then
			local h1, h2 = fingerprint(encode(v[1], v[2]))
			W.checked = W.checked + 1
			if h1 ~= v[3] or h2 ~= v[4] then
				local a = applied_fp[key]
				local same = a and a[3] == v[3] and a[4] == v[4]
				if not (same and a[6] == h1) then
					if same then a[6] = h1 end
					cooldown[key] = frame + REPAIR_COOLDOWN
					W.repairs_requested = W.repairs_requested + 1
					net.send({ "wr", v[1], v[2] })
				end
			end
		end
		if (U.now() - start) * 1000 > VERIFY_BUDGET_MS then break end
	end
end

-- Receiver: our own simulation keeps running in areas the partner owns (liquids flow on, fire spreads
-- differently). Compare each applied area with what we applied and ask for it again once it drifted.
local function check_drift(frame, px, py)
	if decode_skip > 0 then return end
	if drift_pos > #drift_keys then
		drift_keys = {}
		for key in pairs(applied_fp) do drift_keys[#drift_keys + 1] = key end
		drift_pos = 1
	end
	local rx, ry = remote_pos()
	local start = U.now()
	local looked = 0
	local r2 = DRIFT_RANGE * DRIFT_RANGE
	while drift_pos <= #drift_keys and looked < 32 do
		local key = drift_keys[drift_pos]
		drift_pos = drift_pos + 1
		looked = looked + 1
		local a = applied_fp[key]
		if a and frame >= a[5] then
			local cx, cy = a[1] * AREA + AREA / 2, a[2] * AREA + AREA / 2
			if U.dist2(cx, cy, px, py) > r2 or owns_area(a[1], a[2], px, py, rx, ry) then
				applied_fp[key] = nil
			elseif not pending[key] and (cooldown[key] or 0) <= frame and area_ready(a[1], a[2]) then
				a[5] = frame + DRIFT_RECHECK
				local h1, h2 = fingerprint(encode(a[1], a[2]))
				W.drift_checked = W.drift_checked + 1
				-- the same mismatch right after a repair can't be fixed by a repair (physics object in the way)
				if (h1 ~= a[3] or h2 ~= a[4]) and h1 ~= a[6] then
					a[6] = h1
					cooldown[key] = frame + DRIFT_COOLDOWN
					W.drift_repairs = W.drift_repairs + 1
					net.send({ "wr", a[1], a[2] })
				end
				if (U.now() - start) * 1000 > DRIFT_BUDGET_MS then break end
			end
		end
	end
end

local function remember_applied(key, ax, ay, data, frame)
	local h1, h2 = fingerprint(data)
	local old = applied_fp[key]
	local last_bad = old and old[3] == h1 and old[4] == h2 and old[6] or nil
	applied_fp[key] = { ax, ay, h1, h2, frame + DRIFT_DELAY, last_bad }
end

local function apply_pending(frame, px, py)
	if decode_skip > 0 then decode_skip = decode_skip - 1 return end
	if W.pending_count == 0 then return end
	local rx, ry = remote_pos()
	local start = U.now()
	local r2 = 900 * 900
	for key, p in pairs(pending) do
		local cx, cy = p.ax * AREA + 32, p.ay * AREA + 32
		if U.dist2(cx, cy, px, py) < r2 then
			if owns_area(p.ax, p.ay, px, py, rx, ry) then
				-- we simulate this area ourselves now; our version wins
				pending[key] = nil
				W.pending_count = W.pending_count - 1
			elseif area_ready(p.ax, p.ay) then
				pending[key] = nil
				W.pending_count = W.pending_count - 1
				local t0 = U.now()
				if decode(p.ax, p.ay, p.data) then
					W.applied = W.applied + 1
					remember_applied(key, p.ax, p.ay, p.data, frame)
				end
				local ms = (U.now() - t0) * 1000
				W.avg_decode_ms = W.avg_decode_ms * 0.9 + ms * 0.1
				if (U.now() - start) * 1000 > DECODE_BUDGET_MS then break end
			end
		end
	end
	if W.avg_decode_ms > DECODE_BUDGET_MS * 2 then
		decode_skip = math.min(10, math.floor(W.avg_decode_ms / (DECODE_BUDGET_MS * 2)))
	end
end

local function fail(err)
	W.enabled = false
	W.failed = tostring(err)
	U.log("terrain sync disabled after error: " .. W.failed)
	GamePrint("[Co-op] Terrain sync disabled after an error (see mods/noita_coop/coop_log.txt)")
end

function W.init(np, entities, players)
	W.entities = entities
	W.players = players
	if not U.setting("world_sync", true) then
		U.log("terrain sync off in settings")
		return
	end
	if not np then
		W.failed = "NoitaPatcher not loaded"
		return
	end
	net.on("wa", function(m)
		if not W.enabled then return end
		local ax, ay, data = m[2], m[3], m[4]
		if type(data) ~= "string" then return end
		local key = key_of(ax, ay)
		if not pending[key] then
			W.pending_count = W.pending_count + 1
			if W.pending_count > MAX_PENDING then
				local oldest, ot = nil, math.huge
				for k, p in pairs(pending) do
					if p.t < ot then oldest, ot = k, p.t end
				end
				if oldest then pending[oldest] = nil; W.pending_count = W.pending_count - 1 end
			end
		end
		pending[key] = { ax = ax, ay = ay, data = data, t = GameGetFrameNum() }
	end)
	net.on("wh", function(m)
		if not W.enabled then return end
		local frame = GameGetFrameNum()
		for _, e in ipairs(m[2] or {}) do
			local key = key_of(e[1], e[2])
			if not pending[key] and (cooldown[key] or 0) <= frame then
				if not verify[key] then verify_count = verify_count + 1 end
				verify[key] = e
			end
		end
	end)
	net.on("wr", function(m)
		if not W.enabled or not net.synced then return end
		local player = U.local_player()
		if not player then return end
		local px, py = EntityGetTransform(player)
		local rx, ry = remote_pos()
		local ax, ay = m[2], m[3]
		if owns_area(ax, ay, px, py, rx, ry) and refresh_pointers() and area_ready(ax, ay) then
			encode_and_send(ax, ay, GameGetFrameNum(), true)
			W.repairs_sent = W.repairs_sent + 1
		end
	end)
	net.on_sync(function(synced)
		last_sent = {}
		changed_at = {}
		hot = {}
		verify, verify_count = {}, 0
		hash_keys, hash_pos = {}, 1
		applied_fp, drift_keys, drift_pos = {}, {}, 1
		if not synced then
			pending = {}
			W.pending_count = 0
		end
	end)
	W.wanted = true
end

-- Must be called after the world exists (NoitaPatcher's world access needs it).
function W.start()
	if not W.wanted or W.enabled or W.failed then return end
	local ok, res = pcall(require, "noitapatcher.nsew.world_ffi")
	if not ok then
		fail(res)
		return
	end
	wf = res
	pliquid = ffi.typeof("struct CLiquidCell*")
	local ok2, err = pcall(refresh_pointers)
	if not ok2 or not err then
		fail(ok2 and "no grid world" or err)
		return
	end
	W.enabled = true
	U.log("terrain sync ready")
end

function W.update(frame)
	if not W.enabled or not net.synced then return end
	local player = U.local_player()
	if not player then return end
	local px, py = EntityGetTransform(player)
	local ok, err = pcall(function()
		if not refresh_pointers() then return end
		apply_pending(frame, px, py)
		send_changed(frame, px, py)
		send_fingerprints(frame, px, py)
		verify_fingerprints(frame, px, py)
		check_drift(frame, px, py)
	end)
	if not ok then fail(err) end
end

return W
