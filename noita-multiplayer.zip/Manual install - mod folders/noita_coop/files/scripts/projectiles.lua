-- Replicates projectiles fired by the local player and by creatures simulated on this machine.
local net = require("scripts.net")
local U = require("scripts.util")

local PR = {
	np = nil,
	players = nil,
	entities = nil,
	use_callbacks = false,
	seen = {},          -- fallback mode: projectile ids already handled
	sent = 0,
	received = 0,
}

local HEAVY_BACKLOG = 256 * 1024

local function herd_of(entity)
	local g = EntityGetFirstComponentIncludingDisabled(entity, "GenomeDataComponent")
	if g then return ComponentGetValue2(g, "herd_id") end
	return -1
end

local function velocity_of(entity)
	local v = EntityGetFirstComponentIncludingDisabled(entity, "VelocityComponent")
	if v then return ComponentGetValue2(v, "mVelocity") end
	return 0, 0
end

-- key 0 = local player, otherwise the network id of a locally simulated creature. nil = don't replicate.
local function shooter_key(shooter)
	if not shooter or shooter == 0 then return nil end
	local player = U.local_player()
	if shooter == player then return 0 end
	if PR.entities then return PR.entities.owned_nid(shooter) end
	return nil
end

local function is_root_shot(projectile, shooter)
	local pc = EntityGetFirstComponentIncludingDisabled(projectile, "ProjectileComponent")
	if not pc then return false end
	local that_shot = ComponentGetValue2(pc, "mEntityThatShot")
	return that_shot == 0 or that_shot == shooter
end

local function send_file_projectile(projectile, key, herd)
	local file = EntityGetFilename(projectile)
	if not file or file == "" then return end
	local x, y = EntityGetTransform(projectile)
	local vx, vy = velocity_of(projectile)
	net.send({ "pjf", key, file, x, y, vx, vy, herd })
	PR.sent = PR.sent + 1
end

function PR.on_fired(shooter, projectile)
	if not net.synced then return end
	if EntityHasTag(projectile, "coop_replica") then return end
	local key = shooter_key(shooter)
	if key == nil then return end
	if not is_root_shot(projectile, shooter) then return end
	local herd = herd_of(shooter)
	if net.backlog() > HEAVY_BACKLOG or not PR.np then
		send_file_projectile(projectile, key, herd)
		return
	end
	local ok, data = pcall(PR.np.SerializeEntity, projectile)
	if not ok or not data then
		send_file_projectile(projectile, key, herd)
		return
	end
	local x, y = EntityGetTransform(projectile)
	local vx, vy = velocity_of(projectile)
	net.send({ "pj", key, x, y, vx, vy, data, herd })
	PR.sent = PR.sent + 1
end

local function resolve_shooter(key)
	if key == 0 then
		return PR.players and PR.players.puppet or nil
	end
	if PR.entities then return PR.entities.local_for_remote(key) end
	return nil
end

local function finish_replica(e, key, vx, vy, herd)
	EntityAddTag(e, "coop_replica")
	local shooter = resolve_shooter(key)
	if shooter and not EntityGetIsAlive(shooter) then shooter = nil end
	local pc = EntityGetFirstComponentIncludingDisabled(e, "ProjectileComponent")
	if pc then
		ComponentSetValue2(pc, "mWhoShot", shooter or 0)
		ComponentSetValue2(pc, "mEntityThatShot", shooter or 0)
		if herd and herd >= 0 then ComponentSetValue2(pc, "mShooterHerdId", herd) end
	end
	local v = EntityGetFirstComponentIncludingDisabled(e, "VelocityComponent")
	if v then ComponentSetValue2(v, "mVelocity", vx, vy) end
	PR.received = PR.received + 1
end

function PR.init(np, players, entities)
	PR.np = np
	PR.players = players
	PR.entities = entities
	if np and np.InstallShootProjectileFiredCallbacks then
		local ok, err = pcall(np.InstallShootProjectileFiredCallbacks)
		PR.use_callbacks = ok
		if not ok then U.log("projectile callbacks unavailable: " .. tostring(err)) end
	end

	net.on("pj", function(m)
		local key, x, y, vx, vy, data, herd = m[2], m[3], m[4], m[5], m[6], m[7], m[8]
		if not PR.np then return end
		local e = EntityCreateNew()
		local ok, err = pcall(PR.np.DeserializeEntity, e, data, x, y)
		if not ok then
			U.log("projectile deserialize failed: " .. tostring(err))
			EntityKill(e)
			return
		end
		EntitySetTransform(e, x, y)
		finish_replica(e, key, vx, vy, herd)
	end)

	net.on("pjf", function(m)
		local key, file, x, y, vx, vy, herd = m[2], m[3], m[4], m[5], m[6], m[7], m[8]
		if type(file) ~= "string" or file == "" then return end
		local ok, e = pcall(EntityLoad, file, x, y)
		if not ok or not e or e == 0 then return end
		finish_replica(e, key, vx, vy, herd)
	end)
end

-- Fallback when NoitaPatcher callbacks are unavailable: look for fresh projectiles near the player.
function PR.update(frame)
	if PR.use_callbacks or not net.synced then return end
	local player = U.local_player()
	if not player then return end
	local x, y = EntityGetTransform(player)
	local list = EntityGetInRadiusWithTag(x, y, 120, "projectile")
	local seen = PR.seen
	local fresh = {}
	for _, e in ipairs(list) do
		if not seen[e] then
			seen[e] = frame
			if not EntityHasTag(e, "coop_replica") then
				local pc = EntityGetFirstComponentIncludingDisabled(e, "ProjectileComponent")
				if pc then
					local who = ComponentGetValue2(pc, "mWhoShot")
					if who == player and is_root_shot(e, player) then
						fresh[#fresh + 1] = e
					end
				end
			end
		end
	end
	for _, e in ipairs(fresh) do
		send_file_projectile(e, 0, herd_of(player))
	end
	if frame % 300 == 0 then
		for e, f in pairs(seen) do
			if frame - f > 600 then seen[e] = nil end
		end
	end
end

return PR
