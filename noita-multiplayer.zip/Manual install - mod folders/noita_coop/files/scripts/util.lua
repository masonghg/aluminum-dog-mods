local U = {}

U.MOD_ID = "noita_coop"
U.MOD_PATH = "mods/noita_coop/"
U.VERSION = "1.4.0"
U.PROTOCOL = 4
U.NOITA_APP_ID = 881100

function U.setting(id, default)
	local v = ModSettingGet(U.MOD_ID .. "." .. id)
	if v == nil then return default end
	return v
end

local log_file = nil
local log_failed = false

local function frame_num()
	local ok, f = pcall(GameGetFrameNum)
	if ok and f then return f end
	return -1
end

function U.log(...)
	local parts = {}
	for i = 1, select("#", ...) do parts[#parts + 1] = tostring((select(i, ...))) end
	local line = "[" .. frame_num() .. "] " .. table.concat(parts, " ")
	print("[coop] " .. line)
	if log_failed then return end
	if not log_file then
		log_file = io and io.open(U.MOD_PATH .. "coop_log.txt", "w")
		if not log_file then log_failed = true return end
	end
	log_file:write(line, "\n")
	log_file:flush()
end

function U.now()
	if os and os.clock then return os.clock() end
	return GameGetRealWorldTimeSinceStarted()
end

local kernel = nil
local function kernel32()
	if kernel ~= nil then return kernel end
	kernel = false
	local ok, ffi = pcall(require, "ffi")
	if not ok then return false end
	pcall(ffi.cdef, [[
	void __stdcall coop_Sleep(uint32_t ms) __asm__("Sleep");
	const char* __stdcall coop_GetCommandLineA(void) __asm__("GetCommandLineA");
	]])
	kernel = { ffi = ffi, C = ffi.C }
	return kernel
end

-- Blocks the game thread; only for the short waits during world setup.
function U.sleep_ms(ms)
	local k = kernel32()
	if k and pcall(k.C.coop_Sleep, ms) then return end
	local t = U.now() + ms / 1000
	while U.now() < t do end
end

function U.command_line()
	local k = kernel32()
	if not k then return "" end
	local ok, s = pcall(function() return k.ffi.string(k.C.coop_GetCommandLineA()) end)
	return ok and s or ""
end

local proc_defined = nil
local function process_api()
	local k = kernel32()
	if not k then return nil end
	if proc_defined == nil then
		proc_defined = pcall(k.ffi.cdef, [[
		typedef struct {
			uint32_t cb; void* lpReserved; void* lpDesktop; void* lpTitle;
			uint32_t dwX, dwY, dwXSize, dwYSize, dwXCountChars, dwYCountChars, dwFillAttribute, dwFlags;
			uint16_t wShowWindow, cbReserved2; void* lpReserved2;
			void* hStdInput; void* hStdOutput; void* hStdError;
		} coop_STARTUPINFOA;
		typedef struct { void* hProcess; void* hThread; uint32_t dwProcessId, dwThreadId; } coop_PROCESS_INFORMATION;
		int __stdcall coop_CreateProcessA(const char* app, char* cmd, void* pa, void* ta, int inherit, uint32_t flags,
			void* env, const char* cwd, coop_STARTUPINFOA* si, coop_PROCESS_INFORMATION* pi) __asm__("CreateProcessA");
		uint32_t __stdcall coop_GetModuleFileNameA(void* module, char* buf, uint32_t size) __asm__("GetModuleFileNameA");
		int __stdcall coop_CloseHandle(void* h) __asm__("CloseHandle");
		void* __stdcall coop_GetCurrentProcess(void) __asm__("GetCurrentProcess");
		int __stdcall coop_TerminateProcess(void* h, uint32_t code) __asm__("TerminateProcess");
		uint32_t __stdcall coop_GetLastError(void) __asm__("GetLastError");
		]])
	end
	return proc_defined and k or nil
end

-- Full path of noita.exe (nil if unavailable).
function U.exe_path()
	local k = process_api()
	if not k then return nil end
	local buf = k.ffi.new("char[?]", 1024)
	local n = k.C.coop_GetModuleFileNameA(nil, buf, 1024)
	if n == 0 or n >= 1024 then return nil end
	return k.ffi.string(buf, n)
end

local CREATE_NO_WINDOW = 0x08000000

local function create_process(k, app, cmd, flags, cwd)
	local cmd_buf = k.ffi.new("char[?]", #cmd + 1)
	k.ffi.copy(cmd_buf, cmd)
	local si = k.ffi.new("coop_STARTUPINFOA")
	si.cb = k.ffi.sizeof("coop_STARTUPINFOA")
	local pi = k.ffi.new("coop_PROCESS_INFORMATION")
	if k.C.coop_CreateProcessA(app, cmd_buf, nil, nil, 0, flags, nil, cwd, si, pi) == 0 then
		return nil, "CreateProcess failed (error " .. tostring(k.C.coop_GetLastError()) .. ")"
	end
	k.C.coop_CloseHandle(pi.hThread)
	k.C.coop_CloseHandle(pi.hProcess)
	return true
end

-- Starts another copy of the game with the given arguments, delay_s seconds from now (so this process
-- has fully exited before the new one touches the save). Returns true or nil, err.
function U.spawn_self(args, delay_s)
	local k = process_api()
	if not k then return nil, "ffi unavailable" end
	local exe = U.exe_path()
	if not exe then return nil, "can't find noita.exe" end
	local cwd = exe:match("^(.*)[\\/][^\\/]*$")
	if delay_s and delay_s > 0 then
		local cmd = "cmd.exe /c ping -n " .. (math.floor(delay_s) + 1) .. ' 127.0.0.1 >nul & start "" /d "'
			.. cwd .. '" "' .. exe .. '" ' .. args
		if create_process(k, nil, cmd, CREATE_NO_WINDOW, cwd) then return true end
	end
	return create_process(k, exe, '"' .. exe .. '" ' .. args, 0, cwd)
end

-- Ends this game process immediately (nothing is saved).
function U.kill_self()
	local k = process_api()
	if k then k.C.coop_TerminateProcess(k.C.coop_GetCurrentProcess(), 0) end
	if os and os.exit then os.exit(0) end
end

function U.local_player()
	local p = EntityGetWithTag("player_unit")
	if p and p[1] then return p[1] end
	p = EntityGetWithTag("polymorphed_player")
	if p and p[1] then return p[1] end
	return nil
end

function U.real_player()
	local p = EntityGetWithTag("player_unit")
	if p and p[1] then return p[1] end
	return nil
end

function U.dist2(ax, ay, bx, by)
	local dx, dy = ax - bx, ay - by
	return dx * dx + dy * dy
end

function U.var_get(entity, name)
	local comps = EntityGetComponentIncludingDisabled(entity, "VariableStorageComponent")
	if comps then
		for _, c in ipairs(comps) do
			if ComponentGetValue2(c, "name") == name then return c end
		end
	end
	return nil
end

function U.round(v)
	return math.floor(v + 0.5)
end

function U.first_comp(entity, type_name, tag)
	return EntityGetFirstComponentIncludingDisabled(entity, type_name, tag)
end

function U.vel_of(entity)
	local c = EntityGetFirstComponent(entity, "CharacterDataComponent")
	if c then return ComponentGetValue2(c, "mVelocity") end
	c = EntityGetFirstComponent(entity, "VelocityComponent")
	if c then return ComponentGetValue2(c, "mVelocity") end
	return 0, 0
end

function U.split_tabs(s)
	local out = {}
	local start = 1
	while true do
		local i = string.find(s, "\t", start, true)
		if not i then
			out[#out + 1] = string.sub(s, start)
			break
		end
		out[#out + 1] = string.sub(s, start, i - 1)
		start = i + 1
	end
	return out
end

-- Pops all queued lines from a Globals key that entity scripts append to (newline separated).
function U.drain_global(key)
	local v = GlobalsGetValue(key, "")
	if v == "" then return nil end
	GlobalsSetValue(key, "")
	local lines = {}
	for line in string.gmatch(v, "[^\n]+") do lines[#lines + 1] = line end
	return lines
end

function U.effect_count(entity, name)
	if not GameGetGameEffectCount then return 0 end
	local ok, n = pcall(GameGetGameEffectCount, entity, name)
	return ok and tonumber(n) or 0
end

function U.is_burning(entity)
	local dm = EntityGetFirstComponentIncludingDisabled(entity, "DamageModelComponent")
	if dm and (ComponentGetValue2(dm, "is_on_fire") or ComponentGetValue2(dm, "mIsOnFire")) then return true end
	return U.effect_count(entity, "ON_FIRE") > 0
end

-- Makes a mirrored entity burn (or stop burning) the way its original does on the other machine.
-- The native fire state gives the real flames/light; the extra cosmetic particles make it visible even
-- if the engine decides to put the fire out early on an entity that can't ignite.
function U.show_burning(entity, on, frame)
	local dm = EntityGetFirstComponentIncludingDisabled(entity, "DamageModelComponent")
	if dm then
		if on then
			ComponentSetValue2(dm, "is_on_fire", true)
			ComponentSetValue2(dm, "mIsOnFire", true)
			if ComponentGetValue2(dm, "mFireFramesLeft") < 30 then ComponentSetValue2(dm, "mFireFramesLeft", 60) end
			if ComponentGetValue2(dm, "mFireDurationFrames") < 60 then ComponentSetValue2(dm, "mFireDurationFrames", 60) end
		elseif ComponentGetValue2(dm, "is_on_fire") or ComponentGetValue2(dm, "mIsOnFire") then
			ComponentSetValue2(dm, "is_on_fire", false)
			ComponentSetValue2(dm, "mIsOnFire", false)
			ComponentSetValue2(dm, "mFireFramesLeft", 0)
		end
	end
	if on and GameCreateParticle and frame % 2 == 0 then
		local x, y = EntityGetTransform(entity)
		GameCreateParticle("fire", x + math.random(-4, 4), y - math.random(0, 10), 1,
			math.random(-15, 15), -math.random(20, 50), true, false, true)
	end
end

return U
