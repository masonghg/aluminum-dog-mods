-- Steam integration through the bundled luasteam binding: Steam P2P messages as a transport
-- (no port forwarding needed), finding friends who are playing Noita, and lobbies for invites.
-- Everything here is optional: without Steam (or with it disabled) the mod only uses IP connections.
local U = require("scripts.util")

local S = {
	ok = false,
	err = nil,
	api = nil,
	my_id = nil,
	my_key = nil,
	lobby = nil,
	lobby_info = nil,
	links = {},          -- peer key -> link
	accept_any = false,  -- host: accept sessions from anyone (the handshake decides)
	on_unknown = nil,    -- fn(peer_id) -> link, for messages from peers we have no link with
	on_invite = nil,     -- fn(lobby_id), a Steam invite / "Join game" was accepted while in game
	broken = {},         -- peer key -> true after Steam reported the session failed
	events = {},
}

local CHANNEL = 0
local CHUNK = 128 * 1024
local RESULT_OK = 1
local FRIEND_FLAG_IMMEDIATE = 0x04

local function key_of(id)
	if id == nil then return nil end
	return tostring(id)
end
S.key_of = key_of

local function result_ok(r)
	return tonumber(tostring(r)) == RESULT_OK
end

function S.init()
	if S.tried then return S.ok end
	S.tried = true
	if not U.setting("use_steam", true) then S.err = "disabled in mod settings" return false end
	local ok, st = pcall(require, "luasteam")
	if not ok or type(st) ~= "table" then
		S.err = "luasteam not available: " .. tostring(st)
		U.log(S.err)
		return false
	end
	local ok2, res = pcall(st.init)
	if not ok2 or res == false then
		S.err = "Steam is not running (" .. tostring(res) .. ")"
		U.log(S.err)
		return false
	end
	local ok3, id = pcall(st.user.getSteamID)
	if not ok3 or id == nil or key_of(id) == "0" then
		S.err = "no Steam user"
		U.log(S.err)
		return false
	end
	S.api = st
	S.my_id = id
	S.my_key = key_of(id)

	-- These run inside the game's Steam callback pump, so they only record what happened.
	st.networking.onSessionRequest = function(peer)
		local k = key_of(peer)
		if S.accept_any or S.links[k] then
			pcall(st.networking.acceptSession, peer)
		end
	end
	st.networking.onSessionFailed = function(peer, reason, debug_msg)
		local k = key_of(peer)
		S.broken[k] = true
		local link = S.links[k]
		if link then link.failed = "Steam connection failed (" .. tostring(reason) .. ")" end
		S.events[#S.events + 1] = { "log", "steam session with " .. tostring(k) .. " failed: " .. tostring(reason) .. " " .. tostring(debug_msg) }
	end
	st.matchmaking.onGameLobbyJoinRequested = function(data)
		S.events[#S.events + 1] = { "invite", data and data.lobbyID }
	end

	S.ok = true
	U.log("steam ready, user " .. S.my_key)
	return true
end

function S.parse_id(s)
	if not S.ok or type(s) ~= "string" or not s:match("^%d+$") or s == "0" then return nil end
	local ok, id = pcall(S.api.extra.parseUint64, s)
	if ok and id ~= nil then return id end
	return nil
end

function S.name_of(id)
	if not S.ok then return "Steam friend" end
	local ok, n = pcall(S.api.friends.getFriendPersonaName, id)
	if ok and type(n) == "string" and n ~= "" then return n end
	return "Steam friend"
end

------------------------------------------------------------------------------------------------
-- transport: one link per peer, same interface as a TCP socket (send / recv_available / close)

local Link = {}
Link.__index = Link

function S.new_link(peer)
	local k = key_of(peer)
	local old = S.links[k]
	if old then old.closed = true end
	if S.broken[k] then
		-- a failed session has to be closed before a new one can be opened
		pcall(S.api.networking.closeSession, peer)
		S.broken[k] = nil
	end
	local link = setmetatable({ kind = "steam", id = peer, key = k, inbuf = {}, closed = false, failed = nil,
		peer = S.name_of(peer) }, Link)
	S.links[k] = link
	return link
end

-- Sends up to CHUNK bytes of str from offset. Returns the number of bytes sent (0 = Steam's queue is full,
-- try again later) or nil, err.
function Link:send(str, offset)
	if self.closed then return nil, "closed" end
	if self.failed then return nil, self.failed end
	offset = offset or 0
	local len = #str - offset
	if len <= 0 then return 0 end
	local n = math.min(len, CHUNK)
	local piece = (offset == 0 and n == #str) and str or string.sub(str, offset + 1, offset + n)
	local ok, res = pcall(S.api.networking.sendString, self.id, piece, CHANNEL)
	if not ok then return nil, "Steam send error: " .. tostring(res) end
	if not result_ok(res) then return 0 end
	return n
end

function Link:recv_available()
	if self.failed then return nil, self.failed end
	if self.closed then return nil, "closed" end
	if #self.inbuf == 0 then return "" end
	local s = table.concat(self.inbuf)
	self.inbuf = {}
	return s
end

-- Sessions are left to time out on their own: closing one throws away messages Steam hasn't delivered yet.
function Link:close()
	if self.closed then return end
	self.closed = true
	if S.links[self.key] == self then S.links[self.key] = nil end
end

-- Moves received messages into their links. Call once per frame (also while paused).
function S.pump()
	if not S.ok then return end
	local net_ = S.api.networking
	for _ = 1, 64 do
		local ok, msgs = pcall(net_.pollMessages, CHANNEL)
		if not ok or type(msgs) ~= "table" or #msgs == 0 then break end
		for _, m in ipairs(msgs) do
			local data = m.data
			if type(data) == "string" and #data > 0 then
				local k = key_of(m.user)
				local link = S.links[k]
				if (not link or link.closed) and S.on_unknown then
					link = S.on_unknown(m.user)
				end
				if link and not link.closed then
					link.inbuf[#link.inbuf + 1] = data
				end
			end
		end
	end
end

------------------------------------------------------------------------------------------------
-- friends, lobbies, invites

-- Steam friends currently playing Noita; friends who are in a lobby (= hosting co-op) first.
function S.friends_in_noita()
	local out = {}
	if not S.ok then return out end
	local fr = S.api.friends
	local ok, n = pcall(fr.getFriendCount, FRIEND_FLAG_IMMEDIATE)
	if not ok or type(n) ~= "number" then return out end
	for i = 0, n - 1 do
		local ok2, f = pcall(fr.getFriendByIndex, i, FRIEND_FLAG_IMMEDIATE)
		if ok2 and f ~= nil then
			local ok3, gi = pcall(fr.getFriendGamePlayed, f)
			if ok3 and type(gi) == "table" and tonumber(tostring(gi.gameID)) == U.NOITA_APP_ID then
				local lk = gi.lobbyID ~= nil and tostring(gi.lobbyID) or "0"
				out[#out + 1] = { id = f, key = key_of(f), name = S.name_of(f), lobby_key = lk ~= "0" and lk or nil }
			end
		end
	end
	table.sort(out, function(a, b) return (a.lobby_key and 1 or 0) > (b.lobby_key and 1 or 0) end)
	return out
end

-- Lobby id from "+connect_lobby <id>", which Steam adds when it starts the game from an invite.
function S.command_line_lobby()
	return string.match(U.command_line(), "%+connect_lobby%s+(%d+)")
end

function S.rich_presence(key, value)
	if not S.ok then return end
	pcall(S.api.friends.setRichPresence, key, value)
end

-- Host: a friends-only lobby makes "Join Game" show up on the host's Steam profile and enables invites.
function S.host_lobby(info)
	if not S.ok then return end
	S.lobby_info = info
	S.rich_presence("status", "Noita Co-op - hosting")
	if S.lobby or S.lobby_pending then
		S.set_lobby_info(info)
		return
	end
	S.lobby_pending = true
	local ok, err = pcall(S.api.matchmaking.createLobby, "FriendsOnly", 2, function(e)
		S.lobby_pending = false
		if e and result_ok(e.result) and e.lobby ~= nil then
			S.lobby = e.lobby
			U.log("steam lobby created " .. tostring(e.lobby))
			S.set_lobby_info(S.lobby_info)
		else
			U.log("steam lobby creation failed: " .. tostring(e and e.result))
		end
	end)
	if not ok then
		S.lobby_pending = false
		U.log("steam createLobby error: " .. tostring(err))
	end
end

function S.set_lobby_info(info)
	S.lobby_info = info
	if not S.lobby or not info then return end
	for k, v in pairs(info) do
		pcall(S.api.matchmaking.setLobbyData, S.lobby, k, tostring(v))
	end
end

function S.invite_dialog()
	if not S.ok or not S.lobby then return false end
	return (pcall(S.api.friends.activateGameOverlayInviteDialog, S.lobby))
end

function S.invite_friend(id)
	if not S.ok or not S.lobby then return false end
	local ok, res = pcall(S.api.matchmaking.inviteUserToLobby, S.lobby, id)
	return ok and res ~= false
end

-- Client: reads who owns a lobby and the co-op info stored in it. cb(owner_id, info) or cb(nil, err).
function S.resolve_lobby(lobby, cb)
	if not S.ok then cb(nil, "Steam unavailable") return end
	local mm = S.api.matchmaking
	local ok, err = pcall(mm.joinLobby, lobby, function(e)
		if not e or tonumber(tostring(e.response)) ~= 1 then
			cb(nil, "could not open the Steam lobby (" .. tostring(e and e.response) .. ")")
			return
		end
		local id = e.lobbyID or lobby
		local okw, owner = pcall(mm.getLobbyOwner, id)
		local info = {}
		for _, k in ipairs({ "noita_coop", "seed", "host_name", "protocol" }) do
			local okd, v = pcall(mm.getLobbyData, id, k)
			info[k] = okd and v or nil
		end
		pcall(mm.leaveLobby, id)
		if not okw or owner == nil then cb(nil, "lobby has no owner") return end
		cb(owner, info)
	end)
	if not ok then cb(nil, tostring(err)) end
end

function S.update()
	if not S.ok then return end
	local events = S.events
	if #events == 0 then return end
	S.events = {}
	for _, ev in ipairs(events) do
		if ev[1] == "log" then
			U.log(ev[2])
		elseif ev[1] == "invite" and ev[2] ~= nil and S.on_invite then
			local ok, err = pcall(S.on_invite, ev[2])
			if not ok then U.log("invite handler error: " .. tostring(err)) end
		end
	end
end

function S.shutdown()
	if not S.ok then return end
	if S.lobby then pcall(S.api.matchmaking.leaveLobby, S.lobby) S.lobby = nil end
	S.rich_presence("status", "")
end

return S
