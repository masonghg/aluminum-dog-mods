-- Noita Co-op (Full Sync): two-player shared world over Steam or a direct TCP connection.
local MOD_PATH = "mods/noita_coop/"

ModLuaFileAppend("data/scripts/perks/perk_pickup.lua", MOD_PATH .. "files/append/perk_pickup.lua")
ModLuaFileAppend("data/scripts/items/orb_pickup.lua", MOD_PATH .. "files/append/orb_pickup.lua")
for _, h in ipairs({ "heart", "heart_better", "heart_evil", "heart_fullhp", "heart_fullhp_temple" }) do
	ModLuaFileAppend("data/scripts/items/" .. h .. ".lua", MOD_PATH .. "files/append/heart.lua")
end
ModLuaFileAppend("data/scripts/magic/fungal_shift.lua", MOD_PATH .. "files/append/fungal_shift.lua")
ModLuaFileAppend("data/scripts/buildings/temple_check_for_leaks.lua", MOD_PATH .. "files/append/temple_check_for_leaks.lua")

-- Written by the installer. Noita keeps mod settings once they have been saved, so the
-- installer's choices are pushed into the settings once per install (identified by stamp).
do
	local ok, cfg = pcall(dofile, MOD_PATH .. "files/install_defaults.lua")
	if ok and type(cfg) == "table" and cfg.stamp and ModSettingGet("noita_coop._install_stamp") ~= cfg.stamp then
		for _, key in ipairs({ "role", "host_ip", "port", "player_name" }) do
			if type(cfg[key]) == "string" and cfg[key] ~= "" then
				ModSettingSet("noita_coop." .. key, cfg[key])
				ModSettingSetNextValue("noita_coop." .. key, cfg[key], false)
			end
		end
		ModSettingSet("noita_coop._install_stamp", cfg.stamp)
	end
end

local disabled_reason = nil
if type(require) ~= "function" or not pcall(require, "ffi") then
	disabled_reason = "Noita Co-op needs unsafe mods: Mods menu -> enable 'Allow unsafe mods', then restart the game."
elseif ModIsEnabled("evaisa.mp") then
	disabled_reason = "Noita Co-op can't run together with Noita Online (evaisa.mp). Disable one of them in the Mods menu."
end

local U, net, steam, players, entities, projectiles, worldsync, events, ui
local np = nil
local role, host_ip, port, my_name
local game_mode = nil              -- "host" / "join" when the run was started with a Co-op New Game mode
local preinit_seed, preinit_err, preinit_target = nil, nil, nil
local started = false
local local_seed = nil
local error_counts = {}

if not disabled_reason then
	package.path = package.path .. ";./" .. MOD_PATH .. "files/?.lua;./" .. MOD_PATH .. "bin/NoitaPatcher/?.lua"
	package.cpath = package.cpath .. ";./" .. MOD_PATH .. "bin/NoitaPatcher/?.dll;./" .. MOD_PATH .. "bin/?.dll"
	__nsew_path = MOD_PATH .. "bin/NoitaPatcher/noitapatcher/nsew/"
	if os and os.time then math.randomseed(os.time()) end

	U = require("scripts.util")
	net = require("scripts.net")
	steam = require("scripts.steam")
	players = require("scripts.players")
	entities = require("scripts.entities")
	projectiles = require("scripts.projectiles")
	worldsync = require("scripts.worldsync")
	events = require("scripts.events")
	ui = require("scripts.ui")

	local ok, res = pcall(require, "noitapatcher")
	if ok and type(res) == "table" then
		np = res
		U.log("NoitaPatcher loaded")
	else
		U.log("NoitaPatcher failed to load (projectiles fall back to file mode, terrain sync off): " .. tostring(res))
	end

	host_ip = U.setting("host_ip", "70.180.181.97")
	port = tonumber(U.setting("port", "25600")) or 25600
	my_name = U.setting("player_name", "Player")
	if my_name == "" then my_name = "Player" end
end

local function guarded(name, fn, ...)
	local ok, err = pcall(fn, ...)
	if not ok then
		local n = (error_counts[name] or 0) + 1
		error_counts[name] = n
		if n <= 5 then
			U.log("error in " .. name .. ": " .. tostring(err))
			if n == 1 then GamePrint("[Co-op] error in " .. name .. " (details in mods/noita_coop/coop_log.txt)") end
		end
	end
end

local function keep_running()
	return np ~= nil and U.setting("keep_running_when_paused", true)
end

------------------------------------------------------------------------------------------------
-- where to connect: targets are { kind = "tcp", addr, port } or { kind = "steam", id, key, name }

local PENDING_MAX_AGE = 30 * 60

local function target_to_str(t)
	if not t then return "" end
	if t.kind == "steam" then return "steam\t" .. tostring(t.key or steam.key_of(t.id)) .. "\t" .. tostring(t.name or "") end
	return "tcp\t" .. tostring(t.addr) .. "\t" .. tostring(t.port)
end

local function target_from_str(s)
	local p = U.split_tabs(s or "")
	if p[1] == "steam" then
		local id = steam.parse_id(p[2])
		if id then return { kind = "steam", id = id, key = p[2], name = p[3] ~= "" and p[3] or nil } end
	elseif p[1] == "tcp" and p[2] and p[2] ~= "" and tonumber(p[3]) then
		return { kind = "tcp", addr = p[2], port = tonumber(p[3]) }
	end
	return nil
end

local function same_target(a, b)
	if not a or not b or a.kind ~= b.kind then return false end
	if a.kind == "steam" then return tostring(a.key or steam.key_of(a.id)) == tostring(b.key or steam.key_of(b.id)) end
	return a.addr == b.addr and a.port == b.port
end

-- A host we tried to join while in a different world: remembered so the next "Co-op: Join" goes there.
local function save_pending(t, seed)
	ModSettingSet("noita_coop._pending_target", target_to_str(t))
	ModSettingSet("noita_coop._pending_seed", tostring(seed or ""))
	ModSettingSet("noita_coop._pending_time", tostring(os.time()))
end

local function load_pending()
	local t = target_from_str(ModSettingGet("noita_coop._pending_target"))
	local time = tonumber(ModSettingGet("noita_coop._pending_time") or "")
	if not t or not time or os.time() - time > PENDING_MAX_AGE then return nil end
	return { target = t, seed = tonumber(ModSettingGet("noita_coop._pending_seed") or "") }
end

local function clear_pending()
	ModSettingSet("noita_coop._pending_target", "")
end

-- Hand-off to the restarted game when we reload into the host's world. A file, because the game is
-- killed right after writing it and mod settings are only saved on a clean exit.
local AUTOJOIN_FILE = MOD_PATH .. "autojoin.txt"
local AUTOJOIN_MAX_AGE = 3 * 60
local RESTART_ARGS = "-no_logo_splashes -clean_save -gamemode 0 -gamemode_mod_name noita_coop_join"

local function write_autojoin(t, seed, host_name, used, time)
	local f = io.open(AUTOJOIN_FILE, "w")
	if not f then return false end
	f:write(target_to_str(t), "\n", tostring(seed), "\n", tostring(time or os.time()), "\n",
		used and "1" or "0", "\n", tostring(host_name or ""), "\n")
	f:close()
	return true
end

local function read_autojoin()
	local f = io.open(AUTOJOIN_FILE, "r")
	if not f then return nil end
	local lines = {}
	for line in f:lines() do lines[#lines + 1] = line end
	f:close()
	local t = target_from_str(lines[1])
	local seed, time = tonumber(lines[2] or ""), tonumber(lines[3] or "")
	if not t or not seed or not time then return nil end
	return { target = t, seed = seed, time = time, used = lines[4] == "1",
		host_name = (lines[5] and lines[5] ~= "") and lines[5] or nil }
end

local function delete_autojoin()
	os.remove(AUTOJOIN_FILE)
end

local function steam_target(f)
	return { kind = "steam", id = f.id, key = f.key, name = f.name }
end

-- Client, during world setup: ask everyone who could be our host for their world seed.
-- First the host we were invited to / tried to join, then friends hosting on Steam and the IP from the settings.
local function find_host()
	local pending = load_pending()
	local first, rest = {}, {}
	if pending then first[1] = pending.target end
	local cl_lobby = steam.ok and steam.command_line_lobby() or nil
	if cl_lobby then U.log("started from Steam invite, lobby " .. cl_lobby) end
	for _, f in ipairs(steam.friends_in_noita()) do
		if f.lobby_key then
			local t = steam_target(f)
			if cl_lobby and f.lobby_key == cl_lobby then
				table.insert(first, 1, t)
			elseif not (pending and same_target(pending.target, t)) then
				rest[#rest + 1] = t
			end
		end
	end
	rest[#rest + 1] = { kind = "tcp", addr = host_ip, port = port }

	local seed, run_id, t, name, err
	if #first > 0 then
		seed, run_id, t, name = net.query_any(first, my_name, 6)
		if not seed then err = run_id end
	end
	if not seed then
		seed, run_id, t, name = net.query_any(rest, my_name, 4)
		if not seed then err = run_id end
	end
	if seed then return seed, t, name end
	return nil, err, pending
end

-- Normal start: a friend hosting co-op who invited us from their F9 menu (the invite itself is lost if it
-- was accepted on the main menu, so we ask them instead).
local function find_invite()
	if not steam.ok then return nil end
	local targets = {}
	for _, f in ipairs(steam.friends_in_noita()) do
		if f.lobby_key then targets[#targets + 1] = steam_target(f) end
	end
	if #targets == 0 then return nil end
	local seed, _, t, name = net.query_any(targets, my_name, 3, true)
	if seed then return seed, t, name end
	return nil
end

local function save00_file(name)
	local home = os.getenv("USERPROFILE")
	return home and (home .. "\\AppData\\LocalLow\\Nolla_Games_Noita\\save00\\" .. name) or nil
end

local function file_exists(path)
	if not path then return false end
	local f = io.open(path, "rb")
	if f then f:close() return true end
	return false
end

-- Only true when the save folder is visible and holds no run; a continued run must keep its seed.
local function surely_new_game()
	if not file_exists(save00_file("mod_config.xml")) then return false end
	return not file_exists(save00_file("player.xml")) and not file_exists(save00_file("world_state.xml"))
end

local function read_game_mode()
	local h = ModSettingGet("noita_coop._gm_host") == "1"
	local j = ModSettingGet("noita_coop._gm_join") == "1"
	ModSettingSet("noita_coop._gm_host", "")
	ModSettingSet("noita_coop._gm_join", "")
	if h and j then
		U.log("both Co-op game mode mods ran - they are not acting as game modes, ignoring them")
		return nil
	end
	return h and "host" or (j and "join" or nil)
end

------------------------------------------------------------------------------------------------

function OnModPreInit()
	if disabled_reason then return end
	game_mode = read_game_mode()
	local ok, err = pcall(steam.init)
	if not ok then U.log("steam init error: " .. tostring(err)) end
	local aj = read_autojoin()
	if aj and not aj.used and os.time() - aj.time <= AUTOJOIN_MAX_AGE then
		-- we restarted ourselves to load the host's world: the seed is already known
		role = "client"
		preinit_seed = aj.seed
		preinit_target = aj.target
		SetWorldSeed(aj.seed)
		ModSettingSet("noita_coop.last_host_seed", tostring(aj.seed))
		write_autojoin(aj.target, aj.seed, aj.host_name, true, aj.time)
		U.log("Noita Co-op " .. U.VERSION .. " restarted into " .. net.describe_target(aj.target) .. "'s world, seed " .. aj.seed)
		return
	end
	if game_mode == "host" then
		role = "host"
	elseif game_mode == "join" then
		role = "client"
	else
		role = U.setting("role", "off")
		if role ~= "host" and role ~= "client" then role = "off" end
	end
	U.log("Noita Co-op " .. U.VERSION .. " mode=" .. tostring(game_mode) .. " role=" .. tostring(role)
		.. " host=" .. tostring(host_ip) .. ":" .. tostring(port))
	if role == "off" then
		local ok_inv, seed, t, name = pcall(find_invite)
		if ok_inv and seed then
			role = "client"
			preinit_target = t
			if surely_new_game() then
				preinit_seed = seed
				SetWorldSeed(seed)
				ModSettingSet("noita_coop.last_host_seed", tostring(seed))
				U.log("invited by " .. tostring(name) .. ": new game in their world, seed " .. tostring(seed))
			else
				U.log("invited by " .. tostring(name) .. ": continuing a run, will switch to their world after loading")
			end
		elseif not ok_inv then
			U.log("invite check error: " .. tostring(seed))
		end
		return
	end
	if role ~= "client" then return end

	local seed, t_or_err, name_or_pending = find_host()
	if seed then
		preinit_seed = seed
		preinit_target = t_or_err
		SetWorldSeed(seed)
		ModSettingSet("noita_coop.last_host_seed", tostring(seed))
		U.log("got seed " .. tostring(seed) .. " from " .. net.describe_target(t_or_err) .. " (" .. tostring(name_or_pending) .. ")")
		return
	end
	preinit_err = tostring(t_or_err)
	U.log("could not get host seed: " .. preinit_err)
	local pending = name_or_pending
	local fallback = (pending and pending.seed) or tonumber(ModSettingGet("noita_coop.last_host_seed") or "")
	if fallback then
		preinit_seed = nil
		SetWorldSeed(fallback)
		U.log("using remembered host seed " .. fallback)
	end
	if pending then preinit_target = pending.target end
end

function OnMagicNumbersAndWorldSeedInitialized()
	if disabled_reason then return end
	local_seed = tonumber(StatsGetValue("world_seed"))
	if role == "host" then net.host_seed = local_seed end
	U.log("world seed " .. tostring(local_seed))
end

------------------------------------------------------------------------------------------------
-- switching roles in game (F9 menu, Steam invites)

local function ensure_run_id()
	local run_id = GlobalsGetValue("coop_run_id", "")
	if run_id == "" then
		run_id = tostring(local_seed) .. "_" .. tostring(math.random(100000, 999999))
		GlobalsSetValue("coop_run_id", run_id)
	end
	net.run_id = run_id
end

local function lobby_info()
	return { noita_coop = "1", seed = tostring(local_seed), host_name = my_name, protocol = tostring(U.PROTOCOL) }
end

local function become_host()
	if net.role == "host" then return end
	if net.connected then
		GamePrint("[Co-op] You are connected to " .. tostring(net.peer_name) .. " - you can't host at the same time.")
		return
	end
	if net._connecting then net._connecting.link:close() net._connecting = nil end
	role = "host"
	GlobalsSetValue("coop_role", "host")
	net.host_seed = local_seed
	ensure_run_id()
	if net.start_host(port) then
		steam.host_lobby(lobby_info())
		GamePrint("[Co-op] Hosting this world. Your friend can join through Steam" ..
			(net.listening_tcp and (" or your IP on port " .. port) or "") .. ".")
	end
end

local function join_target(t)
	if net.connected and net.role == "host" then
		GamePrint("[Co-op] You are hosting and " .. tostring(net.peer_name) .. " is connected.")
		return
	end
	if net.connected and same_target(net.target, t) then return end
	role = "client"
	GlobalsSetValue("coop_role", "client")
	GlobalsSetValue("coop_target", target_to_str(t))
	steam.accept_any = false
	net.set_target(t)
	GamePrint("[Co-op] Connecting to " .. net.describe_target(t) .. "...")
end

local function handle_invite(lobby)
	local lk = tostring(lobby)
	U.log("Steam invite / join request for lobby " .. lk)
	for _, f in ipairs(steam.friends_in_noita()) do
		if f.lobby_key == lk then
			join_target(steam_target(f))
			return
		end
	end
	steam.resolve_lobby(lobby, function(owner, info)
		if not owner then
			GamePrint("[Co-op] Could not open the Steam invite: " .. tostring(info))
			return
		end
		local key = steam.key_of(owner)
		if key == steam.my_key then return end
		if info and info.noita_coop ~= "1" then
			GamePrint("[Co-op] That Steam lobby is not a Noita Co-op game.")
			return
		end
		join_target({ kind = "steam", id = owner, key = key, name = (info and info.host_name) or steam.name_of(owner) })
	end)
end

------------------------------------------------------------------------------------------------
-- loading the host's world: the world is generated from the seed at startup, so the only way into a
-- different world is a new game. The game restarts itself straight into one with the host's seed.

local RELOAD_DELAY = 3
local reload = nil          -- { target, seed, name, stage = "wait" | "bye" | "done", at }
local reload_failed = false

local function start_reload(t, seed, host_name)
	if reload or reload_failed then return end
	local name = host_name or net.describe_target(t)
	if not U.setting("auto_load_host_world", true) then return end
	local aj = read_autojoin()
	if aj and aj.used and aj.seed == seed and os.time() - aj.time <= AUTOJOIN_MAX_AGE then
		U.log("already restarted for seed " .. tostring(seed) .. " but the world still differs, not restarting again")
		GamePrintImportant("Co-op: still a different world", "Restarting didn't load " .. name .. "'s world. Try New Game > 'Co-op: Join'.")
		return
	end
	net.reloading = true
	reload = { target = t, seed = seed, name = name, stage = "wait", at = U.now() + RELOAD_DELAY }
	U.log("host " .. name .. " is in world " .. tostring(seed) .. ", we are in " .. tostring(local_seed) .. " - restarting into it")
	GamePrintImportant("Co-op: loading " .. name .. "'s world", "Your game restarts into their world in a few seconds...")
end

local function reload_give_up(err)
	U.log("restart failed: " .. tostring(err))
	delete_autojoin()
	reload, reload_failed, net.reloading = nil, true, false
	GamePrintImportant("Co-op: couldn't restart the game", "Start a NEW GAME and pick 'Co-op: Join' to load their world.")
end

local function tick_reload()
	if not reload or U.now() < reload.at then return end
	if reload.stage == "wait" then
		if not write_autojoin(reload.target, reload.seed, reload.name, false) then
			return reload_give_up("can't write " .. AUTOJOIN_FILE)
		end
		net.shutdown("loading your world")
		net.role = "off"
		reload.stage = "bye"
		reload.at = U.now() + 0.5  -- lets Steam deliver the goodbye
	elseif reload.stage == "bye" then
		reload.stage = "done"
		U.log("restarting: " .. RESTART_ARGS)
		local ok, err = U.spawn_self(RESTART_ARGS, 2)
		if not ok then return reload_give_up(err) end
		U.kill_self()
	end
end

local function draw_actions()
	return {
		host = become_host,
		join = join_target,
		join_ip = function() join_target({ kind = "tcp", addr = host_ip, port = port }) end,
		invite = function()
			if not steam.invite_dialog() then GamePrint("[Co-op] Steam overlay invite is not available (is the Steam overlay enabled?)") end
		end,
		invite_friend = function(f)
			if steam.invite_friend(f.id) then
				net.invited[f.key] = U.now() + 600
				GamePrint("[Co-op] Invited " .. tostring(f.name) .. ". They can accept in Steam, or just start a game (New Game or Continue) within 10 minutes.")
			else
				GamePrint("[Co-op] Could not send the Steam invite (the lobby may still be starting).")
			end
		end,
		is_invited = function(f) return (net.invited[f.key] or 0) > U.now() end,
		retry = function() net.retry_now() end,
		friends = function() return steam.friends_in_noita() end,
		steam_target = steam_target,
		host_ip = host_ip,
		port = port,
		game_mode = game_mode,
	}
end

------------------------------------------------------------------------------------------------

function OnWorldInitialized()
	if disabled_reason then
		GamePrintImportant("Noita Co-op is not running", disabled_reason)
		return
	end
	if started then return end
	started = true
	local_seed = local_seed or tonumber(StatsGetValue("world_seed"))

	-- a continued run remembers how it was played
	local client_target = preinit_target
	if role == "off" then
		local saved = GlobalsGetValue("coop_role", "")
		if saved == "host" or saved == "client" then role = saved end
	end
	if role == "client" and not client_target then
		client_target = target_from_str(GlobalsGetValue("coop_target", ""))
			or { kind = "tcp", addr = host_ip, port = port }
	end
	if role ~= "off" then GlobalsSetValue("coop_role", role) end
	if role == "client" then GlobalsSetValue("coop_target", target_to_str(client_target)) end

	if role == "host" then
		net.host_seed = local_seed
		ensure_run_id()
	end

	net.init(role, nil, port, my_name, client_target)
	players.init()
	entities.init(np, players)
	projectiles.init(np, players, entities)
	worldsync.init(np, entities, players)
	events.init()
	ui.init(players, entities, worldsync, draw_actions())
	guarded("terrain sync start", worldsync.start)

	if role == "host" then steam.host_lobby(lobby_info()) end
	steam.on_invite = handle_invite

	net.on_welcome(function(seed, run_id, target, host_name)
		if seed ~= local_seed then
			save_pending(target, seed)
			start_reload(target, seed, host_name)
		end
	end)
	net.on_sync(function(synced)
		if synced then
			clear_pending()
			delete_autojoin()
			entities.load_run_log(net.run_id)
			GamePrint("[Co-op] World synchronized with " .. tostring(net.peer_name))
			steam.rich_presence("status", "Noita Co-op - playing with " .. tostring(net.peer_name))
		end
		if keep_running() then
			pcall(np.EnableGameSimulatePausing, not synced)
		end
	end)

	if role == "client" then
		if preinit_err then
			GamePrint("[Co-op] Could not reach a host before world generation (" .. preinit_err .. ").")
			GamePrint("[Co-op] Make sure your friend is in game, then start a NEW GAME with 'Co-op: Join'. F9 = co-op menu.")
		end
	elseif role == "off" then
		GamePrint("[Co-op] Press F9 to host this world or join a friend.")
		local cl_lobby = steam.command_line_lobby()
		if cl_lobby then
			local id = steam.parse_id(cl_lobby)
			if id then handle_invite(id) end
		end
	end
end

function OnPlayerSpawned(player_entity)
	if disabled_reason or not started then return end
	if np and np.RegisterPlayerEntityId then pcall(np.RegisterPlayerEntityId, player_entity) end
	net.set_local_ready(local_seed)
end

function OnWorldPreUpdate()
	if not started then return end
	guarded("steam", steam.update)
	guarded("network", net.pump)
	guarded("restart", tick_reload)
end

function OnWorldPostUpdate()
	if not started then return end
	local frame = GameGetFrameNum()
	guarded("players", players.update, frame)
	guarded("entities", entities.update, frame)
	guarded("projectiles", projectiles.update, frame)
	guarded("terrain", worldsync.update, frame)
	guarded("events", events.update, frame)
	guarded("network", net.flush)
	guarded("ui", ui.draw, frame)
end

function OnPausePreUpdate()
	if not started then return end
	guarded("steam", steam.update)
	guarded("network", net.pump)
	guarded("network", net.flush)
	guarded("restart", tick_reload)
end

function OnPausedChanged(is_paused, is_inventory_pause)
	if not started then return end
	local player = U.real_player()
	if player and net.synced and keep_running() then
		pcall(np.RegisterPlayerEntityId, player)
		pcall(np.EnableInventoryGuiUpdate, not is_paused)
		pcall(np.EnablePlayerItemPickUpper, not is_paused)
		local controls = EntityGetFirstComponentIncludingDisabled(player, "ControlsComponent")
		if controls then ComponentSetValue2(controls, "enabled", not is_paused) end
	end
	guarded("players", players.on_paused_changed, is_paused)
end

-- NoitaPatcher projectile hooks
function OnProjectileFired() end

function OnProjectileFiredPost(shooter_id, projectile_id, rng, position_x, position_y, target_x, target_y, send_message, unknown1, multicast_index, unknown3)
	if not started then return end
	guarded("projectiles", projectiles.on_fired, shooter_id, projectile_id)
end
