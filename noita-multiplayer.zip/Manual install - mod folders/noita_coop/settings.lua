dofile("data/scripts/lib/mod_settings.lua")

local mod_id = "noita_coop"
mod_settings_version = 1

local NAME_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-"
local HOST_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.-"

mod_settings =
{
	{
		id = "_info",
		ui_name = "2-player co-op. Host: press F9 in game (or New Game -> 'Co-op: Host'). Join: accept a Steam invite\nor press F9 - your game restarts into the host's world by itself.",
		not_setting = true,
	},
	{
		category_id = "connection",
		ui_name = "CONNECTION",
		settings = {
			{
				id = "role",
				ui_name = "Role in normal games",
				ui_description = "Only used for runs NOT started with the 'Co-op: Host' / 'Co-op: Join' New Game modes.\nOff: co-op stays idle until you press F9 and pick Host / Join.",
				value_default = "off",
				values = { {"off", "Off (use New Game modes / F9)"}, {"host", "Host"}, {"client", "Client (join host)"} },
				scope = MOD_SETTING_SCOPE_NEW_GAME,
			},
			{
				id = "use_steam",
				ui_name = "Use Steam",
				ui_description = "Connect through Steam: join friends from your Steam friends list or with Steam invites,\nno port forwarding needed. Direct IP connections keep working either way.",
				value_default = true,
				scope = MOD_SETTING_SCOPE_NEW_GAME,
			},
			{
				id = "auto_load_host_world",
				ui_name = "Auto-load host's world",
				ui_description = "When you join a host who is in a different world, your game restarts by itself\nstraight into a new game in their world (your current run is replaced).",
				value_default = true,
				scope = MOD_SETTING_SCOPE_RUNTIME,
			},
			{
				id = "host_ip",
				ui_name = "Host address",
				ui_description = "IP or hostname of the host, for direct connections (the host must port-forward the port).\nNot needed when joining through Steam.",
				value_default = "70.180.181.97",
				text_max_length = 64,
				allowed_characters = HOST_CHARS,
				scope = MOD_SETTING_SCOPE_NEW_GAME,
			},
			{
				id = "port",
				ui_name = "Port",
				ui_description = "TCP port. The host listens on it, the client connects to it.",
				value_default = "25600",
				text_max_length = 5,
				allowed_characters = "0123456789",
				scope = MOD_SETTING_SCOPE_NEW_GAME,
			},
			{
				id = "player_name",
				ui_name = "Your name",
				ui_description = "Shown above your character on the other player's screen.",
				value_default = "Player",
				text_max_length = 16,
				allowed_characters = NAME_CHARS,
				scope = MOD_SETTING_SCOPE_NEW_GAME,
			},
		},
	},
	{
		category_id = "sync",
		ui_name = "SYNC OPTIONS",
		settings = {
			{
				id = "world_sync",
				ui_name = "Terrain sync",
				ui_description = "Synchronize terrain, liquids and powders pixel by pixel.\nUses the bundled NoitaPatcher. Turn off if you get crashes.",
				value_default = true,
				scope = MOD_SETTING_SCOPE_NEW_GAME,
			},
			{
				id = "revive",
				ui_name = "Downed & revive",
				ui_description = "When you die while your partner is alive you go down instead of getting a game over.\nStand next to a downed partner to revive them, or reach a Holy Mountain.",
				value_default = true,
				scope = MOD_SETTING_SCOPE_RUNTIME,
			},
			{
				id = "shared_perks",
				ui_name = "Shared perks",
				ui_description = "When your partner takes a perk, you get it too.",
				value_default = true,
				scope = MOD_SETTING_SCOPE_RUNTIME,
			},
			{
				id = "shared_orbs",
				ui_name = "Shared orbs",
				ui_description = "When your partner picks up an orb, you get it too.",
				value_default = true,
				scope = MOD_SETTING_SCOPE_RUNTIME,
			},
			{
				id = "shared_hearts",
				ui_name = "Shared hearts",
				ui_description = "When your partner picks up a heart, you get the same max HP / healing.",
				value_default = true,
				scope = MOD_SETTING_SCOPE_RUNTIME,
			},
			{
				id = "keep_running_when_paused",
				ui_name = "Keep world running while paused",
				ui_description = "While connected, opening the menu or inventory does not freeze the world\n(otherwise one player pausing would desync the other).",
				value_default = true,
				scope = MOD_SETTING_SCOPE_NEW_GAME,
			},
		},
	},
}

function ModSettingsUpdate( init_scope )
	local old_version = mod_settings_get_version( mod_id )
	mod_settings_update( mod_id, mod_settings, init_scope )
end

function ModSettingsGuiCount()
	return mod_settings_gui_count( mod_id, mod_settings )
end

function ModSettingsGui( gui, in_main_menu )
	mod_settings_gui( mod_id, mod_settings, gui, in_main_menu )
end
