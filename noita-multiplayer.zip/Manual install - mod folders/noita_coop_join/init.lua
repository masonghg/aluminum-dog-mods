-- Tells the Noita Co-op mod (which reads and clears this in OnModPreInit) to join a host in this run.
ModSettingSet("noita_coop._gm_join", "1")
