SULFUR MULTIPLAYER (version 0.6.0) - online co-op, 2 to 8 players
=================================================================

Play SULFUR together over Steam. One player hosts, friends join through
Steam (no IP addresses or port forwarding), and everyone drops into the
same level as the host:

  - Everyone fights the same enemies. The host's game controls them, and
    they react to every player.
  - More players means more enemies: with 2 players there are twice as
    many, with 3 players three times as many, and so on.
  - Boss fights are shared: whoever walks into the arena first starts the
    fight for everyone, and everyone else is brought into the arena with
    them so nobody gets locked out.
  - Loot, chests, doors (including the big hold-to-open doors and metal
    gates), breakables and pickups are shared: if one player grabs an
    item, it's gone for everyone else.
  - Thrown grenades fly and explode for everyone, with a glowing trail
    and a warning icon so you can see them coming. Molotov fire burns for
    everyone too.
  - The stash chest at the church and every shop are shared, so items you
    put in or sell can be taken or bought by your friends.
  - Share ammo and money by dropping them on the floor from your
    inventory.
  - Barrels, crates and other loose physics objects stay in the same place
    for everyone.
  - Other players show up as priests that match the first-person arms,
    holding the weapon they have out (with its arms), with their Steam
    name above their head. You see their bullets, muzzle flashes,
    reloads (with a "RELOADING" sign) and melee swings, and they crouch
    when they crouch.
  - A bar at the top of the screen shows everyone in the session, their
    ping and health, and who joins, leaves or dies.
  - Level exits are a vote: when someone walks into an exit, everyone
    else gets asked first, and the party moves on together once all have
    accepted. Everyone always ends up in the same world.
  - Opening menus or your inventory doesn't freeze the game while friends
    are connected.

Each player keeps their own character, inventory and save file. Things
you craft stay with you. (The shared church stash is the host's; your
own stash comes back when you play without them.)


1. INSTALL (everyone who plays)
-------------------------------
The zip contains:
  SulfurMP-Setup.exe          the installer (option A, easiest)
  Manual install - mod files  the raw mod files, if you'd rather install
                              it yourself (option B)
  README.txt                  this file

Use ONE of the two options below - they install exactly the same files.
Everyone who plays together must have the same version of the mod.

OPTION A: THE INSTALLER (recommended)
1. Unzip the zip anywhere (e.g. your Desktop).
2. Close SULFUR, then double-click SulfurMP-Setup.exe.
   If Windows says "Windows protected your PC", click "More info" and then
   "Run anyway" (the installer isn't signed by a company).
3. The installer finds your SULFUR folder by itself. If it can't, click
   "Browse..." and pick the folder that has Sulfur.exe in it.
   (On Steam: right-click SULFUR in your library > Manage > Browse local
   files.)
4. Click "Install" (it says "Reinstall" if the mod is already there).
   If Windows asks for administrator permission, click Yes.
5. Start SULFUR from Steam as usual.

The installer puts BepInEx (the mod loader) and the multiplayer mod into
your SULFUR folder. To update to a newer version of the mod, just run the
new SulfurMP-Setup.exe and click "Reinstall". Your settings are kept.

OPTION B: MANUAL INSTALL (the raw mod files)
Everything the installer does, done by hand:
1. Close SULFUR and open your SULFUR folder (the one with Sulfur.exe in
   it). On Steam: right-click SULFUR in your library > Manage > Browse
   local files.
2. Open the "Manual install - mod files" folder from this zip and copy
   EVERYTHING inside it into your SULFUR folder:
     winhttp.dll
     doorstop_config.ini
     .doorstop_version
     BepInEx  (folder)
   If Windows asks to replace or merge files, say yes.
   When you're done, winhttp.dll should sit right next to Sulfur.exe, and
   the mod should be at BepInEx\plugins\SulfurMP\SulfurMP.dll.
3. Start SULFUR from Steam as usual.

Already have BepInEx 5 installed for other SULFUR mods? Then you only
need the mod itself: copy the BepInEx\plugins\SulfurMP folder into your
existing BepInEx\plugins folder.

Updating by hand: copy the new SulfurMP.dll over the old one in
BepInEx\plugins\SulfurMP.

To check it worked: in game, press F8. A "SULFUR Multiplayer" window
should open.


2. PLAYING TOGETHER
-------------------
Everyone needs the mod installed, Steam running, and to be Steam friends
with the host.

HOSTING
1. Start SULFUR and load your save (or start a new character).
2. Press F8 to open the multiplayer menu and click "Host game".
3. Click "Invite friends (Steam overlay)" and invite your friends, or
   tell them to join you through Steam (see below).

JOINING
- Accept the host's invite in Steam, or right-click the host in your
  Steam friends list and choose "Join Game".
- If SULFUR isn't running, Steam starts it. From the main menu the mod
  loads your last save by itself and drops you in next to the host. (If
  you have no save yet, make a character and you'll drop in as soon as
  you're in the game.)
- If you're already playing, you travel to the host's level
  automatically.

THE MULTIPLAYER BAR
- While you're in a session, a small bar at the top of the screen lists
  every other player with their ping (green is good, yellow is OK, red is
  laggy), health, and whether they're dead, reloading, crouching, or in
  another level. Joins, leaves and deaths pop up just below it.
- Turn it off in the F8 menu, or with ShowStatusBar in the settings.

THE F8 MENU
- Shows whether you're hosting or who you're connected to, where the host
  is, and every player with their health and whether they're in your
  level.
- "Join host's level" takes you to the host if you're somewhere else.
- Switches for the multiplayer bar and for seeing other players' bullets.
- "Leave session" disconnects you (or ends the session, if you're the
  host).

SHARING AMMO AND MONEY
- Open your inventory and click one of your ammo counters (the ammo
  amounts listed in the inventory). A box of that ammo drops on the floor
  in front of you. Right-click drops 5 boxes at once.
- Boxes are the game's normal ammo boxes, so you can only drop whole
  boxes. Anyone can pick them up by walking over them.
- Click your money counter the same way to drop 20 in coins and notes,
  or right-click to drop 100.
- Your own drops won't jump straight back into your pockets: walk away
  from them first, or press the interact key on them, to take them back.
- At the church stash, clicking ammo still moves it in and out of the
  stash as usual.

SHARED STASH AND SHOPS
- The stash chest at the church and the shops hold the same items for
  everyone (the host's copy).
- Only one player can have a given stash or shop open at a time. If a
  friend is using it, you'll see a message - try again when they close
  it.

LEVELS, EXITS AND DYING
- Walking into a level exit doesn't drag everyone along any more. It
  starts a vote, and a banner shows who wants to leave, where to, and
  who is ready.
- Press Y to accept or N to decline. Walking into an exit yourself also
  counts as accepting.
- When everyone in the level has accepted, the whole party moves to the
  same next level together. If anyone declines (or nobody answers within
  2 minutes), the vote is cancelled and the exits work again.
- If you're the only one in the level, exits work straight away.
- By default, a player who isn't the host can also start an exit vote.
- If the host goes back to the church, everyone goes to the church too.
- If the host dies, the session keeps going: enemies in your level keep
  fighting on their own, and you follow the host again when they head
  into their next level.


3. SETTINGS
-----------
After you start SULFUR once with the mod, the settings file appears at:
  <SULFUR folder>\BepInEx\config\com.sulfurmp.multiplayer.cfg
Open it with Notepad (with the game closed). The most useful ones:

  MenuKey                     key that opens the multiplayer menu (F8)
  MaxPlayers                  lobby size including the host, 2-8 (4)
  ScaleEnemiesWithPlayers     multiply enemies by the number of players
                              (true)
  ShowNameplates              Steam names above other players (true)
  ShowStatusBar               the multiplayer bar at the top of the
                              screen (true)
  VoteAcceptKey               accept a level-exit vote (Y)
  VoteDeclineKey              decline a level-exit vote (N)
  TeleportToBossFights        bring you into the boss arena when someone
                              else starts the fight (true)
  PlayerRobeColor             robe colour of the other players' priests
                              ("auto", or a hex colour like E8C24A)
  PlayerSkinColor             face and hand colour of the priests
                              ("auto" matches the pale first-person
                              arms, or a hex colour like 7A4E32)
  PlayerModelScale            size of the other players' priests (1)
  ShowRemoteWeapons           show the weapons others are holding (true)
  RemoteWeaponForward         how far in front of a priest their weapon
                              and arms sit (0.4)
  RemoteWeaponDrop            how far below a priest's eyes their weapon
                              sits (0.22)
  ShowRemoteBullets           show the bullets others fire (true)
  AutoFollowHost              follow the host to new levels by yourself
                              (true). If false, use "Join host's level"
                              in the F8 menu.
  ClientsCanAdvanceLevel      let non-hosts start level-exit votes
                              (true)
  KeepWorldRunningWhenPaused  menus don't freeze time while friends are
                              connected (true)
  SyncPhysicsObjects          keep barrels, crates etc. in sync (true)

MaxPlayers, ScaleEnemiesWithPlayers and ClientsCanAdvanceLevel only
matter on the host's game; the rest are personal.


4. TROUBLESHOOTING
------------------
Nothing happens when I press F8
    The mod isn't loaded. Make sure winhttp.dll is next to Sulfur.exe and
    SulfurMP.dll is in BepInEx\plugins\SulfurMP, then restart the game.
    Running SulfurMP-Setup.exe again fixes this.
"Host is running a different SulfurMP version"
    Everyone needs the same version. Download the newest zip and install
    it again (everyone, host included).
"Couldn't reach the host. Try joining again." / stuck on "Connecting..."
    Ask the host to invite you again, or use "Join Game" on them in your
    Steam friends list. Both of you need Steam running and online.
"Could not create lobby" / "Could not join lobby"
    Steam had a hiccup. Restart SULFUR (and Steam if it keeps happening).
Some things look different for different players
    The mod is new and not everything in SULFUR is synced yet. Leaving the
    level and coming back (or "Join host's level") usually sorts it out.
"Close SULFUR before installing"
    The installer can't replace files while the game is running. Quit the
    game completely and try again.
After a big SULFUR update the mod stops working
    Wait for a new version of the mod, or uninstall it for now (section 5).

Log file: <SULFUR folder>\BepInEx\LogOutput.log - please send it along
with any bug report.


5. UNINSTALL
------------
Run SulfurMP-Setup.exe and click "Uninstall". It removes the mod, and
removes BepInEx too unless you have other BepInEx mods installed.

By hand: delete the BepInEx\plugins\SulfurMP folder. To remove BepInEx
as well, delete the BepInEx folder, winhttp.dll, doorstop_config.ini and
.doorstop_version from your SULFUR folder. Steam's "Verify integrity of
game files" does NOT remove these files, but the game runs normally
without the mod once they're gone.
