SULFUR MULTIPLAYER (version 0.3.0) - online co-op, 2 to 8 players
=================================================================

Play SULFUR together over Steam. One player hosts, friends join through
Steam (no IP addresses or port forwarding), and everyone drops into the
same level as the host:

  - Everyone fights the same enemies. The host's game controls them, and
    they react to every player.
  - Loot, chests, doors, breakables and pickups are shared: if one player
    grabs an item, it's gone for everyone else.
  - Barrels, crates and other loose physics objects stay in the same place
    for everyone.
  - Other players show up as goblins holding the weapon they have out,
    with muzzle flashes, tracers and melee swings, and their Steam name
    above their head.
  - When the host moves to a new level, everyone follows automatically.
  - Opening menus or your inventory doesn't freeze the game while friends
    are connected.

Each player keeps their own character, inventory and save file. Things
you craft stay with you.


1. INSTALL (everyone who plays)
-------------------------------
The zip contains:
  SulfurMP-Setup.exe          the installer (option A, easiest)
  Manual install - mod files  the raw mod files, if you'd rather install
                              it yourself (option B)
  README.txt                  this file

Use ONE of the two options below - they install exactly the same files.
Everyone who plays together must have the same version of the mod.

OPTION A: THE INSTALLER (recommended)
1. Unzip the zip anywhere (e.g. your Desktop).
2. Close SULFUR, then double-click SulfurMP-Setup.exe.
   If Windows says "Windows protected your PC", click "More info" and then
   "Run anyway" (the installer isn't signed by a company).
3. The installer finds your SULFUR folder by itself. If it can't, click
   "Browse..." and pick the folder that has Sulfur.exe in it.
   (On Steam: right-click SULFUR in your library > Manage > Browse local
   files.)
4. Click "Install" (it says "Reinstall" if the mod is already there).
   If Windows asks for administrator permission, click Yes.
5. Start SULFUR from Steam as usual.

The installer puts BepInEx (the mod loader) and the multiplayer mod into
your SULFUR folder. To update to a newer version of the mod, just run the
new SulfurMP-Setup.exe and click "Reinstall". Your settings are kept.

OPTION B: MANUAL INSTALL (the raw mod files)
Everything the installer does, done by hand:
1. Close SULFUR and open your SULFUR folder (the one with Sulfur.exe in
   it). On Steam: right-click SULFUR in your library > Manage > Browse
   local files.
2. Open the "Manual install - mod files" folder from this zip and copy
   EVERYTHING inside it into your SULFUR folder:
     winhttp.dll
     doorstop_config.ini
     .doorstop_version
     BepInEx  (folder)
   If Windows asks to replace or merge files, say yes.
   When you're done, winhttp.dll should sit right next to Sulfur.exe, and
   the mod should be at BepInEx\plugins\SulfurMP\SulfurMP.dll.
3. Start SULFUR from Steam as usual.

Already have BepInEx 5 installed for other SULFUR mods? Then you only
need the mod itself: copy the BepInEx\plugins\SulfurMP folder into your
existing BepInEx\plugins folder.

Updating by hand: copy the new SulfurMP.dll over the old one in
BepInEx\plugins\SulfurMP.

To check it worked: in game, press F8. A "SULFUR Multiplayer" window
should open.


2. PLAYING TOGETHER
-------------------
Everyone needs the mod installed, Steam running, and to be Steam friends
with the host.

HOSTING
1. Start SULFUR and load your save (or start a new character).
2. Press F8 to open the multiplayer menu and click "Host game".
3. Click "Invite friends (Steam overlay)" and invite your friends, or
   tell them to join you through Steam (see below).

JOINING
- Accept the host's invite in Steam, or right-click the host in your
  Steam friends list and choose "Join Game".
- If SULFUR isn't running, Steam starts it. From the main menu the mod
  loads your last save by itself and drops you in next to the host. (If
  you have no save yet, make a character and you'll drop in as soon as
  you're in the game.)
- If you're already playing, you travel to the host's level
  automatically.

THE F8 MENU
- Shows whether you're hosting or who you're connected to, where the host
  is, and every player with their health and whether they're in your
  level.
- "Join host's level" takes you to the host if you're somewhere else.
- "Leave session" disconnects you (or ends the session, if you're the
  host).

LEVELS, EXITS AND DYING
- When the host goes to a new level, everyone follows.
- By default, a player who isn't the host can also take a level exit,
  and the whole party moves on.
- If the host goes back to the church, everyone goes to the church too.
- If the host dies, the session keeps going: enemies in your level keep
  fighting on their own, and you follow the host again when they head
  into their next level.


3. SETTINGS
-----------
After you start SULFUR once with the mod, the settings file appears at:
  <SULFUR folder>\BepInEx\config\com.sulfurmp.multiplayer.cfg
Open it with Notepad (with the game closed). The most useful ones:

  MenuKey                     key that opens the multiplayer menu (F8)
  MaxPlayers                  lobby size including the host, 2-8 (4)
  ShowNameplates              Steam names above other players (true)
  GoblinSkinColor             colour of the other players' goblins
                              ("auto", or a hex colour like 6B9440)
  GoblinScale                 size of the other players' goblins (1)
  ShowRemoteWeapons           show the weapons others are holding (true)
  AutoFollowHost              follow the host to new levels by yourself
                              (true). If false, use "Join host's level"
                              in the F8 menu.
  ClientsCanAdvanceLevel      let non-hosts take level exits for the
                              whole party (true)
  KeepWorldRunningWhenPaused  menus don't freeze time while friends are
                              connected (true)
  SyncPhysicsObjects          keep barrels, crates etc. in sync (true)

MaxPlayers and ClientsCanAdvanceLevel only matter on the host's game;
the rest are personal.


4. TROUBLESHOOTING
------------------
Nothing happens when I press F8
    The mod isn't loaded. Make sure winhttp.dll is next to Sulfur.exe and
    SulfurMP.dll is in BepInEx\plugins\SulfurMP, then restart the game.
    Running SulfurMP-Setup.exe again fixes this.
"Host is running a different SulfurMP version"
    Everyone needs the same version. Download the newest zip and install
    it again (everyone, host included).
"Couldn't reach the host. Try joining again." / stuck on "Connecting..."
    Ask the host to invite you again, or use "Join Game" on them in your
    Steam friends list. Both of you need Steam running and online.
"Could not create lobby" / "Could not join lobby"
    Steam had a hiccup. Restart SULFUR (and Steam if it keeps happening).
Some things look different for different players
    The mod is new and not everything in SULFUR is synced yet. Leaving the
    level and coming back (or "Join host's level") usually sorts it out.
"Close SULFUR before installing"
    The installer can't replace files while the game is running. Quit the
    game completely and try again.
After a big SULFUR update the mod stops working
    Wait for a new version of the mod, or uninstall it for now (section 5).

Log file: <SULFUR folder>\BepInEx\LogOutput.log - please send it along
with any bug report.


5. UNINSTALL
------------
Run SulfurMP-Setup.exe and click "Uninstall". It removes the mod, and
removes BepInEx too unless you have other BepInEx mods installed.

By hand: delete the BepInEx\plugins\SulfurMP folder. To remove BepInEx
as well, delete the BepInEx folder, winhttp.dll, doorstop_config.ini and
.doorstop_version from your SULFUR folder. Steam's "Verify integrity of
game files" does NOT remove these files, but the game runs normally
without the mod once they're gone.
